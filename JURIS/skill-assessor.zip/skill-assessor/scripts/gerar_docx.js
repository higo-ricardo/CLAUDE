/**
 * gerar_docx.js — Monta o Relatório de Assessoria Jurídica Processual em .docx
 * a partir do JSON estruturado (FASE 6) e, opcionalmente, da imagem de timeline
 * gerada por gerar_timeline.py.
 *
 * Uso:
 *   node gerar_docx.js dados.json saida.docx [timeline.png]
 *
 * Segue fielmente as seções e a lógica condicional de references/template_relatorio.md.
 */

const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, AlignmentType, ImageRun, PageOrientation,
} = require("docx");

const [, , entradaPath, saidaPath, timelinePath] = process.argv;
if (!entradaPath || !saidaPath) {
  console.error("Uso: node gerar_docx.js dados.json saida.docx [timeline.png]");
  process.exit(1);
}

const dados = JSON.parse(fs.readFileSync(entradaPath, "utf-8"));

const COR_TITULO = "1F3A5F";
const COR_LINHA = "D9DEE4";
const FONT = "Calibri";

const p = (text, opts = {}) => new Paragraph({
  children: [new TextRun({ text: text ?? "—", font: FONT, ...opts })],
  spacing: { after: 120 },
});

const heading = (text, level = HeadingLevel.HEADING_1) => new Paragraph({
  text,
  heading: level,
  spacing: { before: 300, after: 160 },
});

const infoTable = (rows) => new Table({
  width: { size: 100, type: WidthType.PERCENTAGE },
  columnWidths: [3000, 6800],
  rows: rows.map(([label, value]) => new TableRow({
    children: [
      new TableCell({
        width: { size: 3000, type: WidthType.DXA },
        shading: { type: ShadingType.CLEAR, fill: "F2F4F7" },
        children: [new Paragraph({ children: [new TextRun({ text: label, bold: true, font: FONT, size: 20 })] })],
      }),
      new TableCell({
        width: { size: 6800, type: WidthType.DXA },
        children: [new Paragraph({ children: [new TextRun({ text: value ?? "—", font: FONT, size: 20 })] })],
      }),
    ],
  })),
});

function listaOuTraco(arr) {
  return Array.isArray(arr) && arr.length ? arr.join("; ") : "—";
}

const sections = [];

// Capa / título
sections.push(
  new Paragraph({
    children: [new TextRun({ text: "RELATÓRIO DE ASSESSORIA JURÍDICA", bold: true, size: 32, color: COR_TITULO, font: FONT })],
    spacing: { after: 60 },
  }),
  new Paragraph({
    children: [new TextRun({ text: "Análise Processual", size: 24, color: "5A6472", font: FONT })],
    spacing: { after: 400 },
  }),
);

// 1. Identificação
sections.push(heading("1. Identificação do Processo"));
sections.push(infoTable([
  ["Número CNJ", dados.numero_processo],
  ["Tribunal", dados.tribunal],
  ["Vara / Juízo", dados.vara],
  ["Fase Processual", dados.fase_processual],
  ["Valor da Causa", dados.valor_causa],
  ["Status da Extração", `${dados.status_extracao ?? "—"} — ${dados.mensagem ?? ""}`],
]));

// 2. Classificação
if (dados.tipo_acao) {
  sections.push(heading("2. Classificação da Ação"));
  sections.push(infoTable([
    ["Categoria Principal", dados.tipo_acao.categoria_primaria],
    ["Categoria Secundária", dados.tipo_acao.categoria_secundaria || "—"],
    ["Confiança", dados.tipo_acao.confianca],
    ["Sinais Identificados", listaOuTraco(dados.tipo_acao.sinais_identificados)],
  ]));
}

// 3. Partes
sections.push(heading("3. Partes Envolvidas"));
sections.push(infoTable([
  ["Parte Autora", dados.parte_autora],
  ["Parte Requerida", dados.parte_requerida],
]));

// 4. Cronologia — timeline visual + tabela de apoio
sections.push(heading("4. Cronologia Processual Completa"));
function pngDims(buf) {
  // PNG: largura/altura ficam nos bytes 16-23 do IHDR (big-endian, sem dependências externas)
  try {
    return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) };
  } catch {
    return { width: 1400, height: 900 };
  }
}

if (timelinePath && fs.existsSync(timelinePath)) {
  const imgBuffer = fs.readFileSync(timelinePath);
  const dim = pngDims(imgBuffer);
  const maxWidthEmu = 620; // pontos aproximados de largura útil
  const ratio = dim.height / dim.width;
  sections.push(new Paragraph({
    children: [new ImageRun({
      data: imgBuffer,
      type: "png",
      transformation: { width: maxWidthEmu, height: Math.round(maxWidthEmu * ratio) },
    })],
    spacing: { after: 200 },
  }));
} else {
  sections.push(p("(Linha do tempo visual não gerada — ver tabela abaixo.)", { italics: true, size: 18, color: "888888" }));
}

if (Array.isArray(dados.cronologia_completa) && dados.cronologia_completa.length) {
  sections.push(new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    columnWidths: [1400, 2200, 1800, 4400],
    rows: [
      new TableRow({
        children: ["Data", "Tipo de Ato", "Autor", "Descrição"].map((h) => new TableCell({
          shading: { type: ShadingType.CLEAR, fill: COR_TITULO },
          children: [new Paragraph({ children: [new TextRun({ text: h, bold: true, color: "FFFFFF", font: FONT, size: 18 })] })],
        })),
      }),
      ...dados.cronologia_completa.map((ato) => new TableRow({
        children: [ato.data, ato.tipo_ato, ato.autor_ato || "—", ato.descricao].map((v) => new TableCell({
          borders: { top: { style: BorderStyle.SINGLE, size: 2, color: COR_LINHA }, bottom: { style: BorderStyle.SINGLE, size: 2, color: COR_LINHA }, left: { style: BorderStyle.SINGLE, size: 2, color: COR_LINHA }, right: { style: BorderStyle.SINGLE, size: 2, color: COR_LINHA } },
          children: [new Paragraph({ children: [new TextRun({ text: String(v ?? "—"), font: FONT, size: 18 })] })],
        })),
      })),
    ],
  }));
}

// 5. Patrimônio (condicional)
if (dados.bens && (dados.bens.imoveis?.length || dados.bens.veiculos?.length || dados.bens.moveis?.length)) {
  sections.push(heading("5. Patrimônio Discutido"));
  (dados.bens.imoveis || []).forEach((im) => sections.push(p(
    `Imóvel — ${im.endereco || "endereço não informado"} · Matrícula: ${im.matricula || "—"} · Aquisição: ${im.aquisicao || "—"} · Valor: ${im.valor || "—"}`
  )));
  (dados.bens.veiculos || []).forEach((v) => sections.push(p(
    `Veículo — ${v.marca || ""} ${v.modelo || ""} (${v.ano || "—"}) · Placa: ${v.placa || "—"} · Valor: ${v.valor || "—"}`
  )));
  (dados.bens.moveis || []).forEach((m) => sections.push(p(`Bem móvel/financeiro — ${m}`)));
}

// 6. Dívidas (condicional)
if (Array.isArray(dados.dividas) && dados.dividas.length) {
  sections.push(heading("6. Dívidas e Obrigações"));
  dados.dividas.forEach((d) => sections.push(p(
    `${d.valor || "—"} · Credor: ${d.credor || "—"} · Devedor: ${d.devedor || "—"} · ${d.data || "—"} · Natureza: ${d.natureza || "—"}`
  )));
}

// 7. Guarda e Convivência (condicional)
if (dados.guarda_convivencia) {
  sections.push(heading("7. Guarda e Convivência"));
  sections.push(infoTable([
    ["Regime de Guarda", dados.guarda_convivencia.guarda],
    ["Regime de Convivência", dados.guarda_convivencia.visitas],
    ["Laudos / Estudos Sociais", dados.guarda_convivencia.laudos_mencionados],
    ["Argumentos do Autor", dados.guarda_convivencia.argumentos_autor],
    ["Argumentos do Réu", dados.guarda_convivencia.argumentos_reu],
  ]));
}

// 8. Alimentos (condicional)
if (dados.alimentos) {
  sections.push(heading("8. Alimentos"));
  sections.push(infoTable([
    ["Percentual", dados.alimentos.percentual],
    ["Valor Fixo", dados.alimentos.valor_fixo],
    ["Tutela Antecipada", dados.alimentos.tutela_antecipada],
    ["Base de Cálculo", dados.alimentos.base_calculo],
    ["Necessidade (alimentando)", dados.alimentos.necessidade],
    ["Possibilidade (alimentante)", dados.alimentos.possibilidade],
  ]));
}

// 9. Pontos de atenção (preenchido externamente pelo agente antes de gerar o docx)
if (Array.isArray(dados.pontos_atencao) && dados.pontos_atencao.length) {
  sections.push(heading("9. Pontos de Atenção para a Assessoria"));
  dados.pontos_atencao.forEach((pt) => sections.push(p(`⚠  ${pt}`)));
}

// 10. Limitações
if (Array.isArray(dados.campos_ausentes) && dados.campos_ausentes.length) {
  sections.push(heading("10. Dados Ausentes / Limitações da Extração"));
  dados.campos_ausentes.forEach((c) => sections.push(p(`• ${c}`)));
  if (dados.recomendacao_dados_ausentes) sections.push(p(`Recomendação: ${dados.recomendacao_dados_ausentes}`));
}

// Rodapé institucional
sections.push(new Paragraph({
  border: { top: { style: BorderStyle.SINGLE, size: 6, color: COR_LINHA } },
  spacing: { before: 400 },
  children: [new TextRun({
    text: "Relatório gerado automaticamente com base no texto fornecido. Dados de pessoas físicas foram anonimizados (iniciais). Este relatório é um instrumento de apoio à assessoria jurídica e não substitui a análise profissional do advogado responsável.",
    italics: true, size: 16, color: "777777", font: FONT,
  })],
}));

const doc = new Document({
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 } } },
    children: sections,
  }],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync(saidaPath, buf);
  console.log(`Relatório gerado: ${saidaPath}`);
});
