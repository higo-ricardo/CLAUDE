#!/usr/bin/env python3
"""
gerar_timeline.py — Gera uma imagem PNG com a linha do tempo processual
a partir do array `cronologia_completa` do JSON extraído pela skill assessor.

Uso:
    python3 gerar_timeline.py entrada.json saida.png

Onde entrada.json é o JSON completo produzido na FASE 6 (ou apenas um objeto
contendo a chave "cronologia_completa").

Cores por tipo_ato seguem uma paleta jurídica neutra (sem vermelho/verde
como "bom/ruim" — apenas categorização visual).
"""

import json
import sys
import textwrap

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

# Paleta por tipo_ato — mesma ordem da tabela em SKILL.md FASE 5
CORES = {
    "INICIAL":      "#2c3e50",
    "DESPACHO":     "#7f8c8d",
    "DECISAO_INT":  "#8e44ad",
    "CITACAO":      "#2980b9",
    "CONTESTACAO":  "#c0392b",
    "REPLICA":      "#d35400",
    "AUDIENCIA":    "#16a085",
    "PERICIA":      "#27ae60",
    "MANIFESTACAO": "#7f8c8d",
    "SENTENCA":     "#8e44ad",
    "RECURSO":      "#e67e22",
    "ACORDAO":      "#8e44ad",
    "EXECUCAO":     "#c0392b",
    "ACORDO":       "#16a085",
    "ARQUIVAMENTO": "#34495e",
    "OUTRO":        "#95a5a6",
}

LABELS = {
    "INICIAL": "Inicial", "DESPACHO": "Despacho", "DECISAO_INT": "Decisão Interloc.",
    "CITACAO": "Citação/Intimação", "CONTESTACAO": "Contestação", "REPLICA": "Réplica",
    "AUDIENCIA": "Audiência", "PERICIA": "Perícia/Laudo", "MANIFESTACAO": "Manifestação",
    "SENTENCA": "Sentença", "RECURSO": "Recurso", "ACORDAO": "Acórdão",
    "EXECUCAO": "Execução", "ACORDO": "Acordo", "ARQUIVAMENTO": "Arquivamento",
    "OUTRO": "Outro",
}


def carregar_cronologia(path):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    cron = data.get("cronologia_completa", data) if isinstance(data, dict) else data
    if not cron:
        raise ValueError("cronologia_completa vazia ou ausente no JSON de entrada.")
    return cron


def gerar_timeline(cron, saida, numero_processo=None):
    n = len(cron)
    altura = max(3.0, 0.62 * n + 1.2)
    fig, ax = plt.subplots(figsize=(9.5, altura), dpi=200)

    y_positions = list(range(n, 0, -1))
    ax.plot([0, 0], [0.4, n + 0.6], color="#bdc3c7", linewidth=2, zorder=1)

    for y, ato in zip(y_positions, cron):
        tipo = ato.get("tipo_ato", "OUTRO")
        cor = CORES.get(tipo, "#95a5a6")
        data = ato.get("data", "—")
        autor = ato.get("autor_ato")
        desc = ato.get("descricao", "")

        ax.scatter([0], [y], s=140, color=cor, zorder=3, edgecolors="white", linewidths=1.5)

        rotulo = f"{data}  —  {LABELS.get(tipo, tipo)}"
        if autor:
            rotulo += f"  ({autor})"
        ax.text(0.15, y + 0.16, rotulo, fontsize=9.5, fontweight="bold",
                 color="#2c3e50", va="bottom", ha="left")

        desc_quebrada = "\n".join(textwrap.wrap(desc, width=95)) or "—"
        ax.text(0.15, y - 0.18, desc_quebrada, fontsize=8.5, color="#555555",
                 va="top", ha="left", linespacing=1.3)

    ax.set_xlim(-0.3, 8.5)
    ax.set_ylim(0.2, n + 1.0)
    ax.axis("off")

    titulo = "Linha do Tempo Processual"
    if numero_processo:
        titulo += f" — {numero_processo}"
    ax.set_title(titulo, fontsize=13, fontweight="bold", color="#2c3e50", loc="left", pad=14)

    tipos_presentes = sorted({a.get("tipo_ato", "OUTRO") for a in cron},
                              key=lambda t: list(CORES).index(t) if t in CORES else 99)
    handles = [Line2D([0], [0], marker="o", color="w", label=LABELS.get(t, t),
                       markerfacecolor=CORES.get(t, "#95a5a6"), markersize=8)
               for t in tipos_presentes]
    ax.legend(handles=handles, loc="upper right", bbox_to_anchor=(1.0, 1.0),
              fontsize=7.5, frameon=False, ncol=1)

    plt.tight_layout()
    plt.savefig(saida, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return saida


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Uso: python3 gerar_timeline.py entrada.json saida.png [numero_processo]")
        sys.exit(1)
    entrada, saida = sys.argv[1], sys.argv[2]
    numero = sys.argv[3] if len(sys.argv) > 3 else None
    cron = carregar_cronologia(entrada)
    if not numero:
        try:
            with open(entrada, "r", encoding="utf-8") as f:
                numero = json.load(f).get("numero_processo")
        except Exception:
            numero = None
    path = gerar_timeline(cron, saida, numero)
    print(f"Timeline gerada: {path}")
