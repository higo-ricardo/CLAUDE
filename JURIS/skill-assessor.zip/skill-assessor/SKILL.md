---
name: assessor
description: >
  Extrai metadados e dados estruturados de textos de processos judiciais brasileiros e gera
  relatório de assessoria jurídica completo. Use esta skill SEMPRE que o usuário quiser:
  analisar um processo judicial, extrair informações de autos, identificar partes, bens, dívidas,
  guarda, alimentos ou cronologia de um processo, gerar relatório jurídico, resumo processual,
  ficha de processo, ou quando mencionar termos como "processo", "autos", "petição", "decisão",
  "sentença", "vara", "tribunal", "CNJ", "parte autora", "réu", "ação judicial". Ative mesmo
  que o usuário não diga "extrair metadados" — qualquer pedido de análise, resumo ou relatório
  de um documento jurídico brasileiro é gatilho suficiente.
metadata:
  versao: 2.1.0
  autor: assessoria-juridica
  tags: [juridico, extracao, metadados, processo, CNJ, relatorio, assessoria]
---

# Skill: Assessoria Juridica — Extração e Relatório v2.1

Esta skill transforma textos brutos de processos judiciais brasileiros em relatórios estruturados
de assessoria jurídica, com classificação automática do tipo de ação, extração inteligente de
seções condicionais e listagem completa de atos processuais.

---

## Visão Geral do Fluxo

```
TEXTO DO PROCESSO
       |
  [FASE 1] Validação — é um processo judicial?
       |
  [FASE 2] Classificação do Tipo de Ação → define quais seções serão extraídas
       |
  [FASE 3] Extração Base (número, tribunal, vara, partes, valor da causa)
       |
  [FASE 4] Extração Condicional (seções habilitadas pelo tipo de ação)
       |
  [FASE 5] Cronologia completa de TODOS os atos processuais identificados
       |
  [FASE 6] Montagem do JSON estruturado + validação
       |
  [FASE 7] Geração do Relatório de Assessoria (seções dinâmicas por tipo)
       |
  [FASE 8] Exportação Opcional — DOCX / PDF com timeline visual
       |
  RELATÓRIO FINAL (texto e, se solicitado, arquivo .docx/.pdf)
```

---

## Regras Transversais

Valem para todas as fases a seguir. As regras específicas de cada dado — anonimização,
formato de datas, litisconsórcio, cronologia sem limite, seções habilitadas por tipo de
ação — ficam junto do dado que regulam (FASE 3, FASE 4, FASE 5) e se aplicam também à
exportação em arquivo (FASE 8). Aqui ficam só as que não pertencem a uma fase específica:

1. Moeda — valores em "R$" no formato brasileiro (ponto de milhar, vírgula decimal).
2. Empresas — nome completo com tipo societário (Ltda., S.A., EIRELI, ME, EPP).
3. Classificação incerta — confianca: "baixa" quando os sinais da FASE 2 forem insuficientes.
4. Validação final — antes de entregar, confirme que o JSON é sintaticamente
   válido e que as seções exibidas no relatório correspondem exatamente às
   habilitadas na FASE 2.

---

## FASE 1 — Validação

Confirme que o texto contém ao menos dois destes elementos:
- Número no padrão CNJ: \d{7}-\d{2}\.\d{4}\.\d{1,2}\.\d{2}\.\d{4}
- Palavras-chave: "autos", "processo", "ação", "requerente", "requerido", "exequente",
  "executado", "vara", "comarca", "tribunal", "juízo", "sentença", "decisão", "despacho"

| Resultado | Status | Conduta |
|---|---|---|
| Nenhum elemento encontrado | nao_e_processo | Retornar JSON mínimo e encerrar |
| Elementos parciais | parcial | Continuar; registrar limitações na seção 9 do relatório |
| Elementos suficientes | sucesso | Prosseguir normalmente |

---

## FASE 2 — Classificação do Tipo de Ação

Esta fase determina QUAIS SEÇÕES serão extraídas e exibidas no relatório.
Classifique com base nos sinais do texto (nome da vara, palavras-chave, pedidos, tipo de partes).
Um processo pode pertencer a mais de uma categoria — registre primária e secundária.

### Tabela de Classificação e Seções Habilitadas

| Tipo de Ação | Sinais no Texto | Seções Habilitadas |
|---|---|---|
| FAMÍLIA | Vara de Família, divórcio, dissolução, separação, união estável, partilha, alimentos, guarda, convivência, adoção | Bens · Guarda e Convivência · Alimentos · Dívidas |
| CÍVEL PATRIMONIAL | Vara Cível, cobrança, indenização, contrato, rescisão, posse, propriedade, usucapião, despejo, locação | Bens · Dívidas |
| TRABALHISTA | Vara do Trabalho, TRT, reclamação trabalhista, verbas rescisórias, FGTS, horas extras, vínculo empregatício | Dívidas (verbas trabalhistas) |
| CRIMINAL | Vara Criminal, ação penal, denúncia, MP, Ministério Público, réu, crime, delito, pena | Cronologia e Partes apenas |
| CONSUMIDOR | CDC, relação de consumo, fornecedor, produto/serviço defeituoso, dano moral consumerista | Dívidas · Valor do dano |
| PREVIDENCIÁRIO | INSS, benefício, aposentadoria, auxílio-doença, BPC, concessão, revisão | Dívidas (atrasados) |
| EMPRESARIAL | Falência, recuperação judicial, dissolução societária, quotas, acionistas | Bens · Dívidas |
| FISCAL / TRIBUTÁRIO | Execução fiscal, PGFN, Fazenda, CDA, tributo, ICMS, IRPF, parcelamento | Dívidas |
| SUCESSÓRIO / INVENTÁRIO | Inventário, partilha, herança, espólio, herdeiros, testamento | Bens · Dívidas |
| NÃO IDENTIFICADO | Sinais insuficientes | Extrair todas as seções presentes; alertar no relatório |

Registre no JSON:
```json
"tipo_acao": {
  "categoria_primaria": "FAMÍLIA",
  "categoria_secundaria": null,
  "confianca": "alta | média | baixa",
  "sinais_identificados": ["Vara de Família", "pedido de guarda", "partilha de bens"]
}
```

---

## FASE 3 — Extração Base

Extraia SEMPRE, independentemente do tipo de ação:

| Campo | Como extrair |
|---|---|
| numero_processo | Regex CNJ completo |
| tribunal | Do número CNJ ou menção explícita — ver references/glossario_cnj.md |
| vara | "2ª Vara Cível", "Vara de Família", "1ª VT de São Luís" |
| parte_autora | Requerente / autor / exequente / impetrante / reclamante |
| parte_requerida | Requerido / réu / executado / impetrado / reclamado |
| valor_causa | "valor da causa: R$ …" ou "dá-se à causa o valor de R$ …" |
| fase_processual | Conhecimento / Instrução / Sentença / Recurso / Execução / Arquivado |

Anonimização obrigatória:
- Pessoa física → somente iniciais (ex: "M. A. S.")
- Pessoa jurídica → nome completo com tipo societário
- Litisconsórcio → partes separadas por " ; "

---

## FASE 4 — Extração Condicional

Extraia APENAS as seções habilitadas para o tipo identificado na Fase 2.
Nunca invente dados. Se um campo habilitado não constar no texto, omita-o.

### 4.1 Bens (FAMÍLIA · CÍVEL PATRIMONIAL · EMPRESARIAL · SUCESSÓRIO)

Imóveis: endereço completo · matrícula do RI · data de aquisição · valor venal/avaliado
Veículos: marca · modelo · ano · placa · valor se mencionado
Bens móveis e financeiros: cada item individualmente (móveis, eletrodomésticos, investimentos,
cotas societárias, participações, criptoativos, aplicações financeiras)

### 4.2 Dívidas e Obrigações (todos exceto CRIMINAL)

Para cada dívida: valor (com atualização se mencionada) · credor · devedor ·
data de vencimento ou constituição · natureza (contratual, tributária, trabalhista, alimentar)

### 4.3 Guarda e Convivência (FAMÍLIA apenas, somente se houver filhos mencionados)

- Regime de guarda pleiteado e/ou deferido (unilateral, compartilhada, nidal)
- Regime de convivência/visitas detalhado
- Argumentos do autor sobre a guarda
- Argumentos do réu sobre a guarda
- Laudos, estudos sociais ou manifestações do MP mencionados

### 4.4 Alimentos (FAMÍLIA, somente se houver pedido alimentar)

- Percentual pleiteado/fixado
- Valor fixo pleiteado/fixado
- Base de cálculo (salário, pró-labore, rendimentos totais, salários mínimos)
- Demonstração de necessidade do alimentando
- Demonstração de possibilidade do alimentante
- Tutela antecipada de alimentos (se deferida, registrar o valor provisório)

---

## FASE 5 — Cronologia Processual Completa

Liste TODOS OS ATOS PROCESSUAIS identificados no texto, SEM LIMITE DE QUANTIDADE,
em ORDEM CRONOLÓGICA ESTRITA (do mais antigo ao mais recente).

Se duas datas forem iguais, ordenar pelo tipo: despacho antes de resposta antes de decisão.
Se a data for incompleta, use 01/mm/aaaa ou 01/01/aaaa e marque como "(data aproximada)".

Para cada ato registre:
- data: dd/mm/aaaa
- tipo_ato: conforme a tabela abaixo (use o código)
- autor_ato: quem praticou, se identificável
- descricao: até 40 palavras, objetiva, sem jargão desnecessário

### Tabela de Tipos de Ato Processual

| Código | Tipo | Exemplos |
|---|---|---|
| INICIAL | Petição Inicial | Distribuição, protocolo da ação |
| DESPACHO | Despacho | Mero expediente, ordem de citação, prazo |
| DECISAO_INT | Decisão Interlocutória | Tutela antecipada, saneamento, produção de provas |
| CITACAO | Citação / Intimação | Citação do réu, intimação das partes, AR |
| CONTESTACAO | Contestação / Resposta | Contestação, exceção, reconvenção |
| REPLICA | Réplica | Manifestação do autor sobre a contestação |
| AUDIENCIA | Audiência | Conciliação, instrução, alegações finais, CEJUSC |
| PERICIA | Perícia / Laudo | Laudo pericial, estudo social, avaliação de bens |
| MANIFESTACAO | Manifestação / Petição | Petição intercorrente, juntada de documentos |
| SENTENCA | Sentença | Mérito, extinção sem resolução, homologação |
| RECURSO | Recurso | Apelação, agravo de instrumento, embargos |
| ACORDAO | Acórdão | Julgamento pelo tribunal colegiado |
| EXECUCAO | Execução / Cumprimento | Penhora, avaliação, leilão, expropriação |
| ACORDO | Acordo / Homologação | Termo de acordo, homologação judicial |
| ARQUIVAMENTO | Arquivamento / Extinção | Arquivamento definitivo, extinção da execução |
| OUTRO | Outro | Ato não enquadrado nas categorias acima |

---

## FASE 6 — Montagem do JSON

Consulte references/schema.json para validação formal.
Omita campos ausentes. Não use null para arrays — use []. Omita objetos opcionais inteiros.

```json
{
  "status_extracao": "sucesso",
  "mensagem": "Extração completa. Ação de família com guarda e alimentos.",
  "numero_processo": "0001234-56.2024.8.10.0001",
  "tribunal": "TJMA",
  "vara": "2ª Vara de Família de São Luís",
  "fase_processual": "Instrução",
  "valor_causa": "R$ 150.000,00",
  "parte_autora": "M. A. S.",
  "parte_requerida": "P. R. S.",
  "tipo_acao": {
    "categoria_primaria": "FAMÍLIA",
    "categoria_secundaria": null,
    "confianca": "alta",
    "sinais_identificados": ["Vara de Família", "pedido de guarda", "alimentos"]
  },
  "bens": {
    "imoveis": [{"endereco": "", "matricula": "", "aquisicao": "", "valor": ""}],
    "veiculos": [{"marca": "", "modelo": "", "ano": "", "placa": "", "valor": ""}],
    "moveis": []
  },
  "dividas": [{"valor": "", "credor": "", "devedor": "", "data": "", "natureza": ""}],
  "guarda_convivencia": {
    "guarda": "",
    "visitas": "",
    "argumentos_autor": "",
    "argumentos_reu": "",
    "laudos_mencionados": ""
  },
  "alimentos": {
    "percentual": "",
    "valor_fixo": "",
    "base_calculo": "",
    "necessidade": "",
    "possibilidade": "",
    "tutela_antecipada": ""
  },
  "cronologia_completa": [
    {
      "data": "dd/mm/aaaa",
      "tipo_ato": "INICIAL",
      "autor_ato": "Parte autora",
      "descricao": "Distribuição da ação de divórcio litigioso com pedido de guarda compartilhada e alimentos."
    }
  ]
}
```

---

## FASE 7 — Relatório de Assessoria

Gere o relatório seguindo o template em references/template_relatorio.md.
As seções são dinâmicas — inclua apenas as habilitadas pelo tipo de ação da Fase 2.

Princípios:
- Linguagem técnico-jurídica, clara e objetiva; analise e contextualize, não apenas liste dados
- Seção "Pontos de Atenção" obrigatória, com no mínimo 3 pontos
- Se status parcial (FASE 1), detalhe em "Limitações" o que está ausente e como obtê-lo

---

## FASE 8 — Exportação Opcional (DOCX / PDF com Timeline Visual)

Por padrão o relatório é entregue como texto (FASE 7). Gere o arquivo .docx/.pdf
SOMENTE quando o usuário pedir explicitamente um documento, arquivo para baixar,
anexar, enviar ao cliente ou imprimir ("gera o relatório em Word", "manda em PDF",
"quero o arquivo", "documento para anexar aos autos").

### 8.1 Preparar os dados adicionais

Antes de exportar, complete no objeto JSON da FASE 6 os campos que o relatório em
texto (FASE 7) já produz mas que o exportador consome diretamente:

```json
{
  "...": "...campos das fases 3-6...",
  "pontos_atencao": [
    "Texto de cada ponto de atenção, já redigido (mínimo 3, sem o símbolo ⚠)"
  ],
  "campos_ausentes": ["Nome do campo ausente 1", "Nome do campo ausente 2"],
  "recomendacao_dados_ausentes": "Como obter os dados ausentes (se status = parcial)"
}
```

Salve esse JSON em um arquivo (ex: `/tmp/dados_processo.json`).

### 8.2 Gerar a timeline visual

```bash
python3 scripts/gerar_timeline.py /tmp/dados_processo.json /tmp/timeline.png
```

Gera um PNG com a linha do tempo (um marcador colorido por `tipo_ato`, legenda
automática apenas com os tipos presentes no processo). Se `cronologia_completa`
tiver mais de ~25 atos, a imagem cresce verticalmente — isso é esperado e
aceitável; não trunque a cronologia para caber na imagem.

### 8.3 Montar o documento Word

```bash
node scripts/gerar_docx.js /tmp/dados_processo.json /mnt/user-data/outputs/relatorio_assessoria.docx /tmp/timeline.png
```

O script monta automaticamente apenas as seções habilitadas pelo `tipo_acao`
(mesma lógica condicional do template_relatorio.md), incluindo:
tabela de identificação · classificação · partes · timeline visual + tabela de
apoio da cronologia · patrimônio · dívidas · guarda/convivência · alimentos ·
pontos de atenção · limitações · rodapé institucional com aviso de anonimização.

O terceiro argumento (caminho da timeline) é opcional — se omitido ou o arquivo
não existir, o relatório é gerado normalmente só com a tabela de cronologia.

### 8.4 Conversão para PDF e verificação visual

Um único comando cobre as duas necessidades — gerar o PDF pedido pelo usuário
e obter as páginas para conferência visual antes de entregar:

```bash
python3 scripts/office/soffice.py --headless --convert-to pdf /mnt/user-data/outputs/relatorio_assessoria.docx
pdftoppm -jpeg -r 100 relatorio_assessoria.pdf pagina
```

(`scripts/office/soffice.py` pertence à skill `docx` pública do ambiente, não
a esta skill.) Regras de uso:
- Se o usuário pediu PDF, entregue o `.pdf` gerado em vez do `.docx`.
- Em qualquer caso, confira visualmente cada página renderizada antes de
  chamar `present_files`.

### 8.5 Regras desta fase

1. Nunca gere .docx/.pdf sem pedido explícito — o padrão continua sendo texto.
2. Os `pontos_atencao` do JSON de exportação devem ser os MESMOS da seção 9
   do relatório em texto — não redija um conjunto diferente para o arquivo.
3. Anonimização (iniciais para pessoa física) vale igualmente no arquivo exportado.
4. Se `cronologia_completa` estiver vazia, pule a geração da timeline (8.2) e
   informe isso na seção 10 do relatório.
