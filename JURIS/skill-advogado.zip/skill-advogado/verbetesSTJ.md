# Enunciados das Súmulas do STJ — Seleção Verificada por Domínio

> ⚠️ NATUREZA DESTE ARQUIVO: diferente de `verbetesSTF.md` (lista completa),
> este arquivo é uma **seleção inicial e verificada** de súmulas do STJ
> relevantes aos domínios que a skill `advogado` cobre (A — imobiliário,
> B — consumerista, C — cível geral/recursal, E — família e sucessões,
> F/G — remédios constitucionais e mandado de segurança). Cada súmula
> abaixo teve seu texto **conferido em fonte** antes de ser incluída —
> nenhuma foi reproduzida de memória sem checagem. Não é uma lista
> exaustiva de todas as ~680 súmulas do STJ. Novas súmulas devem ser
> adicionadas apenas após verificação equivalente, para não introduzir
> erro em peça jurídica real.

---

## Domínio C — Processual Civil / Admissibilidade Recursal

Súmula 5 — A simples interpretação de cláusula contratual não enseja
recurso especial.

Súmula 7 — A pretensão de simples reexame de prova não enseja recurso
especial.

Súmula 83 — Não se conhece do recurso especial pela divergência, quando
a orientação do tribunal se firmou no mesmo sentido da decisão recorrida.

Súmula 126 — É inadmissível recurso especial, quando o acórdão recorrido
assenta em fundamentos constitucional e infraconstitucional, qualquer
deles suficiente, por si só, para mantê-lo, e a parte vencida não
manifesta recurso extraordinário.

Súmula 211 — Inadmissível recurso especial quanto à questão que, a
despeito da oposição de embargos declaratórios, não foi apreciada pelo
Tribunal a quo.

Súmula 344 — A liquidação por forma diversa da estabelecida na sentença
não ofende a coisa julgada.

Súmula 518 — Para fins do art. 105, III, "a", da Constituição Federal,
não é cabível recurso especial fundado em alegada violação de enunciado
de súmula.

Súmula 568 — O relator, monocraticamente e no Superior Tribunal de
Justiça, poderá dar ou negar provimento ao recurso quando houver
entendimento dominante acerca do tema.

**Uso prático (roteamento):** as Súmulas 5, 7, 83, 126 e 211 são as mais
citadas para inadmitir recurso especial e devem ser verificadas em toda
peça de recurso especial ANTES da redação, conforme já indicado em
`roteamento.md`.

---

## Domínio B — Direito do Consumidor

Súmula 130 — A empresa responde, perante o cliente, pela reparação de
dano ou furto de veículo ocorridos em seu estacionamento.

Súmula 297 — O Código de Defesa do Consumidor é aplicável às instituições
financeiras.

Súmula 302 — É abusiva a cláusula contratual de plano de saúde que limita
no tempo a internação hospitalar do segurado.

Súmula 362 — A correção monetária do valor da indenização do dano moral
incide desde a data do arbitramento.

Súmula 379 — Nos contratos bancários não regidos por legislação
específica, os juros moratórios poderão ser convencionados até o limite
de 1% ao mês.

Súmula 381 — Nos contratos bancários, é vedado ao julgador conhecer, de
ofício, da abusividade das cláusulas.

Súmula 382 — A estipulação de juros remuneratórios superiores a 12% ao
ano, por si só, não indica abusividade.

Súmula 385 — Da anotação irregular em cadastro de proteção ao crédito,
não cabe indenização por dano moral, quando preexistente legítima
inscrição, ressalvado o direito ao cancelamento.

**Nota de estratégia (385):** o STJ tem mitigado esta súmula quando a(s)
inscrição(ões) anterior(es) também é(são) objeto de impugnação judicial,
desde que haja elementos de verossimilhança (ex.: REsp 1.704.002/SP) —
sempre confirmar o estado atual da jurisprudência antes de aplicar a
súmula contra o cliente-consumidor.

Súmula 532 — Constitui prática comercial abusiva o envio de cartão de
crédito sem prévia e expressa solicitação do consumidor, configurando-se
ato ilícito indenizável e sujeito à aplicação de multa administrativa.

Súmula 675 — É legítima a atuação dos órgãos de defesa do consumidor na
aplicação de sanções administrativas previstas no CDC quando a conduta
praticada ofender direito consumerista, o que não exclui nem inviabiliza
a atuação do órgão ou entidade de controle quando a atividade é regulada.

---

## Domínio A — Direito Imobiliário / Posse / Usucapião

Súmula 84 — É admissível a oposição de embargos de terceiro fundados em
alegação de posse advinda do compromisso de compra e venda de imóvel,
ainda que desprovido do registro.

Súmula 364 — O conceito de impenhorabilidade de bem de família abrange
também o imóvel pertencente a pessoas solteiras, separadas e viúvas.

Súmula 375 — O reconhecimento da fraude à execução depende do registro
da penhora do bem alienado ou da prova de má-fé do terceiro adquirente.

**Nota:** a Súmula 84 (posse via compromisso não registrado) e a Súmula
375 (fraude à execução) formam o par de fundamentos mais citado em
embargos de terceiro envolvendo imóveis — sempre verificar ambas em
conjunto.

---

## Domínio E — Família e Sucessões

Súmula 309 — O débito alimentar que autoriza a prisão civil do
alimentante é o que compreende as três prestações anteriores à citação
e as que vencerem no curso do processo.

Súmula 358 — O cancelamento de pensão alimentícia de filho que atingiu a
maioridade está sujeito à decisão judicial, mediante contraditório,
ainda que nos próprios autos.

Súmula 594 — O Ministério Público tem legitimidade ativa para ajuizar
ação de alimentos em proveito de criança ou adolescente,
independentemente do exercício do poder familiar dos pais, ou do fato de
o menor se encontrar nas situações de risco descritas no art. 98 do
Estatuto da Criança e do Adolescente, ou de quaisquer outros
questionamentos acerca da existência ou eficiência da Defensoria Pública
na comarca.

Súmula 596 — A obrigação alimentar dos avós tem natureza complementar e
subsidiária, somente se configurando no caso de impossibilidade total ou
parcial de seu cumprimento pelos pais.

---

## Como Expandir Este Arquivo

1. Nunca adicionar súmula sem confirmar o texto oficial em fonte
   verificável (site do STJ, base de jurisprudência ou publicação
   reconhecida) — não reproduzir de memória;
2. Ao adicionar, indicar o domínio (A–G) a que a súmula pertence, no
   mesmo padrão de organização acima;
3. Quando uma súmula tiver sido mitigada/superada por jurisprudência
   posterior (como a 385), registrar a ressalva junto ao enunciado;
4. Domínios F (remédios constitucionais) e G (mandado de segurança) ainda
   não têm súmulas específicas do STJ verificadas neste arquivo — as
   súmulas do STF relevantes a esses domínios já constam em
   `mandado_seguranca.md` e `remedios-constitucionais.md`. Adicionar aqui
   apenas quando houver súmula do STJ (não do STF) especificamente
   verificada para esses domínios.
