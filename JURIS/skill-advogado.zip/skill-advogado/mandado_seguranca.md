# Minuta: Mandado de Segurança (MS)

## Código: MS | Lei 12.016/2009 + Art. 5º, LXIX e LXX, CF/1988

---

## Mapa Conceitual Obrigatório — Leia Antes de Redigir

### Conceito e Cabimento

| Elemento | Conteúdo | Fundamento |
|---|---|---|
| Objeto | Proteger direito líquido e certo, não amparado por habeas corpus ou habeas data | Art. 1º, caput, Lei 12.016/09 |
| Direito líquido e certo | Fato incontroverso, comprovável de plano por prova pré-constituída (documental) — não admite dilação probatória | Doutrina consolidada |
| Requisito do ato | Ilegalidade ou abuso de poder por parte de autoridade | Art. 1º, caput |
| Autoridade coatora | Qualquer categoria/função, inclusive representantes de partidos políticos, administradores de autarquias e dirigentes de pessoas jurídicas/pessoas naturais no exercício de atribuições do poder público | Art. 1º, §1º |
| Vedação | Não cabe contra atos de gestão comercial de empresas públicas, sociedades de economia mista e concessionárias de serviço público | Art. 1º, §2º |
| Litisconsórcio ativo | Quando o direito couber a várias pessoas, qualquer uma pode impetrar | Art. 1º, §3º |
| MS por direito de terceiro | Titular pode impetrar a favor de direito originário de terceiro que não o fizer em 30 dias após notificação judicial | Art. 3º |

### Modalidades

| Modalidade | Quando usar | Prazo decadencial |
|---|---|---|
| Repressivo | Ato lesivo já praticado | 120 dias (art. 23) |
| Preventivo | Ameaça concreta e iminente de lesão a direito líquido e certo | Não há prazo decadencial (ato ainda não ocorreu) |
| Individual | Pessoa física ou jurídica, em nome próprio | Lei 12.016/09, arts. 1º a 15 |
| Coletivo | Partido político com representação no Congresso, organização sindical, entidade de classe ou associação legalmente constituída há mais de 1 ano, em defesa de interesses de seus membros/associados | Art. 21, Lei 12.016/09 |

### Hipóteses de NÃO Cabimento (Art. 5º)

- I — Ato do qual caiba recurso administrativo **com efeito suspensivo**, independentemente de caução;
- II — Decisão judicial da qual caiba recurso **com efeito suspensivo**;
- III — Decisão judicial transitada em julgado;
- Lei em tese — ato normativo geral e abstrato sem efeitos concretos (Súmula 266, STF), salvo MS coletivo quando os efeitos já incidem sobre categoria determinada;
- Não substitui ação de cobrança (Súmula 269, STF) — não serve para reaver valores pretéritos, apenas para assegurar o exercício do direito daqui em diante;
- Os efeitos patrimoniais pretéritos ao ajuizamento devem ser pleiteados em via própria (Súmula 271, STF) — a concessão do MS não retroage para pagar atrasados, somente ação própria de cobrança;
- Denegado o MS por decisão transitada em julgado, não cabe reiterar novo MS com o mesmo objeto (Súmula 304, STF).

**Checklist de cabimento antes de prosseguir:**
1. O direito é líquido e certo (prova documental pré-constituída, sem necessidade de dilação probatória)?
2. Existe recurso administrativo ou judicial com efeito suspensivo cabível contra o ato? Se sim, MS incabível.
3. O ato foi praticado por autoridade pública (ou equiparada) no exercício de função pública?
4. Trata-se de ato concreto (não lei em tese)?
5. Não há decisão transitada em julgado sobre o mesmo objeto?

### Legitimidade

| Polo | Quem | Observação |
|---|---|---|
| Ativo | Pessoa física ou jurídica titular do direito líquido e certo | Inclui MS coletivo (art. 21) |
| Passivo | Autoridade coatora | Deve-se indicar a autoridade E a pessoa jurídica a que está vinculada (art. 6º) |
| Litisconsorte passivo necessário | Pessoa jurídica de direito público interessada | Deve ser cientificada para ingressar no feito (art. 7º, II) |
| Fiscal da lei | Ministério Público | Intimado para manifestação antes da sentença — custos legis (art. 12) |

### Competência

- Autoridade **federal**: quando as consequências patrimoniais do ato houverem de ser suportadas pela União ou entidade por ela controlada (art. 2º) → Justiça Federal;
- Autoridade **estadual/municipal**: Justiça Estadual, conforme a organização judiciária local;
- Autoridade com foro por prerrogativa de função: observar a competência originária de tribunal (TJ, TRF, STJ ou STF), conforme a hierarquia da autoridade coatora.

---

## Checklist Pré-Redação (Coleta de Dados Obrigatória)

1. Qualificação completa do impetrante (nome, CPF/CNPJ, endereço, e-mail);
2. Identificação precisa da autoridade coatora (cargo e nome, se souber) **e** da pessoa jurídica a que está vinculada;
3. Descrição objetiva e cronológica do ato coator (data, forma de ciência inequívoca, conteúdo);
4. Documentação que comprove o direito líquido e certo (prova pré-constituída — sem essa prova, o MS não é a via adequada);
5. Data em que o impetrante teve ciência inequívoca do ato (para contagem do prazo decadencial de 120 dias, se repressivo);
6. Verificação de cabimento de recurso administrativo/judicial com efeito suspensivo (se houver, MS incabível — art. 5º);
7. Existência de urgência que justifique liminar (relevância do fundamento + risco de ineficácia da medida final);
8. Se coletivo: comprovação de legitimidade da entidade impetrante (ata de fundação, mais de 1 ano de constituição, pertinência temática);
9. Valor da causa (estimado, quando não houver conteúdo econômico definido, ou o valor do proveito econômico pretendido).

---

## Estrutura Obrigatória da Peça

```
EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO DA [X]ª VARA
[DA FAZENDA PÚBLICA / CÍVEL / FEDERAL] DA COMARCA/SEÇÃO JUDICIÁRIA DE [CIDADE/UF]

[Distribuição por dependência a: processo nº XXXXX, se houver]

[NOME DO IMPETRANTE], [nacionalidade], [estado civil], [profissão], portador(a)
do CPF/CNPJ nº [XXX], residente/sediado(a) em [ENDEREÇO COMPLETO], e-mail
[E-MAIL], por seu(ua) advogado(a) que esta subscreve (procuração anexa,
doc. 01), vem, respeitosamente, à presença de Vossa Excelência, impetrar o
presente

MANDADO DE SEGURANÇA
[COM PEDIDO DE LIMINAR]

em face de ato praticado por [CARGO E NOME DA AUTORIDADE COATORA], vinculado(a)
a [PESSOA JURÍDICA DE DIREITO PÚBLICO/PRIVADO A QUE A AUTORIDADE INTEGRA],
com endereço em [ENDEREÇO DA AUTORIDADE, PARA NOTIFICAÇÃO], pelos fatos e
fundamentos jurídicos a seguir expostos.

I — DOS FATOS

Em [DATA], o(a) impetrante [DESCREVER O ATO COATOR: o que foi negado,
determinado ou omitido pela autoridade, com data e forma de ciência
inequívoca].

[Narrar cronologicamente os fatos que antecederam o ato impugnado, indicando
os documentos que comprovam cada afirmação — doc. 0X].

O ato impugnado consiste em: [DESCREVER O ATO COM PRECISÃO: portaria, ofício,
decisão administrativa, omissão etc., com número/data/órgão].

II — DO DIREITO

a) Do cabimento do mandado de segurança

O ato impugnado é ilegal/abusivo porque [FUNDAMENTAR EM FACE DA NORMA
VIOLADA], nos termos do art. 1º, caput, da Lei 12.016/2009. Trata-se de
direito líquido e certo, comprovado de plano pelos documentos anexos
(docs. 0X), prescindindo de dilação probatória.

Não há, contra o ato impugnado, recurso administrativo ou judicial dotado
de efeito suspensivo, tampouco decisão transitada em julgado sobre o mesmo
objeto, de modo que inexiste óbice do art. 5º da Lei 12.016/2009.

b) Do direito líquido e certo violado

[Desenvolver a tese de mérito: a norma (lei, decreto, regulamento,
princípio constitucional) que assegura o direito, e como o ato da
autoridade a violou. Citar jurisprudência do STJ/STF pertinente ao tema
específico, sempre confirmando o teor exato da tese antes de citar.]

c) Da tempestividade

O impetrante teve ciência inequívoca do ato em [DATA], estando o presente
mandamus impetrado dentro do prazo decadencial de 120 (cento e vinte) dias
previsto no art. 23 da Lei 12.016/2009 [ou: tratando-se de mandado de
segurança preventivo, não há prazo decadencial a observar, ante a mera
ameaça de lesão a direito líquido e certo].

III — DA LIMINAR [se cabível]

Presentes os requisitos do art. 7º, III, da Lei 12.016/2009:

(i) Relevância do fundamento: [demonstrar a plausibilidade do direito —
    fumus boni iuris — com base na prova documental e na tese jurídica
    exposta];

(ii) Risco de ineficácia da medida ao final: [demonstrar que, sem a
     liminar, a demora do processo tornará inócua a tutela pretendida —
     periculum in mora].

Requer-se, assim, a concessão de LIMINAR, inaudita altera parte, para
determinar que a autoridade coatora [DESCREVER A PROVIDÊNCIA IMEDIATA
PRETENDIDA], sob pena de multa diária de R$ [VALOR], até decisão final.

IV — DOS PEDIDOS

Ante o exposto, requer-se:

a) A concessão de MEDIDA LIMINAR, inaudita altera parte, para [PROVIDÊNCIA
   IMEDIATA], nos termos do art. 7º, III, da Lei 12.016/2009;

b) A notificação da autoridade coatora para, no prazo de 10 (dez) dias,
   prestar as informações que entender necessárias (art. 7º, I);

c) A ciência do feito ao órgão de representação judicial da pessoa
   jurídica interessada, para que, querendo, ingresse no feito (art. 7º, II);

d) A intimação do Ministério Público para manifestação, na qualidade de
   fiscal da ordem jurídica (art. 12);

e) Ao final, a CONCESSÃO DEFINITIVA DA SEGURANÇA, confirmando a liminar,
   para o fim de [PEDIDO DE MÉRITO DEFINITIVO E ESPECÍFICO];

f) A concessão dos benefícios da justiça gratuita, nos termos da Lei
   1.060/1950 e art. 98 do CPC [se aplicável];

g) A dispensa de condenação em honorários advocatícios e do cabimento de
   embargos infringentes, nos termos do art. 25 da Lei 12.016/2009.

Dá-se à causa o valor de R$ [VALOR] ([por extenso]).

Termos em que,
Pede deferimento.

[Cidade/UF], [data].

[NOME DO ADVOGADO]
OAB/[UF] nº [NÚMERO]
```

---

## Documentos que devem acompanhar a inicial

- [ ] Procuração com poderes específicos
- [ ] Cópia do ato impugnado (portaria, ofício, decisão, notificação)
- [ ] Prova documental pré-constituída do direito líquido e certo (não admite prova testemunhal ou pericial em MS)
- [ ] Comprovante da data de ciência inequívoca do ato (para contagem do prazo decadencial)
- [ ] Comprovante de recolhimento de custas ou pedido de justiça gratuita
- [ ] Se MS coletivo: ato constitutivo da entidade, comprovando mais de 1 ano de existência e pertinência temática
- [ ] Cópia em 2 (duas) vias, com os documentos reproduzidos em ambas (art. 6º), quando exigido pelo juízo/protocolo físico

## Checklist de Validação Final

- [ ] Direito comprovado exclusivamente por prova documental pré-constituída, sem necessidade de dilação probatória
- [ ] Autoridade coatora corretamente identificada (cargo/nome) e pessoa jurídica vinculada indicada
- [ ] Nenhuma hipótese do art. 5º (recurso c/ efeito suspensivo pendente, coisa julgada) incide sobre o caso
- [ ] Prazo decadencial de 120 dias verificado e observado (se repressivo) ou justificada a natureza preventiva (se não houver prazo)
- [ ] Liminar fundamentada nos dois requisitos cumulativos do art. 7º, III (relevância do fundamento + risco de ineficácia)
- [ ] Pedido de notificação da autoridade (art. 7º, I) e ciência à pessoa jurídica interessada (art. 7º, II) presentes
- [ ] Pedido de intimação do Ministério Público (art. 12) presente
- [ ] Pedido de dispensa de honorários e embargos infringentes (art. 25) presente
- [ ] Se coletivo: legitimidade da entidade demonstrada (mais de 1 ano de constituição + pertinência temática)
- [ ] Valor da causa compatível com o proveito econômico pretendido, quando houver

## Referências Legais Consolidadas — MS

| Dispositivo | Conteúdo |
|---|---|
| Art. 5º, LXIX, CF/88 | Cabimento do mandado de segurança individual |
| Art. 5º, LXX, CF/88 | Cabimento do mandado de segurança coletivo |
| Lei 12.016/2009 | Lei do Mandado de Segurança (disciplina individual e coletivo) |
| Art. 1º, caput e §§1º-3º | Conceito, autoridade equiparada, vedação a atos de gestão comercial, litisconsórcio ativo |
| Art. 2º | Critério de competência federal |
| Art. 3º | Impetração por direito de terceiro |
| Art. 5º, I-III | Hipóteses de não cabimento |
| Art. 6º | Requisitos da petição inicial |
| Art. 7º, I-III e §§ | Notificação, ciência ao órgão de representação, liminar (relevância + ineficácia) |
| Art. 10 | Indeferimento liminar da inicial |
| Art. 12 | Intervenção do Ministério Público (custos legis) |
| Art. 14 | Sentença concessiva sujeita a reexame necessário |
| Art. 21 | Mandado de segurança coletivo — legitimidade |
| Art. 23 | Prazo decadencial de 120 dias (repressivo) |
| Art. 25 | Vedação a condenação em honorários e a embargos infringentes |
| Súmula 266, STF | Não cabe MS contra lei em tese |
| Súmula 269, STF | MS não é substitutivo de ação de cobrança |
| Súmula 271, STF | Concessão de MS não produz efeitos patrimoniais pretéritos — via própria |
| Súmula 304, STF | Decisão denegatória transitada em julgado impede reiteração do mesmo MS |
| Súmula 512, STF | Não cabe condenação em honorários advocatícios em MS |
