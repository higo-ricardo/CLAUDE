> ⚠️ NOTA DE ROTEAMENTO: este arquivo cobre apenas o código REP (réplica à
> contestação em fase processual/D2). Os códigos ALV (Expedição de Alvará) e
> CPS (Cumprimento de Sentença) — apesar de listados no cabeçalho do domínio
> D2 em `roteamento.md` — já possuem minuta completa em
> `minutas-intermediariais.md` e NÃO devem ser duplicados aqui. Consulte
> `minutas-intermediariais.md` para ALV e CPS.

# Minuta: Réplica à Contestação (REP)

## Código: REP | Arts. 350, 351 e 337, CPC/2015 | Domínio D2 — Intermediários processuais

---

## Distinção Fundamental

| Código | Contexto | Reside em |
|---|---|---|
| REP-C | Réplica em ações cíveis específicas do Domínio C (ATR, ALU, DEM) | `minutas-civeis.md` |
| REP | Réplica genérica à contestação, fase de saneamento (qualquer domínio) | Este arquivo |

Não confundir os dois códigos — se o processo já foi roteado para um dos
domínios C (ATR/ALU/DEM), use `minutas-civeis.md`. Este arquivo (REP) é o
modelo genérico de réplica, usado quando o processo não se enquadra nos
domínios com minuta própria de réplica.

## Mapa Conceitual Obrigatório — Leia Antes de Redigir

### Natureza e Momento Processual

- A réplica é manifestação do autor **posterior à contestação**, na fase de
  providências preliminares e saneamento do processo (Livro I, Título I,
  Capítulo VI, CPC/2015);
- É **facultativa** quanto à forma, mas **obrigatória a intimação** do autor
  sempre que a contestação trouxer matéria que exija manifestação, sob pena
  de violação ao contraditório e preclusão da oportunidade de impugnar;
- Prazo: **15 (quinze) dias**, contados da intimação da contestação
  (arts. 350 e 351, CPC);
- **Vedação**: a réplica não pode deduzir pedido novo, nem alterar a causa
  de pedir — deve se limitar a impugnar especificamente o que foi alegado
  na contestação (ônus da impugnação especificada, art. 341, CPC).

### Quando a Réplica é Necessária

| Situação | Fundamento | O que fazer na réplica |
|---|---|---|
| Réu alega fato impeditivo, modificativo ou extintivo do direito do autor (ex.: pagamento, prescrição, decadência, novação, compensação) | Art. 350, CPC | Impugnar especificamente cada fato novo, indicando prova em contrário |
| Réu argui preliminar do art. 337 (incompetência, inépcia, ilegitimidade, litispendência, coisa julgada, convenção de arbitragem, incorreção do valor da causa, gratuidade indevida etc.) | Art. 351, CPC | Rebater cada preliminar, demonstrando sua improcedência, para evitar extinção do processo sem resolução de mérito |
| Réu junta documentos novos com a contestação | Art. 437, §1º, CPC (por analogia ao contraditório sobre prova documental) | Manifestar-se sobre a autenticidade e o conteúdo dos documentos juntados |
| Réu formula reconvenção | Arts. 343 e 702, §6º, CPC | Réplica à reconvenção é peça própria — mencionar que reconvenção será respondida em peça apartada, se for o caso |

### Rol de Preliminares do Art. 337 (para identificar o que a réplica deve rebater)

I — inexistência ou nulidade da citação; II — incompetência absoluta e
relativa; III — incorreção do valor da causa; IV — inépcia da petição
inicial; V — perempção; VI — litispendência; VII — coisa julgada;
VIII — conexão; IX — incapacidade da parte, defeito de representação ou
falta de autorização; X — convenção de arbitragem; XI — ausência de
legitimidade ou de interesse processual; XII — falta de caução ou de outra
prestação que a lei exige como preliminar; XIII — indevida concessão do
benefício de gratuidade de justiça.

**Observação de estratégia**: incompetência relativa não alegada em
contestação preclui; incompetência absoluta pode ser conhecida de ofício a
qualquer tempo — a réplica pode e deve reforçar a preclusão quando cabível.

---

## Checklist Pré-Redação (Coleta de Dados Obrigatória)

1. Número do processo e vara/juízo;
2. Cópia da contestação apresentada pelo réu (íntegra);
3. Mapeamento de **todas** as preliminares arguidas (art. 337) — o
   `advogado` deve concluir esse mapeamento ANTES de delegar ao
   `estagiario`; não delegar réplica sem briefing completo (ver
   `roteamento.md`);
4. Mapeamento de **cada** tese de mérito (fato impeditivo, modificativo ou
   extintivo) levantada na contestação;
5. Documentos juntados pelo réu com a contestação, para eventual
   impugnação de autenticidade/conteúdo;
6. Prova que o autor pretende produzir para rebater cada alegação (arts.
   350 e 351 autorizam produção de prova nesta fase);
7. Data de intimação da contestação, para contagem do prazo de 15 dias;
8. Verificar se há reconvenção — se houver, tratar em peça apartada.

---

## Estrutura Obrigatória da Peça

```
EXCELENTÍSSIMO(A) SENHOR(A) DOUTOR(A) JUIZ(A) DE DIREITO DA [X]ª VARA
[CÍVEL/DE FAMÍLIA/EMPRESARIAL] DA COMARCA DE [CIDADE/UF]

Processo nº [NÚMERO]

[NOME DO AUTOR], já qualificado(a) nos autos do processo em epígrafe, por
seu(ua) advogado(a) que esta subscreve, vem, respeitosamente, à presença de
Vossa Excelência, apresentar

RÉPLICA À CONTESTAÇÃO

nos termos dos arts. 350 e 351 do Código de Processo Civil, pelas razões a
seguir expostas.

I — SÍNTESE DA CONTESTAÇÃO

O réu, em sua contestação (ID [XXX]), arguiu as seguintes preliminares:
[LISTAR CADA PRELIMINAR, com o inciso do art. 337 correspondente].

No mérito, sustentou: [LISTAR CADA TESE DE MÉRITO, indicando se se trata
de fato impeditivo, modificativo ou extintivo do direito do autor].

II — DAS PRELIMINARES (ART. 337 c/c ART. 351, CPC)

[Para cada preliminar arguida, em item próprio:]

a) Da [nome da preliminar, ex.: "incompetência relativa do juízo"]

O réu sustenta [SÍNTESE DO ARGUMENTO DO RÉU]. Sem razão, contudo, uma vez
que [FUNDAMENTAÇÃO ESPECÍFICA REBATENDO A PRELIMINAR, com base legal e,
se pertinente, jurisprudência do STJ sobre o tema — confirmar o teor exato
antes de citar].

[Repetir para cada preliminar arguida.]

III — DO MÉRITO — IMPUGNAÇÃO ESPECIFICADA (ART. 341, CPC)

a) Do fato [impeditivo/modificativo/extintivo] alegado: [DESCRIÇÃO]

O réu alega que [SÍNTESE]. Tal alegação não procede, pois [IMPUGNAÇÃO
ESPECÍFICA COM BASE NOS FATOS E NA PROVA JÁ CONSTANTE DOS AUTOS OU A SER
PRODUZIDA].

[Repetir para cada fato novo trazido pela contestação.]

b) Dos documentos juntados pelo réu

Quanto aos documentos acostados à contestação (docs. [XXX]),
[MANIFESTAR-SE SOBRE AUTENTICIDADE E CONTEÚDO — impugnar especificamente
o que não corresponder à verdade, sob pena de presunção de veracidade].

IV — DA PRODUÇÃO DE PROVAS

O autor requer a produção das seguintes provas, para o fim de infirmar as
alegações da contestação: [PROVA DOCUMENTAL COMPLEMENTAR / PERICIAL /
TESTEMUNHAL — justificar a pertinência de cada uma em relação aos fatos
controvertidos].

V — DOS PEDIDOS

Ante o exposto, requer-se:

a) O AFASTAMENTO de todas as preliminares arguidas pelo réu, pelos motivos
   expostos no item II;

b) A REJEIÇÃO integral das teses de mérito (fatos impeditivos, modificativos
   ou extintivos) apresentadas na contestação, nos termos do item III;

c) A produção das provas requeridas no item IV;

d) O prosseguimento do feito, com a designação de audiência de instrução
   e julgamento [se necessária] ou o julgamento antecipado do mérito,
   nos termos do art. 355, CPC [se a matéria for exclusivamente de direito
   ou não houver necessidade de outras provas];

e) Ao final, a PROCEDÊNCIA integral dos pedidos formulados na petição
   inicial, com a condenação do réu ao pagamento das custas processuais e
   honorários advocatícios.

Termos em que,
Pede deferimento.

[Cidade/UF], [data].

[NOME DO ADVOGADO]
OAB/[UF] nº [NÚMERO]
```

---

## Checklist de Validação Final (REP)

- [ ] Todas as preliminares do art. 337 arguidas na contestação foram identificadas e rebatidas uma a uma
- [ ] Todos os fatos impeditivos, modificativos ou extintivos (art. 350) foram impugnados especificamente (art. 341) — nenhum ponto da contestação ficou sem resposta
- [ ] Nenhum pedido novo foi formulado, nem a causa de pedir foi alterada (vedação implícita ao objeto da réplica)
- [ ] Documentos juntados pelo réu foram objeto de manifestação expressa
- [ ] Provas pertinentes para rebater as novas alegações foram requeridas e justificadas
- [ ] Prazo de 15 dias contado corretamente a partir da intimação da contestação
- [ ] Se houver reconvenção, foi tratada em peça apartada (não confundida com a réplica)
- [ ] Se o processo pertencer aos domínios C (ATR/ALU/DEM), verificar se não deveria ter sido usado REP-C em `minutas-civeis.md` em vez deste

## Referências Legais Consolidadas — REP

| Dispositivo | Conteúdo |
|---|---|
| Art. 337, I-XIII, CPC | Rol das preliminares que o réu deve alegar na contestação |
| Art. 341, CPC | Ônus da impugnação especificada pelo autor/réu |
| Art. 342, CPC | Alegações supervenientes admitidas fora da fase inicial |
| Art. 343 e 702, §6º, CPC | Reconvenção — tratamento em peça apartada |
| Art. 350, CPC | Réplica sobre fato impeditivo, modificativo ou extintivo — prazo 15 dias, com produção de prova |
| Art. 351, CPC | Réplica sobre preliminares do art. 337 — prazo 15 dias, com produção de prova |
| Art. 355, CPC | Julgamento antecipado do mérito, quando não houver necessidade de outras provas |
| Art. 357, CPC | Decisão de saneamento e organização do processo, etapa subsequente à réplica |
