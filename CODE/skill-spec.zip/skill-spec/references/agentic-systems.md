# Padrões para sistemas agênticos (multiagente / handoffs / tools)

Leia quando o projeto usa framework de agentes — o **modelo decide o fluxo**
(quais tools chamar, quando delegar), não um orquestrador Python fixo. Muda
principalmente: ADRs da etapa Backend/Frontend (2.4/2.5), Modelagem de
Código (seção 8) e, com UI de streaming, o resumo de Design e UX (seção 6).

Identifique o framework (pergunte se não estiver claro). Não listado: use
"Padrão genérico" — os princípios valem para qualquer SDK com tools +
handoffs.

---

## ADRs típicos de sistemas agênticos (adapte, não copie cego)

Checklist do que perguntar, não texto pronto:

- Qual SDK/framework é a **única camada de orquestração** (nenhum loop
  manual de fases em Python).
- Onde o client do provedor é isolado (um módulo — resto do app nunca
  importa o SDK diretamente).
- Múltiplos provedores (NVIDIA/OpenRouter/OpenAI/Gemini via mesma
  interface): como a compatibilidade é resolvida.
- Tools locais vs. hospedadas pela plataforma — e por quê.
- Múltiplos agentes: como a delegação acontece (handoff nativo, roteamento
  manual, grafo de estados) e por que essa topologia.
- Quem publica eventos de observabilidade — tools nunca publicam
  diretamente; o orquestrador observa o stream.
- Limite de turnos/iterações (`MAX_TURNOS`) contra loop infinito.
- "Thinking"/reasoning nativo: como é exposto, e o fallback (scratchpad
  como tool) quando o SDK não expõe.
- Fonte de verdade de configuração (`.env` ou equivalente).
- Timeout/instabilidade de transporte conhecida (ex.: HTTP/2 em POSTs longos).
- Se handoffs são o padrão, reconstrução de histórico (`to_input_list()`) é
  **só** para retomar execução, não para decidir o próximo passo.

---

## OpenAI Agents SDK (`openai-agents`)

- **Núcleo agêntico**: `Agent`, `Runner`, `function_tool`, `handoff`,
  `stream_run` — nenhum loop manual de fases.
- **Isolamento do client**: `openai` só é importado no módulo de provedor.
- **Multi-provedor**: se não fala Responses API (NVIDIA, OpenRouter), usar
  `set_default_openai_api("chat_completions")` + `OpenAIChatCompletionsModel`
  com `base_url` customizado.
- **Tools locais vs. hospedadas**: `@function_tool` roda no processo;
  tools hospedadas (`WebSearchTool`, `FileSearchTool`, `CodeInterpreterTool`)
  exigem Responses API — sem suporte, vira ADR explícito. `ComputerTool` só
  entra com automação de navegador real.
- **Handoffs nativos**: cada agente foca uma etapa; `result.last_agent`
  rastreia a delegação (ex.: Triagem → Execução → Redação).
- **Eventos**: tools nunca publicam — o orquestrador observa `stream_run`
  (`item.raw_response`) e traduz em eventos de domínio.
- **Estado incremental**: tool "salvar fato" que só persiste no contexto
  injetado (`RunContextWrapper`) — nunca instancia modelo nem publica evento.
- **Memória limitada**: janela deslizante + compactação determinística e
  teto de caracteres — nunca lista ilimitada ao modelo.
- **Validação de output em ponto único**: a tool final rejeita com erro se
  inválido (autocorreção nativa) — sem guardrail redundante em paralelo.
- **Thinking/reasoning**: `reasoning_content` via subclasse do wrapper
  (`extra_body`); sem reasoning nativo, tool "raciocinar" (scratchpad
  agnóstico).
- **Orçamento**: `MAX_TURNOS`, `TOKEN_MAXIMO_TOTAL` checados a cada turno
  pelo orquestrador.
- **Retomada**: estado persistido (tópico, plano, fatos, turno, trilha);
  reconstrua o histórico e passe ao **mesmo agente** — único uso legítimo
  de `to_input_list()`.
- **Conteúdo externo**: tool que devolve web/PDF exige regra explícita no
  agente consumidor tratando isso como dado, nunca instrução.

---

## Google ADK / Gemini SDK

Mesmos princípios do OpenAI Agents SDK acima, com este vocabulário:

- **Núcleo**: `Agent`/`LlmAgent`, `Runner`, `FunctionTool`, sessões
  (`Session`/`SessionService`) — evite reimplementar gestão de sessão.
- **Isolamento**: `google-genai`/`google-generativeai` isolado num módulo
  de provedor.
- **Multiagente**: sub-agentes via `sub_agents` + `transfer_to_agent`;
  documente a topologia como ADR.
- **Tools**: funções decoradas viram `FunctionTool` da assinatura +
  docstring — a docstring é o contrato, trate como parte da spec.
- **Eventos**: via `Runner.run`/`run_async` (`Event` com conteúdo, function
  calls/responses) — mesmo padrão "orquestrador observa e traduz".
- **Grounding/tools hospedadas** (`google_search` etc.): ADR de dependência
  de infraestrutura do provedor.
- **Streaming/thinking**: mesma captura do padrão OpenAI.
- **Orçamento**: turnos e tokens checados no orquestrador/runner.

---

## Padrão genérico (LangGraph, CrewAI, AutoGen, ou framework próprio)

1. **Uma única camada de orquestração agêntica** — nenhum `if/else` de
   fases fixas competindo com a decisão do modelo/grafo.
2. **Isolamento do client do provedor** em um módulo só.
3. **Tools/nodes com responsabilidade única**, sem publicar eventos — o
   observador central traduz execução em eventos de domínio.
4. **Delegação/transição de estado rastreável** (equivalente a
   `result.last_agent`).
5. **Limite de iterações/turnos** contra loop infinito.
6. **Ponto único de validação de output final**, erro devolvido ao modelo
   em vez de guardrail duplicado.
7. **Memória/contexto com teto explícito** (janela + compactação).
8. **Conteúdo externo tratado como dado, nunca instrução**.

Framework fora da lista: pesquise a terminologia própria do SDK ("agente",
"tool", "handoff", "sessão") e use nos ADRs — não force o vocabulário do
OpenAI Agents SDK em outro framework.
