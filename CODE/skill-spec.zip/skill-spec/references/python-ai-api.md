# Padrões para projetos Python com API de IA direta (sem framework de agentes)

Leia quando o projeto chama uma API de LLM diretamente (`openai`,
`anthropic`, `google-genai`) para completions, function calling ou
streaming — **sem** framework de orquestração de agentes (sem handoffs, sem
múltiplos agentes decidindo o fluxo). O fluxo é decidido por código Python
normal, mesmo com structured output ou function calling dentro de uma
função.

Mais simples que `agentic-systems.md` — não force ADRs de
handoff/multiagente se o projeto é, na prática, "chamar a API dentro de uma
função e usar o resultado".

---

## ADRs típicos deste tipo de projeto (etapa Backend, seção 2.5)

- Isolamento do client (`OpenAI()`, `Anthropic()`) em um único módulo —
  troca de provedor ou mock em teste sem tocar em lógica de negócio.
- Modelo e parâmetros (temperatura, max_tokens) como configuração central,
  nunca hardcoded espalhado.
- **Structured output** (JSON mode, `response_format`, tool use forçado):
  schema Pydantic no output — rejeitar e re-perguntar vs. reparar
  programaticamente.
- **Function calling**: onde tools são declaradas, e se a escolha da tool é
  sempre do modelo ou o código força uma chamada específica.
- **Streaming vs. resposta completa**: por que um ou outro por endpoint.
- Retry/backoff em erros transitórios (rate limit, 5xx) — exponencial, com
  teto, diferenciando transitório de definitivo.
- Orçamento de tokens/custo por requisição ou sessão, se relevante.
- Onde fica o prompt do sistema (template vs. string inline).

Exemplo de linha real na tabela do ADR (subseção 2.5 Backend):

```markdown
| ADR-N | Retry exponencial (1s/2s/4s) com teto de 3 tentativas, só para erros 429/5xx | Erros 4xx (exceto 429) são definitivos — retentar só mascara o problema e queima orçamento de tempo |
```

---

## Seções que costumam mudar no template

### RF (seção 3) e NFR (seção 4)

```markdown
| NFR | Descrição |
|---|---|
| **Confiabilidade de output** | Taxa de erro de parsing de structured output < 2% em 100 chamadas |
| **Latência** | P95 do primeiro chunk de streaming < 1.5s |
| **Custo** | Custo médio por sessão ≤ <valor>, com corte de contexto se ultrapassar |
```

### Modelagem de Código (seção 8, plano `<slug>-code-model.md`)

O schema Pydantic do structured output entra em "Entidades/Schemas" do
plano de código — é contrato de validação, não dado persistido; só vai
para Modelagem de Dados se o projeto também persiste essas respostas.

Funções que chamam IA são um método comum na tabela "Métodos Centrais" —
regra usual: "não faz retry por conta própria — isso é do wrapper de
client".

**Comportamento e erros** (em "Ordem de Implementação"):

- Diferencie erro transitório (retry com backoff) de definitivo (propaga
  direto: chave inválida, sem créditos, request malformado).
- Limite de tokens de contexto: corte/resumo quando o input se aproxima do
  limite.
- Resposta inválida (JSON/schema): re-perguntar ao modelo, reparar
  programaticamente, ou falhar para o usuário — escolha uma e documente
  por quê.
- Se streaming: como o consumidor recebe os chunks.

### Client de IA (ADR da etapa Backend, seção 2.5)

```markdown
| Camada | Pacote | Papel |
|---|---|---|
| **Cliente de IA** | `openai` / `anthropic` / `google-genai` | Chamadas de completion/function calling, isolado em `<módulo>` |
| **Validação de output** | `pydantic` | Parsing e validação de structured output do modelo |
```

Configuração não-óbvia do client (base_url, headers, timeout): trecho
mínimo de código junto ao ADR.

---

## O que NÃO incluir aqui (evitar over-spec)

Sem seções de handoff, múltiplos agentes, `MAX_TURNOS`, ou barramento de
eventos de raciocínio só porque o projeto usa IA — isso é de
`agentic-systems.md`, e só faz sentido com modelo controlando o fluxo entre
múltiplos passos/agentes.
