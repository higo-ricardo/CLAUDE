---
name: spec-skill
description: >
  Gera/revisa specs técnicas de software em 10 seções fixas (Visão, ADRs,
  Requisitos, Regras de Negócio e Casos de Borda, Design/UX, Arquitetura,
  Modelagem de Código e de Dados, Milestones), com planos separados
  autoexecutáveis para Design/UX, Código, Dados e Testes. Use para
  documentar arquitetura, formalizar ADRs, planejar app antes de codar,
  wireframes, modelagem de classes/dados, casos de teste. Cobre sistemas
  agênticos (OpenAI Agents SDK, Google ADK, outros) e API de IA direta
  (OpenAI/Anthropic SDK). Ativa mesmo sem a palavra "spec" — ex.: "antes de
  programar, vamos definir a arquitetura".
---

# Spec Skill

Estrutura fixa de 10 seções (template exato em `references/core-sections.md`),
com ou sem IA/agentes. ADRs (seção 2) seguem 8 etapas fixas: Onboarding,
Setup Inicial, Componentes, Frontend, Backend, API, PWA, Testes. Modelagem
de Código (seção 8) segue PEP 8 e SOLID deliberadamente.

## Por que esse formato

Uma boa spec registra **decisões** (com motivo), define contratos
verificáveis e quebra a implementação em marcos testáveis — cada seção
elimina um tipo de ambiguidade que causaria retrabalho. Planos próprios
para Design/UX, Código e Dados permitem implementar cada frente lendo só
o seu arquivo, sem a spec inteira em contexto.

## Convenções gerais

Escreva no idioma da conversa — não assuma português por padrão; siga a
convenção do projeto (código existente dita o idioma).

## Fluxo de trabalho

### 1. Entrevista em lote — no máximo duas interações

Nunca gere a spec a partir de uma frase curta, nem transforme a entrevista
em perguntas soltas. Cubra o essencial em duas interações:

1. **Texto livre, uma mensagem**: nome, objetivo (seção 1) e tecnologias
   já decididas (linguagem, frameworks, banco).
2. **Uma leva única de múltipla escolha** (`ask_user_input_v0`, até 3
   perguntas): tipo de projeto (web app/CLI/API/mobile/desktop/
   biblioteca/multiagente + é PWA?); IA/LLM (agêntico + framework, direta +
   SDK/provedor, ou nenhuma); interface visual (referência já em mente ou
   a skill propõe do zero).

Não pergunte requisitos em aberto: com o tipo de projeto conhecido, puxe
`references/rf-nfr-baseline.md` e proponha o RF/NFR já escrito e sinalizado
como inferido — o usuário edita ou remove, não lista do zero (esqueleto
pré-preenchido, etapa 4).

As respostas já determinam as etapas de ADR aplicáveis (tipo de projeto →
API/PWA; IA → agêntico/direta/nenhuma); infira direto. Só confirme quando
a resposta ficou ambígua (ex.: "tem IA" sem dizer se é agêntica).

### 2. Montar a spec seção por seção

Leia `references/core-sections.md` — template das seções, dos planos
separados e da convenção de sinalizar inferido. Antes de escrever as
seções 3 e 4, abra `references/rf-nfr-baseline.md` no tipo de projeto
identificado (ressalva de uso no próprio arquivo). Siga à risca; seção
pulada exige nota "não se aplica, porque X". Com IA, leia também o arquivo
condicional certo antes dos ADRs de Backend/Frontend e da Modelagem de
Código:

| Projeto | Leia também | Cobre |
|---|---|---|
| Sistema agêntico (handoffs, tools, multiagente) | `agentic-systems.md` | Padrões por framework: OpenAI Agents SDK, Google ADK/Gemini SDK, genérico |
| App Python com API de IA direta | `python-ai-api.md` | Client wrapper, retries, orçamento, validação de output |
| Sem IA | nenhum | `core-sections.md` sozinho já cobre tudo |

### 3. Entrega — sempre em múltiplos arquivos

A spec principal (`<slug>-spec.md`) cobre as seções 1-5, 7 e 10 por
inteiro, com resumo e ponteiro para 6, 8 e 9. Planos separados conforme o
projeto:

- `<slug>-design-ux.md` — há interface visual (seção 6).
- `<slug>-code-model.md` — modelagem não-trivial (seção 8).
- `<slug>-data-model.md` — persistência própria (seção 9).
- `<slug>-test-plan.md` — etapa 2.8 não é "não se aplica".

Sempre `.md` (`create_file`, `/mnt/user-data/outputs/`, `present_files` de
uma vez), nunca só no chat.

### 4. Construção iterativa

Esqueleto das 10 seções primeiro, já com as seções 3 e 4 preenchidas pelo
baseline da entrevista — o usuário revisa conteúdo desde a primeira
passada, não estrutura vazia. Confirme antes de preencher o restante
quando o projeto envolve IA/agêntico, PWA ou múltiplas entidades
persistidas — esqueleto errado custa caro depois; pule direto ao
preenchimento em specs simples. Gere os planos por último nesta ordem:
dados → código → design/UX → testes — dados antes de código porque as
classes de `<slug>-code-model.md` referenciam os schemas de
`<slug>-data-model.md`; testes por último por depender dos outros.

### 5. Revisão de spec existente

Leia o(s) arquivo(s), identifique o que existe e o que falta, proponha o
diff antes de reescrever — não descarte conteúdo já correto. Regrave só o
arquivo cuja seção-fonte mudou (mudança na seção 5 regrava
`<slug>-test-plan.md` por rastreamento, não `<slug>-code-model.md` se os
métodos não mudaram); nunca reescreva um plano que a mudança não toca.

## Checklist final antes de entregar

- [ ] As 10 seções presentes, na ordem — nenhuma pulada sem nota "não se aplica, porque X"
- [ ] As 8 etapas de ADR consideradas — API/PWA marcadas "não se aplica" quando for o caso
- [ ] Toda decisão de arquitetura relevante virou ADR na etapa certa
- [ ] Todo RF/NFR/Regra/Caso de Borda tem critério de aceite, com inferido vs. pedido claro
- [ ] Design/UX, Código, Dados e Testes aplicáveis viraram arquivo separado
- [ ] Árvore de arquivos detalhada só em `<slug>-code-model.md` — seção 7 tem só nível alto
- [ ] Todo caso de teste rastreia a um RF/NFR/Regra/Caso de Borda ou método
- [ ] Milestones testável (o que o usuário vê + comando de verificação + critério) e referencia os planos
- [ ] Planos autoexecutáveis — implementáveis lendo só o arquivo
- [ ] Nenhuma seção condicional (agêntica/API de IA) sem necessidade real
