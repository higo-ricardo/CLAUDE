---
name: skill-poema
description: >
  Compõe, avalia e revisa poemas em português (verso, estrofe, métrica,
  rima, musicalidade). Cobre formas fixas internacionais (soneto
  shakespeariano/petrarquiano, haicai, tanka, villanelle, limerique) e
  luso-brasileiras (redondilha, soneto camoniano, cordel, trova). Sem
  forma nomeada, compõe em formato livre com metro fixo (redondilha
  menor/maior ou decassílabo), quarteto padrão e rima sorteada. Use
  sempre que o usuário quiser escrever um poema, corrigir métrica ou
  rima, escandir versos, contar sílabas poéticas, analisar esquema de
  rima, avaliar musicalidade, checar versos pesados ou cacofonia, ou
  transformar um poema em outra forma. Ative mesmo sem termos técnicos
  — "melhora esse poema", "isso rima direito?", "poema sobre X em
  soneto", "conta as sílabas desse verso" já bastam.
---

# Oficina Poética

Uma skill para trabalhar poemas em português com o vocabulário técnico
certo (verso, estrofe, métrica, rima, musicalidade, figuras de
linguagem) sem perder de vista que tudo isso serve ao efeito do
poema — não é um fim em si. Revisar um poema não é só fazer a conta
bater; é entender o que o verso está tentando soar como, e ajustar sem
matar a voz do autor.

## Os três modos e os dois workflows

A skill tem três modos:

- **Criação** — escreve um poema novo, do zero. Não existe poema
  anterior; nada a revisar ainda.
- **Avaliação** — audita métrica, ritmo, rima, figuras de linguagem e
  vícios de leitura de um poema. Não cria nem corrige nada sozinha —
  devolve um diagnóstico, que outro modo (ou o próprio usuário) usa
  para decidir o que fazer.
- **Revisão** — trabalha em cima de um poema que **já existe** (colado
  no chat ou em arquivo). Cobre duas operações possíveis sobre esse
  poema: **corrigir** desvios (aproximando do próprio padrão do poema,
  ou de uma forma fixa que ele já deveria seguir) ou **transformar** de
  propósito (mudar forma, tom, métrica, tamanho ou registro). Nunca
  inventa um poema novo; sempre parte do que foi trazido.

Esses três modos combinam em dois workflows fixos, sempre nesta ordem:

- **Criar** = Criação → Avaliação. Escreve o rascunho, depois audita
  antes de entregar (é a Tarefa 4 do modo Criação).
- **Revisar** = Avaliação → Revisão. Audita o poema exatamente como o
  usuário trouxe, e só depois decide o que corrigir ou transformar (é
  a Tarefa V1 do modo Revisão).

Avaliação também pode ser chamada sozinha, fora dos dois workflows,
quando o usuário só pede um diagnóstico ("avalia esse poema", "esse
verso está pesado?", "tem cacofonia aqui?") sem querer criar nem
revisar nada.

Os dois arquivos de referência valem para os três modos — leia-os
antes de qualquer um:

- `references/metrica-e-rima.md` — como contar sílabas poéticas
  (sinalefa, regra da última tônica), classificação de versos e
  estrofes, tipos de rima e esquemas (com a distinção exata entre
  cruzada e alternada), figuras de linguagem, musicalidade/ritmo, e os
  vícios de linguagem que o modo Avaliação precisa flagrar (verso
  pesado, cacofonia, eco, excesso de palavras, ambiguidade não
  intencional).
- `references/formas-fixas.md` — catálogo de formas fixas (soneto
  shakespeariano, petrarquiano, camoniano, haicai, tanka, villanelle,
  limerique, rondó, e formas luso-brasileiras como redondilha, cordel,
  trova), mais a regra de formato livre (o único modo sem forma fixa
  que a skill oferece para criar do zero — não há mais opção de "verso
  livre" sem metro e sem rima no catálogo).

## Regra central: forma pedida vs. formato livre

Vale para os três modos — resolva isto antes de qualquer tarefa:

- **O usuário nomeou uma forma fixa** (soneto camoniano, haicai,
  villanelle, cordel etc.)? Abra `references/formas-fixas.md` e siga
  **à risca** a estrutura própria dela (número de versos, agrupamento,
  esquema de rima, métrica). As regras de formato livre abaixo **não
  se aplicam** — uma forma prescrita tem suas próprias regras e elas
  têm prioridade.
- **O usuário não nomeou nenhuma forma** (só pediu "um poema sobre
  X")? Em Criação, este é o modo padrão de composição, com regras
  fixas próprias:
  - **Metro:** um único metro para o poema inteiro, escolhido entre
    redondilha menor (5 sílabas), redondilha maior (7 sílabas) ou
    decassílabo (10 sílabas) — nunca sem metro.
  - **Estrofe:** um quarteto (4 versos) por padrão, salvo se o
    usuário especificar outro número de versos ou de estrofes.
  - **Rima:** sorteada de verdade entre três esquemas — emparelhada
    (AABB), cruzada (ABAB) ou alternada (ABCB) — ver o passo de
    sorteio na Tarefa 2 do modo Criação.
  - **Recursos:** ao menos uma figura de linguagem e atenção ao ritmo
    (ver `references/metrica-e-rima.md`).
- **Em Revisão**, um poema já existente pode ter sido escrito sem
  metro nem rima fixos (mesmo que a skill não ofereça mais isso como
  opção de criação). Nesse caso, ao avaliar (ver modo Avaliação,
  Tarefa A2):
  - a **ausência de metro é neutra** — não é defeito, é uma tradição
    legítima (poesia sem metro fixo existe e é válida);
  - a **ausência de rima é negativa** — aponte como lacuna a considerar
    preencher, mesmo quando o metro também estiver ausente.
  Fora isso, o modo Avaliação audita pelo padrão que o próprio poema
  estabelece, sem forçar a métrica ou o quarteto do modo padrão de
  Criação sobre um poema que nunca os teve.

## Escansão automática: `scripts/escandir_verso.py`

Contar sílabas poéticas de cabeça é enganoso — sinalefa e tonicidade têm
regras específicas que erram fácil "no olho". Use o script sempre que
precisar de uma contagem confiável — é a ferramenta central do modo
Avaliação:

```bash
# um verso avulso
python3 scripts/escandir_verso.py "Amor é fogo que arde sem se ver"

# um poema inteiro (arquivo com um verso por linha)
python3 scripts/escandir_verso.py --arquivo poema.txt

# haicai/tanka: use --simples (ver por quê em metrica-e-rima.md)
python3 scripts/escandir_verso.py --arquivo haicai.txt --simples

# validar contra o perfil estrutural de uma forma fixa (ver formas
# cadastradas em scripts/formas.json): compara nº de versos, sílabas
# por verso e esquema de rima contra o esperado, e devolve um relatório
# em JSON — fatos mensuráveis, não julgamento de qualidade
python3 scripts/escandir_verso.py --arquivo poema.txt --validar soneto_shakespeariano

# relatório de rima expandido: agrupa por som e classifica cada grupo
# por tonicidade (aguda/grave/esdrúxula) e qualidade (consoante/toante)
python3 scripts/escandir_verso.py --arquivo poema.txt --rima

# contagens objetivas: nº de versos, estrofes, palavras, média de
# sílabas por verso
python3 scripts/escandir_verso.py --arquivo poema.txt --stats
```

Use `--validar <forma>` sempre que o pedido nomear uma forma fixa
cadastrada (soneto_shakespeariano, soneto_petrarquiano, soneto_camoniano,
haicai, tanka, villanelle, limerique — ver a lista completa e os
critérios de cada uma em `scripts/formas.json`). Para o modo padrão de
formato livre (sem forma nomeada) não há entrada em `formas.json` —
rode sem `--validar` e confira o metro verso a verso e o esquema de
rima que o script detecta contra o que foi sorteado ou contra o padrão
que o próprio poema (em Revisão) já tinha.

**O script é uma ferramenta de apoio, não um oráculo.** A separação
silábica e a acentuação do português têm exceções reais (hiatos sem
acento gráfico, nomes próprios, licenças poéticas). Trate o resultado
como um ponto de partida objetivo — confira de ouvido, principalmente
quando a contagem estiver "quase certa" (1 sílaba de diferença) ou o
esquema de rima parecer estranho. Isso vale tanto para você quanto para
o que você reporta ao usuário: mostre a contagem, mas fale como "o
verso está escandindo em N sílabas" em vez de "está errado" quando o
desvio puder ser licença poética deliberada.

## Modo Avaliação

Escopo do conteúdo analisado muda conforme quem chama — no workflow
Criar é o rascunho recém-escrito (ainda não mostrado ao usuário); no
workflow Revisar é o poema que o usuário já trouxe pronto, avaliado
*antes* de decidir o que fazer com ele; chamada sozinha, é o que o
usuário colar ou apontar. As tarefas são as mesmas nos três casos:

### Tarefa A1 — Escandir e contar
Rode `escandir_verso.py --arquivo poema.txt` (`--simples` se
haicai/tanka; `--validar <forma>` se for forma fixa cadastrada) para a
escansão verso a verso, e `--rima` para os grupos de rima já
classificados por tonicidade e qualidade sonora. Rode também `--stats`
se a contagem de versos/estrofes/palavras ajudar a situar o poema.

### Tarefa A2 — Checar a forma
O poema bate com o que se esperava dele — forma fixa prescrita (número
de versos, agrupamento, esquema de rima), ou modo padrão (metro único +
esquema de rima sorteado), ou, no workflow Revisar, o padrão que os
próprios primeiros versos do poema estabeleceram? Aponte os versos que
destoam. Se o poema não tem metro nem rima definidos, aplique a regra
da seção "Regra central": falta de metro é neutra, falta de rima é
negativa.

### Tarefa A3 — Ler em voz alta procurando peso e ruído sonoro
Releia cada verso mentalmente em voz alta e marque:
- **Verso pesado** (acúmulo de consoantes ásperas ou de átonas demais
  seguidas, quebrando o ritmo esperado mesmo com a contagem certa).
- **Cacofonia** (o fim de uma palavra funde com o início da próxima e
  forma outro som/palavra indesejado).
- **Eco** (terminações sonoras repetidas entre versos próximos, fora do
  esquema de rima pretendido).

Definições e exemplos completos em `references/metrica-e-rima.md`.

### Tarefa A4 — Checar excesso de palavras
Aponte palavras de enchimento (linguiça métrica) — adjetivos genéricos,
advérbios redundantes, palavras que só existem para fechar a métrica ou
a rima — que poderiam sair sem tirar sentido ou imagem do verso.

### Tarefa A5 — Checar figuras de linguagem e musicalidade
Que figuras aparecem (metáfora, comparação, personificação, antítese
etc.) e que recursos sonoros (aliteração, assonância, anáfora,
enjambement)? Reforçam a imagem central ou parecem soltos/gratuitos? Há
pelo menos uma figura de linguagem, como o modo padrão exige?

### Tarefa A6 — Separar fato de julgamento e sintetizar
Separe o que é fato objetivo (contagem, esquema de rima, forma
cadastrada bate ou não) do que é julgamento (verso fora do padrão é
deslize ou licença poética deliberada?). Entregue isso como uma síntese
curta — é esse resultado que o workflow Criar usa para revisar o
rascunho antes de entregar, e que o modo Revisão usa para decidir o que
fazer na tarefa seguinte.

## Modo Criação

Escopo: nenhum poema anterior — tudo nasce nesta conversa. Quatro
tarefas fixas, nesta ordem (as 3 primeiras são a Criação propriamente
dita; a 4ª é a Avaliação, entrando como parte do workflow Criar).

### Tarefa 1 — Definir forma, tema e tom
Aplique a "Regra central" acima: identifique se há forma fixa nomeada
ou se é o modo padrão. Confirme (ou infira do pedido) tema e tom. Se
for modo padrão, escolha já aqui o metro (redondilha menor/maior ou
decassílabo) pelo que serve ao tom — não decida isso por sorteio, só a
rima é sorteada.

### Tarefa 2 — Sortear o esquema de rima (só no modo padrão)
Se uma forma fixa foi nomeada, pule esta tarefa e use o esquema de rima
que a própria forma prescreve (`formas-fixas.md`). Se for modo padrão,
sorteie de verdade — não escolha "no olho" — rodando:

```bash
python3 -c "import random; print(random.choice(['emparelhada (AABB)', 'cruzada (ABAB)', 'alternada (ABCB)']))"
```

Use o resultado do sorteio como o esquema da estrofe. Isso garante que
a distribuição entre os três esquemas seja de fato aleatória ao longo
de vários poemas, em vez de sempre recair no mesmo esquema por hábito.

### Tarefa 3 — Rascunhar
Escreva pensando primeiro na imagem/ideia central — inclua ao menos uma
figura de linguagem que sirva a essa imagem (`metrica-e-rima.md`) — e
só depois ajuste à forma (metro e rima definidos nas Tarefas 1-2, ou à
forma fixa prescrita). Poemas que nascem "encaixando palavras na
métrica" costumam soar arrastados; é mais natural escrever o sentido e
lapidar o verso depois, trocando sinônimos e reordenando frases.

### Tarefa 4 — Rodar o modo Avaliação sobre o rascunho
Aplique as Tarefas A1-A6 do modo Avaliação ao rascunho da Tarefa 3.
Ajuste os versos que a avaliação apontar como erro real (verso fora do
metro sem parecer proposital, cacofonia, verso pesado, linguiça
métrica) — licenças poéticas deliberadas podem ficar, mas vale
mencioná-las ao entregar o poema. Só entregue depois desta tarefa.

## Modo Revisão

Escopo: um poema que **já existe** — o usuário colou no chat ou
enviou um arquivo. Nunca cria do zero; sempre parte do que foi trazido.
Cobre duas operações diferentes sobre esse poema — **corrigir** (o
pedido é do tipo "conserta", "corrige", "isso rima direito?") ou
**transformar** (o pedido é do tipo "transforma isso num soneto",
"muda o tom", "encurta para um haicai"); se o pedido for ambíguo sobre
qual das duas quer, pergunte antes de seguir. As duas operações
começam pela mesma auditoria (Tarefa V1), depois se separam.

### Tarefa V1 — Rodar o modo Avaliação sobre o poema como está
Sempre a primeira tarefa do workflow Revisar, para as duas operações.
Aplique as Tarefas A1-A6 do modo Avaliação ao poema exatamente como o
usuário entregou — esta é a auditoria que baliza tanto corrigir quanto
transformar, não um rascunho a ajustar livremente como em Criação.

### Tarefa V2 — Escolher a operação
Com base no pedido do usuário (ou perguntando, se ambíguo):
- Pedido de **correção** → siga as Tarefas V3-Corrigir a V5-Corrigir.
- Pedido de **transformação** → siga as Tarefas V3-Transformar a
  V5-Transformar.

#### Corrigir (aproxima o poema do próprio padrão dele)

**Tarefa V3-Corrigir — Separar deslize de licença poética**
Para cada ponto que a Avaliação (Tarefa A6) marcou como desvio: é um
deslize (quebra a expectativa sem parecer proposital) ou uma licença
poética (dá ênfase de propósito)? Só proponha correção para o primeiro
caso; para o segundo, observe isso na resposta e deixe a decisão com o
usuário.

**Tarefa V4-Corrigir — Corrigir preservando a voz**
Ao propor um ajuste, prefira trocar palavras por sinônimos ou reordenar
a sintaxe em vez de cortar imagens — o objetivo é acertar o verso sem
esvaziar o sentido nem substituir a voz do autor pela sua.

**Tarefa V5-Corrigir — Aplicar e documentar**
Quando o poema estiver em um arquivo, aplique as correções diretamente
nele e acrescente um changelog inline (um comentário ou uma lista logo
após o poema) listando verso por verso o que mudou e por quê — não
deixe a correção só descrita em prosa se o usuário pode simplesmente
querer o arquivo pronto.

#### Transformar (muda o padrão do poema de propósito)

**Tarefa V3-Transformar — Definir o que a nova forma corta e ganha**
Leia a seção final de `references/formas-fixas.md` ("Escolhendo a forma
certa numa transformação") e nomeie para o usuário o que se perde e o
que se ganha na mudança pedida, por exemplo:
- Mudança de forma (formato livre → soneto, soneto → haicai etc.)
- Mudança de tom ou registro (sério ↔ cômico, formal ↔ coloquial)
- Mudança de métrica (ex.: redondilha maior → decassílabo)
- Condensação ou expansão (resumir um poema longo em uma quadra, ou
  desenvolver uma quadra em um poema maior)
- Modernização ou arcaização de vocabulário e sintaxe

**Tarefa V4-Transformar — Aplicar a transformação**
Se o destino for uma forma fixa nomeada, siga-a à risca
(`formas-fixas.md`). Se o destino for "sem forma nomeada" (ex.: "tira a
métrica do soneto, mas não peça verso livre"), trate como modo padrão
de formato livre e aplique a Regra central (metro único à escolha,
quarteto por padrão, rima sorteada — Tarefa 2 do modo Criação) em vez
de soltar o poema em versos sem metro.

**Tarefa V5-Transformar — Rodar o modo Avaliação de novo**
Aplique as Tarefas A1-A6 sobre a variação recém-criada para confirmar
que a nova forma realmente bate com o que foi pedido — mesmo papel que
a Tarefa 4 cumpre no workflow Criar, agora sobre o resultado da
transformação em vez de um rascunho.
