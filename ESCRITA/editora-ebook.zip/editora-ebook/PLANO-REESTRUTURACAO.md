# Plano de Reestruturação — Editora Ebook
## Para aprovação — v1.0

---

## 1. Diagnóstico: onde os tokens estão sendo gastos

### Inventário atual (por arquivo)

| Arquivo | Tokens est. | Carregado em |
|---|---|---|
| SKILL.md | ~2.893 | **toda** requisição |
| 12-sistema-scoring.md | ~1.678 | M4, M5, M6, M7 |
| 11-pesquisa-mercado.md | ~1.735 | M2, M4, M7 |
| 13-log-decisoes-editoriais.md | ~1.496 | toda requisição |
| 10-versionamento-estado.md | ~1.161 | toda requisição |
| 04-estrutura-organizacao.md | ~974 | M3 |
| 05-estilo-tom-voz.md | ~994 | M6 |
| 02-redacao-capitulos.md | ~950 | M4 |
| 01-definicao-projeto.md | ~905 | M1 |
| 03-revisao-correcao.md | ~905 | M5 |
| 09-formatacao-export.md | ~781 | M8 |
| 08-metadados-publicacao.md | ~687 | M9 |
| 06-adaptacao-linguagem.md | ~593 | M5/M6 |
| 07-validacao-coerencia.md | ~603 | M5/M7 |
| capitulos-e-estruturas.md | ~374 | M4/M8 |
| critico.md | ~205 | M5/M7 |
| **TOTAL** | **~16.939** | |

### Problema central

A skill é um **sistema de documentação lida pela LLM** em vez de um
**sistema de execução com delegação inteligente de tarefas**.

Isso causa três desperdícios:

**1. Tokens redundantes por requisição**
O SKILL.md (~2.893 tokens) é carregado em toda requisição mesmo quando
a tarefa é parcial (ex: `/revisar` não precisa de roteamento completo,
scoring, log de decisões, pipeline etc).

**2. Lógica determinística descrita em prosa**
Vários trechos dos arquivos descrevem *como calcular* algo que um
script Python calcularia instantaneamente e sem consumo de tokens:
- Cálculo do score de capítulo (média ponderada S1–S5)
- Contagem de palavras por frase (legibilidade)
- Contagem de erros ortográficos/gramaticais (via LanguageTool API)
- Diff entre versões (texto original vs. revisado)
- Detecção de voz passiva (regex)
- Contagem de jargões sem glossário (busca por termos)
- Geração de metadados YAML (estruturado, sem criatividade)
- Exportação Markdown → EPUB/DOCX/PDF (pandoc CLI)
- Calculadora de equilíbrio de capítulos (contagem de palavras)
- Análise de gap do sumário (checklist binário)
- Versionamento e histórico (CRUD em JSON)
- Geração do Bloco de Estado (template preenchido)

**3. Templates repetidos como contexto**
Templates de capítulo, blurb, sumário e página de rosto são
carregados como texto no contexto da LLM, quando poderiam ser
arquivos preenchidos por script e entregues prontos.

---

## 2. Princípio da reestruturação

```
ANTES: LLM lê instrução → LLM executa tarefa → LLM formata resultado
DEPOIS: Script executa tarefa determinística → LLM recebe dados prontos → LLM decide / cria
```

A LLM deve agir **apenas** onde há julgamento, criatividade ou
interpretação de linguagem natural. Todo o resto vai para Python.

---

## 3. Mapa de tarefas: LLM vs. Script

### 3A — Tarefas que permanecem na LLM (exigem julgamento)

| Tarefa | Agente | Por quê é da LLM |
|---|---|---|
| Escrever capítulos (ToT) | AUTOR | Criatividade, coerência narrativa |
| Avaliar qualidade do gancho (S1) | CRÍTICO | Julgamento de impacto emocional |
| Avaliar adequação de tom (S3) | CRÍTICO | Interpretação de linguagem |
| Avaliar coerência argumentativa (S2 parcial) | CRÍTICO | Lógica e subtexto |
| Detectar contradições internas | CRÍTICO | Cruzamento semântico |
| Reescrever por tom/voz | COPYWRITER | Criatividade estilística |
| Gerar analogias e exemplos | SIMPLIFICADOR | Criatividade contextual |
| Blurb e copy de vendas | EDITOR | Persuasão e síntese |
| Gerador de títulos (ToT) | COPYWRITER | Criatividade + SEO julgado |
| Fact-checking e classificação | PESQUISADOR | Interpretação de fontes |
| Persona do leitor | ARQUITETO | Síntese qualitativa |
| Posicionamento diferenciado | PESQUISADOR | Análise estratégica |
| Identificar falácias lógicas | CRÍTICO | Raciocínio lógico |
| Detectar "saída de voz" (ghostwriting) | COPYWRITER | Estilo e nuance |
| Reorganizar estrutura narrativa | ARQUITETO | Fluxo e progressão |

### 3B — Tarefas determinísticas → migrar para Python

| Tarefa | Script | Input | Output para LLM |
|---|---|---|---|
| Calcular score ponderado S1–S5 | `scorer.py` | Notas brutas S1–S5 | Score final + status |
| Gerar scorecard consolidado | `scorer.py` | JSON de capítulos | Tabela Markdown pronta |
| Detectar voz passiva | `analyzer.py` | Texto do capítulo | Lista de frases + posição |
| Contar palavras por frase | `analyzer.py` | Texto | Média + frases acima do limiar |
| Detectar jargões sem glossário | `analyzer.py` | Texto + glossário.json | Lista de jargões não explicados |
| Diff entre versões | `versioner.py` | v_anterior + v_nova | Diff unificado em Markdown |
| Salvar/carregar estado do projeto | `versioner.py` | Bloco de Estado JSON | Estado carregado ou confirmação |
| Gerar histórico de versões | `versioner.py` | JSON de versões | Tabela Markdown pronta |
| Registrar decisão editorial | `decisions.py` | Decisão + categoria | Confirmação + D-XX atribuído |
| Listar decisões travadas | `decisions.py` | decisions.json | Tabela Markdown pronta |
| Detectar conflito com decisão | `decisions.py` | Texto + decisions.json | Lista de conflitos detectados |
| Calculadora de equilíbrio | `analyzer.py` | Textos dos capítulos | Palavras/cap + desequilíbrios |
| Análise de gap do sumário | `analyzer.py` | Sumário + capítulos | ✅/🔶/❌ por capítulo |
| Gerar metadados YAML | `publisher.py` | Campos do briefing | YAML completo |
| Exportar Markdown → EPUB | `exporter.py` | .md + metadados | Arquivo .epub |
| Exportar Markdown → DOCX | `exporter.py` | .md + template.docx | Arquivo .docx |
| Exportar Markdown → PDF | `exporter.py` | .md + metadados | Arquivo .pdf |
| Preencher template de capítulo | `templater.py` | Tipo + campos | .md preenchido |
| Preencher página de rosto | `templater.py` | Campos do projeto | .md preenchido |
| Índice Flesch (legibilidade) | `analyzer.py` | Texto | Score + classificação |
| Verificar numeração sequencial | `analyzer.py` | Texto | Lista de inconsistências |

---

## 4. Arquitetura proposta

```
editora-ebook/
│
├── SKILL.md                  ← REDUZIDO: apenas roteamento + regras críticas
│
├── agents/                   ← sem alteração de conteúdo
│   └── critico.md
│
├── references/               ← REFATORADOS: só o que a LLM precisa saber
│   ├── 01-definicao-projeto.md      (mantido — briefing é conversacional)
│   ├── 02-redacao-capitulos.md      (mantido — escrita é da LLM)
│   ├── 03-revisao-correcao.md       (enxugado — checklist vira parâmetro do script)
│   ├── 04-estrutura-organizacao.md  (mantido — arquitetura é da LLM)
│   ├── 05-estilo-tom-voz.md         (mantido — estilo é da LLM)
│   ├── 06-adaptacao-linguagem.md    (mantido — adaptação é da LLM)
│   ├── 07-validacao-coerencia.md    (enxugado — métricas vão para scripts)
│   ├── 08-metadados-publicacao.md   (enxugado — YAML gerado por script)
│   ├── 09-formatacao-export.md      (enxugado — export é script, LLM só decide)
│   ├── 10-versionamento-estado.md   (enxugado — CRUD vai para versioner.py)
│   ├── 11-pesquisa-mercado.md       (mantido — pesquisa e julgamento são da LLM)
│   ├── 12-sistema-scoring.md        (enxugado — cálculo vai para scorer.py)
│   └── 13-log-decisoes-editoriais.md (enxugado — CRUD vai para decisions.py)
│
├── scripts/                  ← NOVO: Python puro, determinístico
│   ├── scorer.py             ← Cálculo de score S1–S5, scorecard, consolidado
│   ├── analyzer.py           ← Legibilidade, voz passiva, jargões, equilíbrio, gap
│   ├── versioner.py          ← Estado do projeto, histórico, diff, rollback
│   ├── decisions.py          ← Log de decisões, travamento, conflitos
│   ├── publisher.py          ← Metadados YAML, checklist pré-publicação
│   ├── exporter.py           ← EPUB, DOCX, PDF via pandoc
│   └── templater.py          ← Preenchimento de templates .md
│
├── data/                     ← NOVO: estado persistente em JSON
│   ├── project.json          ← Briefing, decisões, sumário aprovado
│   ├── versions.json         ← Histórico de versões por capítulo
│   ├── scores.json           ← Scorecard de todos os capítulos
│   └── glossary.json         ← Termos técnicos do projeto
│
└── templates/                ← sem alteração
    └── capitulos-e-estruturas.md
```

---

## 5. Redução de tokens projetada

### Antes (pior caso — tarefa complexa carrega tudo)

| Arquivo | Tokens |
|---|---|
| SKILL.md | 2.893 |
| Arquivo de referência do agente | ~900 |
| 12-sistema-scoring.md | 1.678 |
| 13-log-decisoes-editoriais.md | 1.496 |
| 10-versionamento-estado.md | 1.161 |
| **Total por turno** | **~8.128** |

### Depois (mesma tarefa complexa)

| O que vai para o contexto | Tokens |
|---|---|
| SKILL.md reduzido (só roteamento + regras) | ~800 |
| Arquivo de referência do agente (enxugado) | ~500 |
| Output do script (dados prontos, sem instrução) | ~200 |
| **Total por turno** | **~1.500** |

**Redução estimada: ~82% de tokens de contexto de instrução**

A LLM recebe dados, não instruções sobre como calcular dados.

---

## 6. Scripts — especificação funcional

### `scorer.py`

```
Entradas:
  --s1 FLOAT  --s2 FLOAT  --s3 FLOAT  --s4 FLOAT  --s5 FLOAT
  --stage [M4|M5|M6|M7]
  --chapter STR  --version STR
  --consolidate (gera tabela de todos os capítulos de scores.json)

Saídas:
  score_final: float (1 casa decimal)
  status: APROVADO | RETRABALHO
  limiar: float
  secao_mais_fraca: str
  scorecard_md: str (tabela Markdown pronta)
  salva em scores.json automaticamente
```

### `analyzer.py`

```
Entradas:
  --text FILE.md
  --mode [passive|readability|jargon|balance|gap|numbering]
  --glossary glossary.json (para modo jargon)
  --summary summary.json (para modo gap)
  --level [leigo|iniciante|intermediario|avancado] (para readability)

Saídas (por modo):
  passive:     lista de frases com voz passiva + posição de linha
  readability: média palavras/frase, índice Flesch, classificação
  jargon:      lista de termos sem explicação no texto
  balance:     palavras/capítulo, desvio da média, capítulos problemáticos
  gap:         ✅/🔶/❌ por capítulo com % de cobertura
  numbering:   inconsistências em listas numeradas
```

### `versioner.py`

```
Entradas:
  --action [save|load|diff|rollback|history]
  --chapter STR  --version STR  --agent STR  --description STR
  --file FILE.md (conteúdo a salvar)
  --compare vX.Y:vX.Z (para diff)

Saídas:
  save:     confirmação + versão atribuída
  load:     conteúdo do arquivo + metadados
  diff:     diff unificado em Markdown (~~removido~~ / **adicionado**)
  rollback: confirmação + estado restaurado
  history:  tabela Markdown de todo o histórico
```

### `decisions.py`

```
Entradas:
  --action [add|list|lock|check|alter|pending]
  --category [TOM|PUB|EST|LNG|CIT|GRF|POS|FMT|MKT]
  --decision STR  --by STR  --stage STR
  --text FILE.md (para check — detecta conflitos)
  --id D-XX (para alter/detail)

Saídas:
  add:     D-XX atribuído + confirmação
  list:    tabela Markdown de decisões travadas
  check:   lista de conflitos detectados no texto (linha + decisão violada)
  alter:   protocolo de alteração iniciado + entrada no histórico
  pending: lista de decisões em aberto com urgência
```

### `publisher.py`

```
Entradas:
  --action [metadata|checklist]
  --project project.json

Saídas:
  metadata:  YAML completo para KDP/Hotmart
  checklist: checklist pré-publicação com status ✅/❌ por item
```

### `exporter.py`

```
Entradas:
  --input FILE.md
  --format [epub|docx|pdf]
  --cover IMAGE (opcional, para epub)
  --template FILE.docx (opcional, para docx)
  --metadata project.json

Saídas:
  arquivo exportado no formato solicitado
  log de erros de conversão se houver
```

### `templater.py`

```
Entradas:
  --template [capitulo-nonfiction|capitulo-fiction|conclusao|blurb|rosto|sumario]
  --fields JSON (campos a preencher)
  --output FILE.md

Saídas:
  arquivo .md preenchido com os campos fornecidos
  campos não preenchidos marcados com [PENDENTE: campo]
```

---

## 7. Protocolo de integração LLM ↔ Script

A LLM instrui o script via comentário estruturado no output,
o usuário (ou um runner externo) executa e devolve o resultado:

```
[SCRIPT: scorer.py --s1 8.5 --s2 7.2 --s3 9.0 --s4 10.0 --s5 6.5 --stage M5 --chapter "Cap. 1" --version v1.2]
```

O runner devolve:
```
[RESULTADO: score_final=8.1 status=APROVADO limiar=7.0 secao_mais_fraca=S5(6.5)]
```

A LLM usa o resultado para compor sua resposta ao usuário —
sem ter calculado nada.

---

## 8. Redução dos arquivos de referência

### Arquivos que enxugam mais

**12-sistema-scoring.md**: remove toda a seção de fórmulas e tabelas
de pontuação (vai para `scorer.py`). Mantém apenas:
- Quais seções existem e o que cada uma avalia (para a LLM pontuar)
- Os limiares por estágio (parâmetro de `scorer.py`)
- O template de scorecard (agora gerado pelo script)
- Estimativa: de ~1.678 para ~400 tokens

**13-log-decisoes-editoriais.md**: remove toda a lógica de CRUD.
Mantém apenas:
- O que é uma decisão editorial (para a LLM identificar)
- As categorias (TOM, PUB, EST...)
- O protocolo de conflito (o que a LLM deve fazer ao detectar)
- Estimativa: de ~1.496 para ~350 tokens

**10-versionamento-estado.md**: remove numeração, formato JSON,
comandos CRUD. Mantém apenas:
- O que o Bloco de Estado contém (para a LLM saber o que pedir)
- O protocolo de rollback (decisão é da LLM, execução é do script)
- Estimativa: de ~1.161 para ~300 tokens

**SKILL.md**: remove seções de scoring (resumo vai para referência ao
12-sistema-scoring.md enxuto), remove lista detalhada de arquivos,
remove descrições longas de agentes (ficam nos arquivos deles).
Mantém: roteamento, pipeline, comandos, regras globais.
- Estimativa: de ~2.893 para ~900 tokens

---

## 9. Cronograma de implementação

| Fase | Entregável | Complexidade | Prioridade |
|---|---|---|---|
| **F1** | `scorer.py` completo + `12-sistema-scoring.md` enxuto | Baixa | Alta |
| **F1** | `decisions.py` completo + `13-log-decisoes-editoriais.md` enxuto | Baixa | Alta |
| **F2** | `versioner.py` completo + `10-versionamento-estado.md` enxuto | Média | Alta |
| **F2** | `analyzer.py` (passive + readability + jargon) | Média | Alta |
| **F3** | `exporter.py` (epub + docx + pdf) | Média | Média |
| **F3** | `publisher.py` + `templater.py` | Baixa | Média |
| **F4** | `analyzer.py` (balance + gap + numbering) | Média | Baixa |
| **F4** | `SKILL.md` reduzido + todos os `.md` enxutos | Baixa | Alta |

**F1 e F4 (SKILL.md) são os de maior impacto de tokens e menor risco.**
Sugere-se aprovação e execução imediata de F1 + F4.

---

## 10. O que NÃO muda

- Conteúdo editorial dos arquivos 01–09 (técnica de escrita, estrutura,
  tom, estilo — são da LLM e permanecem intocados)
- Lógica dos agentes (o que cada agente faz não muda, só quem executa
  as partes determinísticas)
- Comandos do usuário (`/escrever`, `/revisar`, `/score`, etc.)
- O sistema de ToT (exclusivamente da LLM)
- O sistema de fact-checking (exclusivamente da LLM + web_search)
- Templates de conteúdo (`capitulos-e-estruturas.md`)

---

## 11. Riscos e mitigações

| Risco | Probabilidade | Mitigação |
|---|---|---|
| Runner de scripts não disponível no ambiente do usuário | Média | Scripts têm modo `--dry-run` que simula output sem executar |
| LLM ignora instrução de chamar script | Baixa | Regra global no SKILL.md: "nunca calcule scores manualmente" |
| JSON corrompido entre sessões | Baixa | `versioner.py` faz backup antes de qualquer write |
| Pandoc não instalado para export | Média | `exporter.py` detecta e instrui instalação; fallback para Markdown |

---

## Aguardando aprovação para iniciar implementação

Ao aprovar, especifique:
- **Quais fases iniciar** (sugestão: F1 + F4 imediatamente)
- **Ambiente de execução dos scripts** (local com Python, Cowork, outro)
- **Formato de retorno do script para a LLM** (comentário inline, arquivo, outro)
