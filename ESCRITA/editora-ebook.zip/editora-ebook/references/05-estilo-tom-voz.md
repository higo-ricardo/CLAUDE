# 05 — Estilo, Tom e Voz

**Agente**: COPYWRITER
**Estágio**: M6

---

## Objetivo
Garantir voz consistente, tom adequado ao público e escrita que engaje
e retenha o leitor.

---

## Espectro de Tom

`Formal (acadêmico, técnico, corporativo, jornalístico) ←→ Informal (conversacional, coloquial, descontraído, íntimo)`

### Referências de Tom por Gênero

| Gênero | Tom sugerido | Características |
|---|---|---|
| Autoajuda | Inspirador + empático | Fala "você", metáforas, histórias pessoais |
| Negócios/gestão | Direto + profissional | Dados, frameworks, linguagem de resultado |
| Técnico/programação | Objetivo + didático | Exemplos de código, step-by-step, alertas |
| Educacional infanto-juvenil | Leve + encorajador | Frases curtas, analogias do cotidiano |
| Saúde/bem-estar | Acolhedor + informativo | Equilíbrio ciência e humanidade |
| Ficção literária | Variável por obra | Dependente de POV, época, gênero |

---

## Reescrita por Tom

Aplicando o espectro acima, dado um parágrafo e o tom desejado, o
COPYWRITER reescreve. Exemplo a partir de "A gestão do tempo é um fator
determinante para o aumento da produtividade dos profissionais em
ambiente corporativo":

- **Formal/acadêmico**: "Estudos indicam que a administração eficaz do
  tempo constitui variável crítica na otimização da performance
  profissional em contextos organizacionais."
- **Direto/negócios**: "Quem domina o próprio tempo, domina os
  resultados. É simples assim."
- **Conversacional/autoajuda**: "Você já chegou ao fim do dia com a
  sensação de que trabalhou muito, mas entregou pouco? Isso tem nome:
  má gestão do tempo. E tem solução."

---

## Detecção de Voz Autoral

Dado material próprio do usuário (notas, posts, transcrições), extrair
a impressão digital de voz: adjetivos descritivos · comprimento médio
de frase · vocabulário característico (5-10 termos recorrentes) ·
padrão de pontuação · nível de formalidade (X/10) · uso de 1ª pessoa ·
2-3 frases exemplo representativas.

---

## Otimização de Títulos e Subtítulos

5 critérios (0-2 pontos cada, mínimo 7/10 para aprovação): **Clareza**
(entende do que trata?) · **Benefício** (ganho concreto?) ·
**Curiosidade** (gera vontade de saber mais?) · **Urgência** (senso de
necessidade?) · **SEO** (palavras que o público buscaria?).

---

## Funcionalidades Extras

**Gerador de Títulos de Capítulo** — 5 títulos por fórmulas testadas:
Número+Benefício ("7 Estratégias para Dobrar Sua Produtividade") ·
Como+Resultado ("Como Escrever um Ebook em 30 Dias") · Pergunta
("Por Que Você Trabalha Muito e Entrega Pouco?") · Segredo/Revelação
("O Erro que 90% dos Gestores Cometem") · Comparação/Contraste
("De Procrastinador a Produtivo em 21 Dias").

**Gerador de Introduções** — 3 opções de abertura por capítulo: gancho
estatístico, narrativo ou provocador.

**Otimizador de Conclusões** — reescrever para maximizar transição ao
próximo capítulo, gerando antecipação sem revelar tudo.

**Checador de Consistência de Voz** — dado estilo de referência, varrer
capítulos em busca de trechos fora da voz e sinalizar para revisão.
