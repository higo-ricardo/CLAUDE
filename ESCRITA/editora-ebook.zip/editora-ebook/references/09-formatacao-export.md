# 09 — Formatação e Export

**Agente**: FORMATADOR  
**Estágio**: M8

---

## Objetivo
Produzir o arquivo final do ebook no formato correto, com estrutura
visual profissional e pronto para distribuição.

---

## Formatos Suportados

| Formato | Uso | Ferramenta |
|---|---|---|
| **Markdown (.md)** | Edição, versionamento, base para outros | Nativo |
| **HTML** | Web, conversão para EPUB | Pandoc / manual |
| **DOCX** | Revisão colaborativa, impressão | python-docx |
| **PDF** | Distribuição direta, preservação de layout | WeasyPrint / reportlab |
| **EPUB** | Kindle, Kobo, Apple Books | Pandoc + calibre |

---

## Estrutura Markdown Padrão

Ordem: frontmatter YAML (title/author/date/lang) → título + subtítulo +
autor + copyright → "Sobre este Ebook" → partes numeradas, cada uma com
capítulos (subseções, boxes de destaque `💡`/`⚠️`, transição ao final) →
Conclusão → Referências → Sobre o Autor.

Para a folha de rosto: usar `templater.py --template rosto` (ver
`SKILL.md`) — já gera a estrutura padrão (título, subtítulo, autor,
copyright, aviso de direitos, contato).

---

## Elementos Visuais em Markdown

| Elemento | Sintaxe |
|---|---|
| Destaque/dica | `> **💡 Dica:** texto` |
| Alerta | `> **⚠️ Atenção:** texto` |
| Citação de expert | `> "Texto da citação" — Autor, Obra` |
| Separador de seção | `---` |
| Código/técnico | ` ```linguagem ``` ` |
| Tabela | Padrão Markdown |
| Negrito para termos | `**termo importante**` |

---

## Checklist de Formatação Final

Com o conteúdo e a folha de rosto prontos, confira antes de exportar:

- [ ] Capa: título, autor, imagem ou cor de fundo
- [ ] Folha de rosto: título, subtítulo, autor, editora/publicação independente
- [ ] Página de copyright: © Ano, direitos, ISBN, contato
- [ ] Sumário com links navegáveis (EPUB) ou página (PDF)
- [ ] Introdução antes do Capítulo 1
- [ ] Numeração de capítulos consistente
- [ ] Conclusão presente
- [ ] Seção "Sobre o Autor" ao final
- [ ] CTA final (lista de e-mail, próximo produto, redes sociais)
- [ ] Referências bibliográficas (se houver)
- [ ] Revisão de metadados no frontmatter

---

## Guia de Exportação Rápida

Checklist aprovado, exportar com `exporter.py --format {epub,docx,pdf}`
(ver `SKILL.md`) — já implementa os comandos pandoc equivalentes
(`--toc`, `--epub-cover-image`, `--reference-doc`, seleção de motor
PDF). Não reconstruir os comandos manualmente.
