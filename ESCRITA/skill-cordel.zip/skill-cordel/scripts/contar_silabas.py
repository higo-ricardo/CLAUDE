#!/usr/bin/env python3
"""
contar_silabas.py — Contador de sílabas poéticas (métrica) para versos em português.

Uso:
    python3 contar_silabas.py "Verso a ser medido aqui"
    python3 contar_silabas.py --arquivo cordel.txt
    echo "um verso" | python3 contar_silabas.py -

Conceito:
Na métrica portuguesa, a contagem de sílabas de um verso vai até a ÚLTIMA
SÍLABA TÔNICA da última palavra (não até o fim físico da palavra). Além
disso, quando uma palavra termina em vogal (ou vogal nasal) e a próxima
começa com vogal, ocorre SINALEFA: as duas vogais se fundem em uma só
sílaba métrica (elisão), reduzindo a contagem total do verso.

Este script é uma HEURÍSTICA — cobre a grande maioria dos casos de
sextilha/redondilha maior (7 sílabas), mas não substitui a checagem
humana (ou do próprio Claude, lendo o verso em voz alta) em casos raros
de hiato/ditongo ambíguo. Sempre que a contagem der um número próximo
mas não exato (ex.: 6 ou 8 em vez de 7), releia o verso e ajuste.

Regra prática para quem for revisar manualmente:
- Redondilha maior = 7 sílabas poéticas por verso (forma da sextilha clássica)
- Martelo agalopado / galope à beira-mar = 10 sílabas
- Décima = geralmente 7 sílabas também, mas em estrofe de 10 versos
"""

import re
import sys
import argparse
import unicodedata

VOGAIS = "aeiouáéíóúâêôãõàAEIOUÁÉÍÓÚÂÊÔÃÕÀ"
VOGAIS_ORAIS_TONICAS_MARCADAS = "áéíóúâêô"  # acento gráfico indica a tônica diretamente

# Ditongos e tritongos comuns (fundem-se em UMA sílaba poética).
# Sequências de vogais que NÃO estão nesta lista são tratadas como hiato
# (duas sílabas separadas) — aproximação intencional.
DITONGOS = {
    # ditongos decrescentes (vogal tônica + semivogal) — leitura estável,
    # praticamente sem ambiguidade em português
    "ai", "au", "ei", "eu", "oi", "ou", "iu", "ui", "õe", "ãe", "ão",
    "éu", "êu", "óu", "ãi", "ũi",
}
TRITONGOS = {"uai", "uei", "uau", "iai", "uão", "uõe"}

# Vogais que, quando acentuadas graficamente, costumam MARCAR HIATO
# (quebram um possível ditongo crescente) — ex.: sa-í-da, ba-ú, juí-za
VOGAIS_QUEBRAM_DITONGO = "íúÍÚ"

# NOTA IMPORTANTE sobre sequências crescentes (semivogal + vogal: ia, ie,
# io, ua, ue, uo — ex.: "lua", "dia", "sua", "história", "viagem"):
# o português admite as DUAS leituras conforme o contexto poético —
# SINÉRESE (1 sílaba, ex.: "his-tó-ria") ou DIÉRESE (2 sílabas, ex.:
# "lu-a", "di-a", "su-a"). Não há regra puramente ortográfica que decida
# isso sem saber a tônica da palavra e a intenção do verso. Por default,
# este script NÃO funde essas sequências (trata como 2 sílabas/hiato),
# porque essa é a leitura mais comum em palavras curtas e frequentes no
# cordel ("lua", "dia", "sua", "rua"). Isso pode SUBESTIMAR levemente a
# métrica em palavras como "história" ou "viagem" onde a leitura mais
# natural funde em 1 sílaba — se um verso ficar 1 sílaba "a mais" e
# tiver uma dessas sequências, tente a leitura fundida antes de reescrever
# o verso.


def _strip_accents(s: str) -> str:
    return "".join(
        c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn"
    )


def eh_vogal(c: str) -> bool:
    return c in VOGAIS


def _remover_u_mudo(palavra: str) -> str:
    """Remove o 'u' mudo dos dígrafos que/qui/gue/gui (ex.: 'ninguém',
    'que', 'aqui', 'guerra') antes da contagem de vogais. Simplificação:
    trata sempre como mudo, que é o caso mais comum — palavras raras
    onde o 'u' é pronunciado (ex.: 'linguiça', 'sagui', 'averiguou')
    ficarão subcontadas em 1 sílaba; ajuste manualmente se for o caso.
    """
    return re.sub(r"([gq])u([eiEI])", r"\1\2", palavra)


def separar_nucleos_vocalicos(palavra: str):
    """Retorna lista de núcleos vocálicos (cada um = 1 sílaba métrica),
    já considerando ditongos/tritongos como núcleo único."""
    p = _remover_u_mudo(palavra.lower())
    nucleos = []
    i = 0
    n = len(p)
    while i < n:
        if eh_vogal(p[i]):
            # tenta tritongo (3 vogais)
            if i + 2 < n and eh_vogal(p[i + 1]) and eh_vogal(p[i + 2]):
                tri = p[i:i + 3]
                tri_sem_acento = _strip_accents(tri)
                if tri_sem_acento in TRITONGOS or tri in TRITONGOS:
                    nucleos.append(tri)
                    i += 3
                    continue
            # tenta ditongo (2 vogais) — mas respeita acento de hiato (í/ú)
            if i + 1 < n and eh_vogal(p[i + 1]):
                di = p[i:i + 2]
                di_sem_acento = _strip_accents(di)
                segunda_vogal_marca_hiato = p[i + 1] in VOGAIS_QUEBRAM_DITONGO
                if not segunda_vogal_marca_hiato and (di_sem_acento in DITONGOS or di in DITONGOS):
                    nucleos.append(di)
                    i += 2
                    continue
            # vogal isolada (ou hiato: cai aqui, cada vogal vira seu próprio núcleo)
            nucleos.append(p[i])
            i += 1
        else:
            i += 1
    return nucleos


def contar_silabas_palavra(palavra: str) -> int:
    palavra = re.sub(r"[^\wáéíóúâêôãõàçÁÉÍÓÚÂÊÔÃÕÀÇ']", "", palavra)
    if not palavra:
        return 0
    return max(1, len(separar_nucleos_vocalicos(palavra)))


def termina_em_vogal_ou_nasal(palavra: str) -> bool:
    """Para checar sinalefa: a palavra termina em som vocálico (vogal, ou
    vogal nasal -am/-em/-ão etc. cujo som final ainda é vocálico)?"""
    p = _strip_accents(palavra.lower())
    if not p:
        return False
    if p[-1] in "aeiou":
        return True
    if p.endswith(("am", "em", "ao", "im", "om", "um")):
        return True
    return False


def comeca_com_vogal(palavra: str) -> bool:
    p = palavra.lower()
    return bool(p) and p[0] in "aeiouáéíóúâêôãõà"


def posicao_tonica(palavra: str):
    """Retorna (0 = última sílaba é tônica / oxítona,
                1 = penúltima é tônica / paroxítona,
                2 = antepenúltima é tônica / proparoxítona)
    contando a partir do fim, com base em acento gráfico ou regra padrão."""
    p_lower = palavra.lower()
    nucleos = separar_nucleos_vocalicos(re.sub(r"[^\wáéíóúâêôãõàçÁÉÍÓÚÂÊÔÃÕÀÇ']", "", p_lower))
    if not nucleos:
        return 1
    if len(nucleos) == 1:
        # monossílabo: não há sílaba seguinte à tônica para descartar
        return 0

    # 1) Acento gráfico explícito indica a tônica diretamente
    for idx_reverso, nucleo in enumerate(reversed(nucleos)):
        if any(v in nucleo for v in VOGAIS_ORAIS_TONICAS_MARCADAS):
            return idx_reverso

    # 2) Regra padrão sem acento gráfico
    # Terminações nasais (ão/ãe) precisam ser checadas ANTES de remover
    # acento, pois "ão" -> "ao" perderia a marca de nasalização.
    if p_lower.endswith(("ão", "ãe", "ãos", "ães")):
        return 0
    sem_acento = _strip_accents(p_lower)
    terminacoes_oxitonas = ("r", "l", "z", "x", "n", "i", "u")
    if sem_acento.endswith(terminacoes_oxitonas) or sem_acento.endswith(tuple(v + "s" for v in "iu")):
        return 0
    # padrão geral: paroxítona (a maioria das palavras terminadas em a/e/o/em/ens/as/es/os)
    return 1


def contar_silabas_verso(verso: str, aplicar_sinalefa: bool = True, verbose: bool = False):
    """Conta as sílabas métricas de um verso, aplicando:
    - sinalefa (elisão) entre palavras adjacentes vogal-final + vogal-inicial
    - corte no final: só conta até a sílaba tônica da última palavra
    Retorna um dict com o total e o detalhamento (útil para debug/relatório)."""
    palavras = [w for w in re.findall(r"[\wáéíóúâêôãõàçÁÉÍÓÚÂÊÔÃÕÀÇ']+", verso) if w]
    if not palavras:
        return {"total": 0, "detalhe": []}

    silabas_por_palavra = [contar_silabas_palavra(w) for w in palavras]
    detalhe = []

    total = 0
    for i, (palavra, n_sil) in enumerate(zip(palavras, silabas_por_palavra)):
        elidiu = False
        if aplicar_sinalefa and i > 0:
            anterior = palavras[i - 1]
            if termina_em_vogal_ou_nasal(anterior) and comeca_com_vogal(palavra):
                n_sil -= 1
                elidiu = True
        n_sil = max(1, n_sil) if not elidiu else max(0, n_sil)
        total += n_sil
        detalhe.append({"palavra": palavra, "silabas_contadas": n_sil, "sinalefa_com_anterior": elidiu})

    # Corte final: contar só até a tônica da última palavra
    pos_tonica = posicao_tonica(palavras[-1])  # 0=oxítona,1=paroxítona,2=proparoxítona
    total_ajustado = total - pos_tonica

    resultado = {
        "verso": verso,
        "total_bruto": total,
        "posicao_tonica_ultima_palavra": pos_tonica,
        "total_metrico": max(1, total_ajustado),
        "detalhe": detalhe,
    }
    if verbose:
        print(f"  Verso: {verso!r}")
        for d in detalhe:
            marca = " (sinalefa ↩)" if d["sinalefa_com_anterior"] else ""
            print(f"    {d['palavra']}: {d['silabas_contadas']} sílaba(s){marca}")
        print(f"    Tônica final: {'oxítona' if pos_tonica==0 else 'paroxítona' if pos_tonica==1 else 'proparoxítona'}")
        print(f"    TOTAL MÉTRICO: {resultado['total_metrico']}")
    return resultado


def contar_silabas_texto(texto: str, alvo: int = 7):
    """Roda a contagem em cada linha não vazia do texto e sinaliza quais
    versos fogem do número-alvo de sílabas (padrão: 7, redondilha maior)."""
    linhas = [l for l in texto.splitlines() if l.strip()]
    resultados = []
    for linha in linhas:
        r = contar_silabas_verso(linha)
        r["dentro_da_metrica"] = (r["total_metrico"] == alvo)
        resultados.append(r)
    return resultados


def _cli():
    ap = argparse.ArgumentParser(description="Conta sílabas poéticas de versos em português")
    ap.add_argument("verso", nargs="?", help="Verso único a medir (ou '-' para ler da stdin)")
    ap.add_argument("--arquivo", help="Arquivo de texto com um verso por linha")
    ap.add_argument("--alvo", type=int, default=7, help="Nº de sílabas alvo por verso (default: 7, redondilha maior)")
    ap.add_argument("--json", action="store_true", help="Saída em JSON")
    args = ap.parse_args()

    import json as _json

    if args.arquivo:
        with open(args.arquivo, encoding="utf-8") as f:
            texto = f.read()
        resultados = contar_silabas_texto(texto, alvo=args.alvo)
        if args.json:
            print(_json.dumps(resultados, ensure_ascii=False, indent=2))
        else:
            fora = 0
            for r in resultados:
                status = "OK" if r["dentro_da_metrica"] else f"FORA (alvo={args.alvo})"
                print(f"[{r['total_metrico']:>2} síl.] {status:<12} {r['verso']}")
                if not r["dentro_da_metrica"]:
                    fora += 1
            print(f"\n{len(resultados)} versos analisados, {fora} fora da métrica de {args.alvo} sílabas.")
        return

    if args.verso == "-" or (args.verso is None and not sys.stdin.isatty()):
        texto = sys.stdin.read()
        resultados = contar_silabas_texto(texto, alvo=args.alvo)
        if args.json:
            print(_json.dumps(resultados, ensure_ascii=False, indent=2))
        else:
            for r in resultados:
                status = "OK" if r["dentro_da_metrica"] else f"FORA (alvo={args.alvo})"
                print(f"[{r['total_metrico']:>2} síl.] {status:<12} {r['verso']}")
        return

    if args.verso:
        r = contar_silabas_verso(args.verso, verbose=not args.json)
        if args.json:
            print(_json.dumps(r, ensure_ascii=False, indent=2))
        return

    ap.print_help()


if __name__ == "__main__":
    _cli()
