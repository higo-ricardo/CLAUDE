#!/usr/bin/env python3
"""
checar_rima.py — Verifica se os versos finais de uma estrofe seguem o
esquema de rima esperado para a forma escolhida (sextilha, septilha,
décima de peleja, quadrão).

Uso:
    python3 checar_rima.py --forma sextilha "verso 1" "verso 2" ... "verso 6"
    python3 checar_rima.py --forma septilha --arquivo estrofe.txt
    python3 checar_rima.py --forma decima-peleja --arquivo estrofe.txt

Esquemas suportados (posição do verso -> grupo de rima; "-" = livre,
sem obrigação de rimar com ninguém):

  sextilha        (6 versos, 7 sílabas):  - A - A - A
                  (versos ímpares 1,3,5 livres; pares 2,4,6 rimam entre si)

  septilha        (7 versos, 7 sílabas):  A B A B C C B
                  (1º rima com 3º; 2º, 4º e 7º rimam entre si; 5º rima com 6º)

  decima-peleja   (10 versos, 7 sílabas): A B B A A C C D D C

  quadrao         (4 versos):             A B C B   (variante comum)
                  use --esquema-custom "A B C B" para forçar outro padrão

A extração da "rima" é uma HEURÍSTICA: pega o trecho da palavra a partir
da última vogal tônica até o fim (aproximação de rima consoante) e
compara esse trecho, ignorando acentos. Funciona bem para a maioria dos
casos de rima consoante regular; não detecta nuances de rima toante vs.
consoante — isso ainda exige o ouvido de quem está revisando.
"""

import argparse
import re
import sys
import unicodedata

ESQUEMAS = {
    "sextilha": ["-", "A", "-", "A", "-", "A"],
    "septilha": ["A", "B", "A", "B", "C", "C", "B"],
    "decima-peleja": ["A", "B", "B", "A", "A", "C", "C", "D", "D", "C"],
    "quadrao": ["A", "B", "C", "B"],
}


def _strip_accents(s: str) -> str:
    return "".join(
        c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn"
    )


VOGAIS = "aeiouAEIOU"
VOGAIS_ACENTUADAS = "áéíóúâêôãõàÁÉÍÓÚÂÊÔÃÕÀ"


def ultima_palavra(verso: str) -> str:
    palavras = re.findall(r"[\wáéíóúâêôãõàçÁÉÍÓÚÂÊÔÃÕÀÇ']+", verso)
    return palavras[-1] if palavras else ""


def extrair_rima(palavra: str) -> str:
    """Aproxima a 'rima' do verso: pega a partir da última vogal tônica
    até o fim da palavra, normalizado (minúsculo, sem acento)."""
    palavra = palavra.lower()
    if not palavra:
        return ""

    # localizar índice da última vogal com acento gráfico (marca a tônica)
    idx_tonica = None
    for i, c in enumerate(palavra):
        if c in VOGAIS_ACENTUADAS:
            idx_tonica = i

    if idx_tonica is None:
        # sem acento gráfico: aproximação -> penúltima vogal da palavra
        # (regra prática: maioria das palavras é paroxítona)
        indices_vogais = [i for i, c in enumerate(palavra) if c in VOGAIS]
        if not indices_vogais:
            return _strip_accents(palavra)
        if len(indices_vogais) == 1:
            idx_tonica = indices_vogais[0]
        else:
            # palavras terminadas em r/l/z/x/n/i/u/ão/ãe ou em nasal
            # -im/-om/-um/-em costumam ser oxítonas
            terminacoes_oxitonas = ("r", "l", "z", "x", "n", "i", "u")
            sem_acento = _strip_accents(palavra)
            if (
                sem_acento.endswith(terminacoes_oxitonas)
                or palavra.endswith(("ão", "ãe"))
                or sem_acento.endswith(("im", "om", "um", "em"))
            ):
                idx_tonica = indices_vogais[-1]
            else:
                idx_tonica = indices_vogais[-2]

    return _strip_accents(palavra[idx_tonica:])


def rimam(palavra_a: str, palavra_b: str) -> bool:
    return extrair_rima(palavra_a) == extrair_rima(palavra_b)


def checar_estrofe(versos_finais, esquema):
    """versos_finais: lista de últimas palavras (ou versos completos,
    a última palavra será extraída). esquema: lista tipo ['-','A','-','A',...]
    Retorna lista de problemas encontrados (vazia se tudo OK)."""
    if len(versos_finais) != len(esquema):
        return [f"Número de versos ({len(versos_finais)}) não bate com o esquema esperado ({len(esquema)} versos)."]

    ultimas = [ultima_palavra(v) if " " in v or len(v) > 3 else v for v in versos_finais]
    rimas = [extrair_rima(p) for p in ultimas]

    grupos = {}
    for i, letra in enumerate(esquema):
        if letra == "-":
            continue
        grupos.setdefault(letra, []).append(i)

    problemas = []
    for letra, indices in grupos.items():
        base_idx = indices[0]
        base_rima = rimas[base_idx]
        for idx in indices[1:]:
            if rimas[idx] != base_rima:
                problemas.append(
                    f"Verso {idx+1} ('{ultimas[idx]}') deveria rimar com o verso "
                    f"{base_idx+1} ('{ultimas[base_idx]}') [grupo {letra}], mas as "
                    f"terminações não batem ('{rimas[idx]}' vs '{rimas[base_idx]}')."
                )
    return problemas


def _cli():
    ap = argparse.ArgumentParser(description="Verifica esquema de rima de uma estrofe de cordel")
    ap.add_argument("versos", nargs="*", help="Versos da estrofe (um por argumento)")
    ap.add_argument("--arquivo", help="Arquivo com um verso por linha (estrofe única)")
    ap.add_argument("--forma", choices=list(ESQUEMAS.keys()), default="sextilha")
    ap.add_argument("--esquema-custom", help="Esquema customizado, ex.: 'A B C B' (sobrepõe --forma)")
    args = ap.parse_args()

    if args.esquema_custom:
        esquema = args.esquema_custom.split()
    else:
        esquema = ESQUEMAS[args.forma]

    if args.arquivo:
        with open(args.arquivo, encoding="utf-8") as f:
            versos = [l.strip() for l in f if l.strip()]
    else:
        versos = args.versos

    if not versos:
        ap.print_help()
        sys.exit(1)

    problemas = checar_estrofe(versos, esquema)
    print(f"Forma: {args.forma if not args.esquema_custom else 'custom'} | Esquema: {' '.join(esquema)}")
    for i, v in enumerate(versos):
        print(f"  {i+1}. [{esquema[i] if i < len(esquema) else '?'}] {v}  (rima: {extrair_rima(ultima_palavra(v))})")
    if problemas:
        print(f"\n{len(problemas)} problema(s) de rima encontrado(s):")
        for p in problemas:
            print(f"  - {p}")
    else:
        print("\nEsquema de rima OK.")


if __name__ == "__main__":
    _cli()
