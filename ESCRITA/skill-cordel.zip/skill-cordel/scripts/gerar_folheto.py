#!/usr/bin/env python3
"""
gerar_folheto.py — Monta um cordel em formato de folheto (docx), no
tamanho tradicional pequeno (~10x15cm), com capa (título, subtítulo,
autor e descrição textual da xilogravura) e miolo com as estrofes.

Uso:
    python3 gerar_folheto.py --config cordel.json --out folheto.docx

Formato esperado do JSON de config (ver references/schema-folheto.md):
{
  "titulo": "A CHEGADA DO CELULAR NO SERTÃO",
  "subtitulo": "Ou como o sertanejo aprendeu a viver com internet",
  "autor": "Nome do(a) autor(a)",
  "local_data": "Cidade — 2026",
  "xilogravura_descricao": "Um sertanejo de chapéu de couro segurando um celular, ao fundo um cacto e o sol nordestino, traço em preto e branco estilo xilogravura tradicional.",
  "estrofes": [
    ["Vou contar uma história", "Que ninguém vai duvidar", ...],
    [...]
  ],
  "moral_final": "E fica aqui registrado (opcional, última fala do cordel)"
}
"""

import argparse
import json
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement


LARGURA_FOLHETO = Cm(10.5)
ALTURA_FOLHETO = Cm(15.5)
MARGEM = Cm(1.2)


def _config_pagina_pequena(section):
    section.page_width = LARGURA_FOLHETO
    section.page_height = ALTURA_FOLHETO
    section.left_margin = MARGEM
    section.right_margin = MARGEM
    section.top_margin = MARGEM
    section.bottom_margin = MARGEM


def _borda_paragrafo(paragraph, tamanho_pt=12):
    """Aplica uma borda simples ao redor do parágrafo (usada para emular
    a moldura da xilogravura de capa em texto)."""
    p = paragraph._p
    pPr = p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    for lado in ("top", "left", "bottom", "right"):
        el = OxmlElement(f"w:{lado}")
        el.set(qn("w:val"), "single")
        el.set(qn("w:sz"), str(tamanho_pt))
        el.set(qn("w:space"), "8")
        el.set(qn("w:color"), "000000")
        pBdr.append(el)
    pPr.append(pBdr)


def montar_capa(doc, titulo, subtitulo, autor, local_data, xilogravura_descricao):
    doc.add_paragraph()
    p_titulo = doc.add_paragraph()
    p_titulo.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p_titulo.add_run(titulo.upper())
    run.bold = True
    run.font.size = Pt(20)

    if subtitulo:
        p_sub = doc.add_paragraph()
        p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run_sub = p_sub.add_run(subtitulo)
        run_sub.italic = True
        run_sub.font.size = Pt(12)

    doc.add_paragraph()

    # Moldura textual representando a xilogravura de capa
    p_xilo_label = doc.add_paragraph()
    p_xilo_label.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_label = p_xilo_label.add_run("[ XILOGRAVURA ]")
    run_label.font.size = Pt(9)
    run_label.font.color.rgb = RGBColor(0x66, 0x66, 0x66)

    p_xilo = doc.add_paragraph()
    p_xilo.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_xilo = p_xilo.add_run(xilogravura_descricao)
    run_xilo.italic = True
    run_xilo.font.size = Pt(9)
    _borda_paragrafo(p_xilo)

    doc.add_paragraph()
    doc.add_paragraph()

    if autor:
        p_autor = doc.add_paragraph()
        p_autor.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run_autor = p_autor.add_run(autor)
        run_autor.font.size = Pt(11)

    if local_data:
        p_data = doc.add_paragraph()
        p_data.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run_data = p_data.add_run(local_data)
        run_data.font.size = Pt(10)


def montar_miolo(doc, estrofes, numerar_estrofes=False):
    for idx, estrofe in enumerate(estrofes, start=1):
        if numerar_estrofes:
            p_num = doc.add_paragraph()
            p_num.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run_num = p_num.add_run(f"— {idx} —")
            run_num.font.size = Pt(8)
            run_num.font.color.rgb = RGBColor(0x88, 0x88, 0x88)
        for verso in estrofe:
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after = Pt(0)
            run = p.add_run(verso)
            run.font.size = Pt(12)
        doc.add_paragraph()  # linha em branco entre estrofes


def montar_colofao(doc, autor, local_data):
    doc.add_paragraph()
    p_fim = doc.add_paragraph()
    p_fim.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_fim = p_fim.add_run("FIM")
    run_fim.bold = True
    run_fim.font.size = Pt(13)

    doc.add_paragraph()
    p_colofao = doc.add_paragraph()
    p_colofao.alignment = WD_ALIGN_PARAGRAPH.CENTER
    texto_colofao = "Cordel"
    if autor:
        texto_colofao += f" de {autor}"
    if local_data:
        texto_colofao += f" — {local_data}"
    run_colofao = p_colofao.add_run(texto_colofao)
    run_colofao.font.size = Pt(8)
    run_colofao.font.color.rgb = RGBColor(0x88, 0x88, 0x88)


def gerar_folheto(config: dict, caminho_saida: str):
    doc = Document()
    _config_pagina_pequena(doc.sections[0])

    montar_capa(
        doc,
        titulo=config.get("titulo", "SEM TÍTULO"),
        subtitulo=config.get("subtitulo", ""),
        autor=config.get("autor", ""),
        local_data=config.get("local_data", ""),
        xilogravura_descricao=config.get("xilogravura_descricao", "(descrição da xilogravura não fornecida)"),
    )

    # nova seção para o miolo (permite, se necessário, numeração de página
    # separada da capa no futuro; aqui usamos quebra de página simples)
    doc.add_section(WD_SECTION.NEW_PAGE)
    _config_pagina_pequena(doc.sections[-1])

    montar_miolo(doc, config.get("estrofes", []), numerar_estrofes=config.get("numerar_estrofes", False))

    if config.get("moral_final"):
        p_moral = doc.add_paragraph()
        p_moral.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run_moral = p_moral.add_run(config["moral_final"])
        run_moral.italic = True
        run_moral.font.size = Pt(11)
        doc.add_paragraph()

    montar_colofao(doc, config.get("autor", ""), config.get("local_data", ""))

    doc.save(caminho_saida)
    return caminho_saida


def _cli():
    ap = argparse.ArgumentParser(description="Gera um folheto de cordel (.docx) a partir de um JSON de config")
    ap.add_argument("--config", required=True, help="Caminho do JSON com título, estrofes etc.")
    ap.add_argument("--out", required=True, help="Caminho do .docx de saída")
    args = ap.parse_args()

    with open(args.config, encoding="utf-8") as f:
        config = json.load(f)

    caminho = gerar_folheto(config, args.out)
    print(f"Folheto gerado em {caminho}")


if __name__ == "__main__":
    _cli()
