# Estrutura do cordel — formas de estrofe, métrica e narrativa

Referência técnica para escrever, avaliar ou corrigir cordéis. Consulte
este arquivo sempre que precisar checar o esquema de rima ou a métrica
exata de uma forma de estrofe.

## 1. Formas de estrofe mais usadas

### Sextilha (a forma-padrão do cordel narrativo)
- 6 versos por estrofe
- 7 sílabas poéticas por verso (redondilha maior)
- Rima: **versos ímpares (1º, 3º e 5º) são livres** — não têm obrigação
  de rimar entre si nem com nada; **versos pares (2º, 4º e 6º) rimam
  entre si** (mesma terminação). Notação: `- A - A - A`.
- É a forma-padrão para narrar uma história. Use como default sempre
  que o usuário não especificar outra.

### Septilha
- 7 versos, 7 sílabas
- Rima: **o 1º rima com o 3º; o 2º, o 4º e o 7º rimam entre si; e o 5º
  rima com o 6º**. Notação: `A B A B C C B`.

### Décima de peleja
- 10 versos, 7 sílabas — forma usada em desafios/repentes de poeta
  contra poeta (a "peleja")
- Rima: **A B B A A C C D D C**

### Quadrão (ou quadra/quarteto)
- 4 versos, geralmente 7 ou 10 sílabas
- Rima mais comum: **A B C B** (2º rima com o 4º; 1º e 3º livres)
- Usado para remates curtos, epígrafes ou introduções. Se o usuário
  pedir uma variante diferente de rima para o quadrão, siga a
  especificação dele — não é uma forma tão fixa quanto a sextilha.

### Martelo agalopado
- 10 versos, 10 sílabas por verso
- Rima: ABBAACCDDC (mesmo esquema da décima de peleja, mas em versos
  decassílabos em vez de redondilha maior)
- Usado tradicionalmente para desafios/repentes e para temas de maior
  fôlego épico ou humorístico mais "espalhafatoso"

### Galope à beira-mar
- 10 versos, 10 sílabas
- Rima: ABABABCDDC (esquema mais entrelaçado que o martelo)
- Considerado uma das formas mais difíceis de compor
- Tradicionalmente o último verso termina na expressão "beira-mar"

**Regra prática:** se o usuário não pedir uma forma específica, use
sextilha. Só ofereça as outras formas se o usuário pedir algo "mais
difícil", "estilo repente/martelo/peleja" ou sinalizar um desafio mais
avançado.

## 2. Métrica — como contar as sílabas

A contagem poética portuguesa vai **até a última sílaba tônica** do
verso (não até o fim físico da última palavra), e aplica **sinalefa**
(fusão de vogais entre palavras adjacentes quando uma termina em vogal
e a seguinte começa com vogal).

Use o script `scripts/contar_silabas.py` como apoio:

```bash
python3 scripts/contar_silabas.py "Vou contar uma história"
python3 scripts/contar_silabas.py --arquivo rascunho.txt --alvo 7
```

O script é uma heurística — ele erra em casos raros de hiato/ditongo
ambíguo (ex.: sequências como "ia", "ua" admitem duas leituras válidas
em português — sinérese, 1 sílaba, ou diérese, 2 sílabas — e o script
assume por padrão a leitura mais comum em palavras curtas, contando-as
como 2 sílabas separadas). Sempre que o resultado ficar 1 sílaba a mais
ou a menos do esperado, releia o verso em voz alta (mentalmente) e
ajuste por julgamento próprio antes de confiar cegamente no número.
Nunca entregue ao usuário um cordel sem rodar essa checagem pelo menos
uma vez em cada estrofe nova ou corrigida.

## 2.1 Rima — como checar o esquema

Métrica correta não garante rima correta — são checagens independentes
e **as duas são obrigatórias**. Use `scripts/checar_rima.py`:

```bash
python3 scripts/checar_rima.py --forma sextilha "verso 1" "verso 2" ... "verso 6"
python3 scripts/checar_rima.py --forma septilha --arquivo estrofe.txt
python3 scripts/checar_rima.py --forma decima-peleja --arquivo estrofe.txt
python3 scripts/checar_rima.py --forma quadrao --arquivo estrofe.txt
```

O script identifica a última palavra de cada verso, extrai a rima
(aproximação: do início da vogal tônica até o fim da palavra) e
verifica se os grupos que deveriam rimar (conforme a forma escolhida —
ver seção 1) realmente batem. Ele imprime exatamente quais versos
estão quebrando o esquema e com qual verso deveriam rimar — use essa
saída para saber quais versos reescrever, mantendo os demais.

Assim como o contador de sílabas, é uma heurística (não distingue nuances
de rima toante vs. consoante), mas pega a esmagadora maioria dos erros
reais — sobretudo o erro mais comum, que é escrever um verso par que
não rima com os outros pares da estrofe.

**Fluxo recomendado ao escrever (evita retrabalho):** antes de escrever
os versos de uma estrofe, decida primeiro as palavras finais dos versos
que precisam rimar (ex.: para sextilha, escolha a terminação dos versos
2, 4 e 6 antes de redigi-los por extenso). Escrever "de trás pra frente"
assim é muito mais rápido do que escrever a estrofe inteira e só depois
descobrir que os pares não rimam.

## 3. Estrutura narrativa do cordel

1. **Argumento (1ª estrofe):** apresenta o mote/tema, como um resumo do
   que vai ser contado — o leitor precisa saber do que se trata já na
   primeira estrofe.
2. **Desenvolvimento:** narra os fatos em ordem, com detalhes concretos,
   diálogos, reviravoltas — linguagem popular, oral, direta.
3. **Clímax/virada:** o ponto alto da história (ou da argumentação, se
   for cordel de opinião/denúncia).
4. **Conclusão/moral:** cordéis tradicionalmente fecham com uma reflexão,
   moral, ou "recado" ao leitor — não é obrigatório, mas é a assinatura
   do gênero. Fórmulas comuns: "Aqui termino essa história...",
   "E fica aqui registrado...", "Termino com esse recado...".
5. **Remate de despedida:** o poeta popular tradicionalmente se despede
   nominalmente ou com uma assinatura estilizada ao final.

## 4. Registro de linguagem

- Vocabulário popular nordestino: "cabra", "menino(a)", "sertão",
  "arretado", "égua" (interjeição), "oxente", "vixe", "num" (não),
  "pra" (para) — use com moderação e coerência, sem exagerar a ponto de
  virar caricatura. Para um repertório maior e categorizado (por
  registro tradicional/sertanejo × urbano contemporâneo, e por tipo —
  interjeição, pessoa, fauna/flora, expressão, ditado), consulte
  `references/dicionario.md`. A seção "Ditados e
  provérbios" daquele arquivo é especialmente útil para a estrofe de
  moral/conclusão (item 4 abaixo).
- Rima toante (vogais iguais, consoantes diferentes — ex.: "coração" /
  "chão") é aceita na tradição oral, mas rima consoante (perfeita) é
  mais valorizada em folhetos escritos. Prefira rima consoante quando
  possível; toante é aceitável como recurso, não como regra geral.
- Humor, ironia e exagero cômico são recursos centrais do gênero,
  mesmo em temas sérios.

## 5. Xilogravura e capa

A capa tradicional do cordel traz uma ilustração em xilogravura (talha
em madeira, traço preto e branco, alto contraste, bem popular/rústico)
relacionada ao tema central do folheto. Ao descrever uma xilogravura
para a capa, inclua:
- Elemento(s) central(is) da cena (personagem principal, objeto-símbolo)
- Cenário de fundo (sertão, cidade, mar, feira etc., conforme o tema)
- Estilo: sempre mencionar "traço preto e branco, estilo xilogravura
  popular nordestina, alto contraste" — isso é o que diferencia uma
  descrição de capa de cordel de uma ilustração genérica.

## 6. Cordel de encomenda (eventos)

Ao adaptar para aniversário, casamento, formatura ou evento corporativo:
- Colete: nome(s) do(s) homenageado(s), tipo de evento, data, 2-3
  detalhes/anedotas pessoais reais (isso é o que torna o cordel único —
  sem eles, o resultado fica genérico)
- Tom: pergunte se é para ser mais engraçado/zombeteiro (comum em
  cordel de aniversário) ou mais emocionado/celebratório (comum em
  bodas e formaturas) — pode ser uma mistura dos dois
- Estrutura: mesmo formato (argumento → desenvolvimento → moral), mas
  o "argumento" já anuncia o motivo da celebração, e o remate final
  costuma incluir votos/desejos ao homenageado
