# Schema do JSON de config para gerar_folheto.py

```json
{
  "titulo": "string — título do cordel, em maiúsculas no folheto final",
  "subtitulo": "string opcional — subtítulo explicativo, comum em folhetos de cordel",
  "autor": "string — nome do autor(a)",
  "local_data": "string — ex.: 'Fortaleza — 2026' ou apenas o ano",
  "xilogravura_descricao": "string — descrição textual da ilustração de capa (ver seção 5 de estrutura-cordel.md)",
  "estrofes": [
    ["verso 1", "verso 2", "verso 3", "verso 4", "verso 5", "verso 6"],
    ["...próxima estrofe..."]
  ],
  "moral_final": "string opcional — fala/moral de encerramento, mostrada em itálico antes do FIM",
  "numerar_estrofes": false
}
```

Notas:
- `estrofes` é uma lista de listas: cada sub-lista é uma estrofe, cada
  item da sub-lista é um verso (linha). O gerador não formata a rima —
  isso deve ser garantido no texto antes de montar o JSON.
- O documento gerado usa tamanho de página pequeno (~10,5 x 15,5 cm),
  imitando o formato físico tradicional do folheto de cordel.
- A "xilogravura" é representada como uma caixa de texto com borda,
  contendo a descrição — não uma imagem real. Se o usuário tiver acesso
  a geração de imagem (skill de imagegen, ou Claude in Chrome/outra
  ferramenta), ofereça gerar a imagem a partir dessa descrição e depois
  reconstruir o folheto substituindo a caixa de texto por uma imagem
  real (usando o skill de docx para inserir a imagem na capa).
