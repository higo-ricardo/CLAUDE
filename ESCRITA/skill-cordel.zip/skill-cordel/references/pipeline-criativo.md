# Caminho da criação — o pipeline único do cordel

Existe **um único pipeline** nesta skill, com 6 etapas em ordem de
precedência. Todo modo de uso (A, B, C, D, E — ver tabela em
`SKILL.md`) entra e sai deste mesmo pipeline em pontos diferentes;
não há um pipeline separado por modo. Isso existe porque a lista
antiga (9 passos soltos, mais um resumo quase idêntico duplicado no
`SKILL.md`) misturava decisões de naturezas diferentes numa sequência
plana e repetida em dois lugares — o que facilita pular etapa (ex.:
escrever verso sem ter decidido o arco da história) e facilita os dois
textos saírem de sincronia um do outro. Agora só existe esta versão.

**Pontos de entrada por modo:**

| Modo | Entra na etapa |
|---|---|
| A — mote já definido | Etapa 1, direto |
| B — palavras soltas | Gera 2-3 motes, usuário escolhe, **depois** entra na Etapa 1 |
| E — encomenda (evento) | Coleta dados do evento, **depois** entra na Etapa 1 (a 1.4 é o encaixe) |
| C — avaliar cordel pronto | Percorre as Etapas 1-4 como grade de critérios de leitura (não escreve nada) |
| D — corrigir cordel pronto | Roda a bateria da Etapa 4 primeiro para localizar o problema, depois reentra pontualmente na Etapa 3 só no trecho afetado |

**Regra geral de precedência entre etapas:** uma etapa só começa
quando a anterior está fechada. Não se escreve verso (Etapa 3) sem
outline (Etapa 2); não se gera o folheto (Etapa 6) com estrofes que
ainda não passaram pela Etapa 4. Dentro da Etapa 3↔4 há uma exceção
importante: elas alternam por estrofe, não rodam uma vez cada no fim.

**Regra sobre o dicionário (`references/dicionario.md`): consulta
obrigatória, não condicional.** As Etapas 1, 3 e 4 sempre consultam o
dicionário — a única coisa que varia é *qual registro* puxar de lá
(`trad` ou `urb`, conforme a ambientação decidida em 1.3), nunca *se*
consulta. Mesmo um cordel 100% urbano/contemporâneo consulta a seção
`urb` do dicionário; mesmo um cordel tradicional de sertão consulta a
seção `trad`. "Não usei o dicionário porque o tema não pedia" é
sempre um erro de processo.

---

## Etapa 1 — Concepção

*Responde: "sobre o que, em que forma, com que voz?"*

| # | Tarefa | Depende de |
|---|---|---|
| 1.1 | Confirmar ou definir o mote (Modo A: já vem pronto, só confirme se estiver vago; Modo B: escolher entre as 2-3 propostas geradas) | — |
| 1.2 | Perguntar, agrupado numa só rodada: forma de estrofe (default sextilha), tamanho aproximado, tom (humor/denúncia/moral/romance/ação) | 1.1 |
| 1.3 | Definir a **ambientação temporal/social** do mote (sertão antigo, cangaço, seca vs. tema urbano/atual) e, a partir dela, **consultar `dicionario.md` e decidir o registro** (`trad`, `urb`, ou mistura deliberada) que vai guiar o vocabulário das Etapas 3 e 4 | 1.1, 1.2 |
| 1.4 | Se for cordel de encomenda (Modo E): coletar tipo de evento, homenageado(s), 2-3 anedotas reais, tom desejado — isso alimenta 1.1-1.3, não substitui | 1.1–1.3 |

A 1.3 é obrigatória em todo mote, sem exceção — é o que evita
anacronismo (gíria `urb` recente na boca de um vaqueiro de 1930) e
excesso de caricatura (recheio de termos `trad` num cordel urbano de
humor leve).

## Etapa 2 — Arquitetura narrativa

*Responde: "o que acontece, em que ordem, e onde a história vira?"*
Ainda **sem escrever verso** — é rascunho em prosa/tópicos.

| # | Tarefa | Depende de |
|---|---|---|
| 2.1 | Esboçar o argumento: a 1 frase que a 1ª estrofe vai anunciar | Etapa 1 completa |
| 2.2 | Esboçar o arco em tópicos: fatos do desenvolvimento em ordem → ponto de clímax/virada → moral/conclusão | 2.1 |
| 2.3 | Se o tom pedir moral pronta, **consultar `dicionario.md`** (seção "Ditados e provérbios") e pré-selecionar um candidato para adaptar no remate | 2.2 |

Pular a Etapa 2 e ir direto para os versos é a causa mais comum de
retrabalho: sem saber onde o clímax cai, é fácil escrever estrofes de
desenvolvimento longas demais ou repetitivas.

## Etapa 3 — Composição (redação estrofe por estrofe)

*Responde: "quais palavras, nesta ordem, batendo métrica e rima?"*

| # | Tarefa | Depende de |
|---|---|---|
| 3.1 | Para a estrofe da vez, decidir primeiro as palavras finais dos versos que precisam rimar (2º/4º/6º na sextilha) | Etapa 2 |
| 3.2 | Escrever os versos completos, **puxando vocabulário de `dicionario.md`** no registro decidido em 1.3 | 3.1 |
| 3.3 | Seguir a sequência do arco (2.2): argumento → desenvolvimento → clímax → moral → remate de despedida do poeta | 3.1, 3.2 |

## Etapa 4 — Revisão técnica e de registro (por estrofe, não em lote)

*Responde: "esta estrofe que acabei de escrever está correta?"*

**Alterna com a Etapa 3, estrofe a estrofe** — não se acumula texto
para revisar tudo no final; cada estrofe nova passa por aqui antes de
começar a próxima.

| # | Tarefa | Ferramenta |
|---|---|---|
| 4.1 | Checar métrica (sílabas poéticas até a tônica, com sinalefa) | `scripts/contar_silabas.py` |
| 4.2 | Checar esquema de rima da forma escolhida | `scripts/checar_rima.py` |
| 4.3 | **Checar contra `dicionario.md`:** os termos regionais usados existem lá, condizem com o registro decidido em 1.3 e não estão em excesso (nem viraram caricatura)? | `references/dicionario.md` |
| 4.4 | Checar coerência: a estrofe ainda serve ao mote, ou se afastou do tema? | releitura própria |

4.1 e 4.2 são checagens mecânicas (rodar o script); 4.3 e 4.4 são
julgamento de leitura, mas as quatro são obrigatórias — inclusive a
4.3, mesmo quando nenhum termo regional "óbvio" foi usado (nesse caso
o resultado da checagem é "confirmar que a ausência é proposital", não
pular a etapa). Corrigiu algo? Rode a bateria inteira de novo na
estrofe alterada — ajustar métrica pode mudar a palavra final de um
verso e quebrar a rima ou trocar um termo regional por outro.

## Etapa 5 — Paratexto

*Responde: "como isso se apresenta na capa?"* Só depois do texto
inteiro estável — título e xilogravura devem refletir a história
final, não o rascunho.

| # | Tarefa |
|---|---|
| 5.1 | Gerar título (curto, impactante) e subtítulo (explicativo, formato "OU [gancho]") |
| 5.2 | Descrever a xilogravura de capa (elemento central + cenário + "traço preto e branco, estilo xilogravura popular nordestina") — ver seção 5 de `estrutura-cordel.md` |

## Etapa 6 — Editoração e entrega

*Responde: "como isso vira o objeto físico (folheto)?"*

| # | Tarefa |
|---|---|
| 6.1 | Montar o JSON de configuração conforme `schema-folheto.md` |
| 6.2 | Rodar `scripts/gerar_folheto.py` para montar o `.docx` (capa + miolo) |
| 6.3 | Converter para PDF e rasterizar para inspeção visual (mesmo fluxo de outras skills de documento) |
| 6.4 | Corrigir quebras de página estranhas ou estrofes cortadas ao meio, se houver, e refazer 6.2–6.3 |
| 6.5 | Copiar o `.docx` final para a pasta de saída e entregar com `present_files` |

---

## Resumo visual do caminho

```
1. Concepção          → mote, forma, tom, ambientação → registro no dicionário
        ↓
2. Arquitetura        → argumento, arco, clímax, moral (ainda em prosa)
        ↓
3. Composição   ⇄   4. Revisão técnica/registro   (por estrofe, repete,
                       sempre consultando o dicionário em 3.2 e 4.3)
        ↓
5. Paratexto           → título, subtítulo, xilogravura
        ↓
6. Editoração/entrega  → docx → pdf → QA visual → present_files
```

Modo C (avaliar) percorre as Etapas 1-4 como grade de critérios (mote,
arco, métrica, rima, registro contra o dicionário) sem passar pelas
Etapas 5-6 — e sem reescrever nada. Modo D (corrigir) reentra direto na
Etapa 4 nos trechos apontados, sem refazer 1-3 do zero.
