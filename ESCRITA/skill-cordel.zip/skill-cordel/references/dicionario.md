# Dicionário de linguajar nordestino

Repertório de vocabulário popular nordestino para consulta ao escrever
ou revisar um cordel. Reúne o glossário sertanejo fornecido pelo
usuário, expressões contemporâneas de giria coletadas em pesquisa e
um bloco de ditados/provérbios úteis para morais e remates.

**Objetivo:** dar musculatura lexical real para a seção 4
("Registro de linguagem") de `estrutura-cordel.md`, que hoje só diz
"use com moderação, sem virar caricatura" sem oferecer um repertório
concreto. Este dicionário é esse repertório.

## Como usar este dicionário (leia antes de aplicar)

Cada entrada traz duas etiquetas entre parênteses:

- **Registro** — `trad` (tradicional/sertanejo: vocabulário de raiz
  rural, vaqueiro, Caatinga, cangaço, oralidade antiga — funciona em
  *qualquer* cordel, histórico ou atual) ou `urb` (gíria urbana/jovem
  contemporânea, mais recente e às vezes regional a um único estado —
  soa **anacrônica** em cordel ambientado no sertão antigo, na seca,
  no cangaço etc.; funciona bem em cordel de tema atual, humor jovem,
  crítica social contemporânea, ou encomenda descontraída).
- **Categoria** — `interj` (interjeição), `adj` (estado/qualidade),
  `pess` (pessoa/tipo humano), `lugar`, `expr` (expressão
  verbal/idiomática), `fauna`, `flora`, `comida`, `música/festa`,
  `ditado` (provérbio pronto, frase completa).

**Regras de aplicação (usar nas Etapas 3 e 4 do pipeline criativo —
ver `pipeline-criativo.md`):**

1. Antes de escrever, confira o **tema/época** do cordel: sertão
   antigo, cangaço, seca → priorize `trad`. Tema urbano/atual (PIX,
   internet, política do dia) → pode misturar `trad` com `urb`, o
   contraste às vezes é o próprio humor do cordel.
2. Não recheie o texto de termos regionais a cada verso — isso é o
   que a seção 4 de `estrutura-cordel.md` chama de "virar
   caricatura". Um termo bem colocado no verso certo vale mais que
   cinco espremidos na mesma estrofe.
3. Prefira termos com **registro consistente entre si**: uma estrofe
   que mistura "oxente" (trad) com "migué" (urb, gíria recente) numa
   fala de vaqueiro do sertão de 1930 quebra a verossimilhança. Dentro
   da mesma fala/personagem, mantenha o registro coerente.
4. Ditados e provérbios (seção final) são material pronto para a
   estrofe de moral/conclusão — muitas vezes já veem prontos numa
   métrica próxima de 7 sílabas com pequeno ajuste.
5. Ao **avaliar** (Modo C) um cordel de terceiros, use este dicionário
   para checar se o vocabulário regional soa natural ou forçado —
   é o critério "Oralidade e registro" da avaliação.

---

## A

- **Aboio** *(música/festa, trad)* — canto melódico do vaqueiro, sem
  letra fixa ou com versos improvisados, usado para conduzir o gado.
- **Abestado** *(adj, trad)* — bobo, trouxa, tonto.
- **Açude** *(lugar, trad)* — reservatório para água da chuva, comum
  no semiárido.
- **Afeiçado / afeição** *(adj, trad)* — bem arrumado, elogio à
  aparência.
- **Alpercata** *(objeto, trad)* — sandália simples de couro do
  sertanejo.
- **Aluado** *(adj, urb)* — distraído, no mundo da lua.
- **Amancebado / amasiado** *(adj, trad)* — vive junto sem casar
  oficialmente.
- **Aperreado** *(adj, trad)* — aborrecido, chateado, agoniado.
- **Apombaiado** *(adj, urb)* — distraído, que não entende nada.
- **Arengar** *(expr, trad)* — discutir, provocar briga por motivo
  pequeno; quem faz isso é **arengueiro**.
- **Arretado** *(adj, trad)* — muito bom, valente, admirável — ou,
  conforme o tom, bravo/irritado. Ambiguidade proposital: "Esse
  forró tá arretado" (elogio) vs. "Fiquei arretado com ele" (raiva).
- **Arribar** *(expr, trad)* — levantar, partir, ir embora.
- **Avexado** *(adj, trad)* — apressado, impaciente, aflito. "Não
  fique avexado, ainda dá tempo."

## B

- **Baião** *(música/festa, trad)* — ritmo nordestino popularizado por
  Luiz Gonzaga, sanfona/zabumba/triângulo.
- **Barril** *(adj, urb)* — algo muito bom ou muito ruim, conforme o
  contexto.
- **Bodega** *(lugar, trad)* — pequeno comércio de bairro/interior.
- **Boi-bumbá** *(música/festa, trad)* — manifestação popular com
  música, dança e a morte/ressurreição do boi.
- **Buchada** *(comida, trad)* — vísceras de caprino/ovino temperadas
  e cozidas.
- **Buliçoso** *(adj, trad)* — inquieto, agitado, mexe em tudo.

## C

- **Cabra** *(pess, trad)* — homem, sujeito, pessoa em geral.
- **Cabra da peste** *(pess, trad)* — pessoa valente, corajosa,
  resistente, admirável; tom de respeito.
- **Cacimba** *(lugar, trad)* — poço ou escavação para água
  subterrânea.
- **Caixa-prego** *(lugar, urb)* — lugar muito distante, longínquo
  ("onde Judas perdeu as botas").
- **Cangaço** *(hist, trad)* — movimento/fenômeno histórico do sertão
  nordestino, fim do séc. XIX às primeiras décadas do séc. XX.
- **Cangaceiro** *(pess, trad)* — integrante de grupo armado do
  cangaço.
- **Carcará** *(fauna, trad)* — ave de rapina, símbolo de resistência.
- **Carne de sol** *(comida, trad)* — carne salgada e parcialmente
  desidratada.
- **Cavalo do cão** *(pess, urb)* — pessoa disposta a tudo, ou
  gabola, que gosta de contar vantagem.
- **Comer água** *(expr, urb)* — beber bebida alcoólica.
- **Comer mosca** *(expr, urb)* — distrair-se, perder uma oportunidade.
- **Correr frouxo** *(expr, trad)* — haver algo em grande abundância.
- **Cuscuz** *(comida, trad)* — flocos de milho hidratados e cozidos
  no vapor.

## D

- **Danado** *(adj, trad)* — travesso, esperto, ousado, hábil; também
  intensificador ("um calor danado!").
- **De hoje a oito** *(expr, trad)* — daqui a uma semana, no mesmo
  dia.
- **Desmantelo** *(adj, trad)* — desordem, confusão, bagunça.
- **Destá** *(interj, trad)* — "deixe estar"; conformação ou aviso de
  consequência futura.
- **Dizer arretado** *(expr, trad)* — fala muito boa, engraçada,
  marcante.
- **Do tempo do ronca** *(expr, trad)* — muito antigo, ultrapassado.

## E

- **Eita** *(interj, trad)* — espanto, surpresa, ênfase — de uso mais
  disseminado que "oxente", cabe em quase qualquer fala.
- **Enxerido** *(pess, trad)* — intrometido, mete-se no que não é
  chamado.
- **Esmorecer** *(expr, trad)* — perder a coragem, a disposição, a
  esperança.
- **Esparroso** *(adj, urb)* — chamativo, espalhafatoso.
- **Espinhela caída** *(adj, trad)* — pessoa desanimada, deprimida,
  desgostosa.
- **Estrebuchar** *(expr, trad)* — agitar-se, debater-se (inclusive
  antes de morrer); usado também como hipérbole cômica.
- **Estropiado** *(adj, trad)* — cansado, machucado, debilitado.

## F

- **Facheiro** *(flora, trad)* — cacto alto típico da Caatinga.
- **Farra** *(música/festa, trad)* — festa animada, com música e
  confraternização.
- **Ficar de butuca** *(expr, urb)* — ficar observando, prestando
  atenção de olho vivo.
- **Ficar de rolo** *(expr, urb)* — ter um caso/affair.
- **Forró** *(música/festa, trad)* — gênero musical/dança nordestina
  (baião, xote, xaxado, arrasta-pé).
- **Fuxico** *(expr, trad)* — conversa/fofoca sobre a vida alheia;
  também técnica artesanal de retalhos.

## G

- **Gibão** *(objeto, trad)* — vestimenta de couro do vaqueiro,
  proteção contra espinho.
- **Gogó** *(corpo, trad)* — garganta, voz. "Ter gogó" = ter boa voz
  ou falar muito.
- **Gota serena** *(interj, trad)* — interjeição de irritação.
- **Garrancho** *(objeto, trad)* — escrita difícil de ler; ou galho
  seco/espinhoso.

## H

- **Hehein** *(interj, urb)* — interjeição regional de concordância/
  confirmação ("hehein, é isso mesmo").

## I

- **Ispilicute** *(adj, urb)* — garota bonitinha, desinibida, levada
  (Ceará).

## J

- **Jurema** *(flora, trad)* — planta de importância cultural e
  religiosa para povos e comunidades tradicionais nordestinas.
- **Juazeiro** *(flora, trad)* — árvore do semiárido que permanece
  verde mesmo na seca.
- **Jumento** *(fauna, trad)* — animal de trabalho e transporte rural.

## L

- **Lida** *(expr, trad)* — trabalho cotidiano, sobretudo o trabalho
  pesado do campo.
- **Légua** *(unidade, trad)* — antiga unidade de distância, ainda
  presente em expressões populares.
- **Ligeiro** *(adj, trad)* — rápido, ágil, esperto.

## M

- **Macambira** *(flora, trad)* — planta resistente à seca, típica da
  Caatinga.
- **Mandacaru** *(flora, trad)* — cacto emblemático do sertão, símbolo
  de resistência à estiagem.
- **Mangar** *(expr, trad)* — zombar, tirar sarro de alguém.
- **Massa** *(adj, urb)* — muito bom, muito legal.
- **Matuto** *(pess, trad)* — pessoa do interior, dos costumes rurais.
- **Meu rei** *(interj, urb)* — saudação afetuosa, equivalente a
  "mano"/"cumpade".
- **Migué** *(expr, urb)* — desculpa esfarrapada, enrolação.
- **Mungunzá** *(comida, trad)* — milho branco cozido com leite e
  açúcar (também chamado canjica).
- **Muié** *(pess, trad)* — forma popular de pronunciar "mulher".

## O

- **Oxente / oxe** *(interj, trad)* — a interjeição mais icônica do
  Nordeste: surpresa, espanto, indignação, admiração, dúvida —
  conforme a entonação. Vem de "olha, gente!" contraído; ao longo do
  tempo virou "ôxe" e, em fala jovem, quase só "xi".

## P

- **Pamonha** *(comida, trad)* — milho verde ralado cozido na palha.
- **Pé de serra** *(lugar/música, trad)* — região próxima a serras; ou
  estilo tradicional de forró.
- **Peba** *(fauna, trad)* — tatu.
- **Pirão** *(comida, trad)* — creme de farinha de mandioca com caldo
  de carne ou peixe.
- **Preá** *(fauna, trad)* — pequeno roedor da Caatinga.
- **Puxar conversa** *(expr, trad)* — iniciar papo espontâneo.

## Q

- **Quenga** *(pess, trad/vulgar — usar com cautela)* — sentido
  pejorativo em certos contextos; também nome de prato ("quenga de
  galinha"). Depende muito da região/situação — confirme o tom com o
  usuário antes de usar em cordel de encomenda.
- **Quentura** *(adj, trad)* — calor intenso, típico do sertão.
- **Quixabeira** *(flora, trad)* — árvore nativa da Caatinga.

## R

- **Rapariga** *(pess, trad)* — moça/mulher jovem; pode ganhar sentido
  pejorativo conforme a região — mesma cautela da "quenga".
- **Rês** *(fauna, trad)* — animal de criação, sobretudo bovino.
- **Rochedo** *(lugar, trad)* — formação rochosa da paisagem
  sertaneja.
- **Roçado** *(lugar, trad)* — terra preparada para cultivo agrícola.

## S

- **Sanfoneiro** *(pess, trad)* — músico de sanfona.
- **Sertão** *(lugar, trad)* — região interiorana semiárida, berço da
  identidade nordestina.
- **Sofrência** *(adj, urb)* — sofrimento amoroso, termo da música
  popular contemporânea (forró eletrônico/sofrência).
- **São João** *(música/festa, trad)* — festa junina com fogueiras,
  quadrilha, comidas típicas.

## T

- **Tá cá peste** *(expr, urb)* — "tá difícil", "tá osso".
- **Tá com a mulesta** *(expr, urb)* — estar muito irritado; ou,
  conforme o contexto, algo muito intenso.
- **Tangerino** *(pess, trad)* — quem conduz/acompanha o gado.
- **Terreiro** *(lugar, trad)* — espaço aberto ao redor de casa rural;
  em contexto religioso, local de culto.
- **Tô na bruxa** *(expr, urb)* — estar com raiva.
- **Traia** *(objeto, trad)* — conjunto de utensílios/equipamentos de
  uma atividade. "Arrume a traia do vaqueiro."
- **Trincheira** *(lugar, trad)* — abrigo/defesa; uso metafórico para
  "lugar de proteção".

## V

- **Vaqueiro** *(pess, trad)* — trabalhador que cuida e conduz o gado,
  figura central da cultura sertaneja.
- **Vaquejada** *(música/festa, trad)* — prática de condução/derrubada
  de bovinos, hoje também evento esportivo.
- **Viração** *(expr, trad)* — mudança de vento; mudança repentina de
  tempo/situação.
- **Vixe** *(interj, trad)* — espanto, surpresa leve — mais suave que
  "oxente".
- **Vôti** *(interj, urb)* — espanto ("que negócio estranho", Bahia).

## X

- **Xaxado** *(música/festa, trad)* — dança/ritmo ligado ao cangaço,
  passos marcados e arrastados.
- **Xêro** *(expr, trad)* — forma carinhosa de dizer "cheiro"
  ("mande um xêro pra sua mãe").
- **Xodó** *(pess, trad)* — pessoa/animal/objeto muito querido.
- **Xote** *(música/festa, trad)* — ritmo/dança de origem europeia
  incorporado ao forró.

## Z

- **Zabumba** *(música/festa, trad)* — tambor grande, base do forró
  tradicional.
- **Zambê** *(música/festa, trad)* — manifestação afro-brasileira do
  Rio Grande do Norte.
- **Zé-povinho** *(pess, trad)* — o povo, as pessoas comuns.

---

## Ditados e provérbios (bons para morais e remates)

Cordel tradicionalmente fecha com moral/recado (ver seção 3 de
`estrutura-cordel.md`). Estes ditados são matéria-prima pronta para
essa estrofe final — muitos já nascem com cadência próxima da
redondilha maior (7 sílabas), exigindo só pequeno ajuste de métrica:

- "Água mole em pedra dura, tanto bate até que fura" — persistência
  vence a resistência.
- "Antes só do que mal acompanhado" — vale mais estar sozinho que em
  má companhia.
- "Quem não tem cão, caça com gato" — vira-se com o que se tem.
- "Filho de peixe, peixinho é" — semelhança entre pais e filhos.
- "À noite todos os gatos são pardos" — no escuro (ou na confusão),
  tudo parece igual.
- "Devagar se vai ao longe" — pressa nem sempre compensa.
- "Deus escreve certo por linhas tortas" — recorrente em morais de
  cordel de fé/resignação.
- "Quem com ferro fere, com ferro será ferido" — comum em cordéis de
  denúncia/justiça poética.

Ao usar um ditado pronto no remate, cheque a métrica com
`scripts/contar_silabas.py` do mesmo jeito que checaria um verso
autoral — ditado popular não está isento da regra.
