---
name: skill-cordel
description: Escreve, avalia ou corrige literatura de cordel brasileira — a partir de um mote pronto, ou a partir de palavras soltas (define o mote primeiro e depois escreve). Cobre sextilha (ABCBDB, 7 sílabas) e outras formas (martelo agalopado, galope à beira-mar, décima, quadrão), sugere título/subtítulo, descreve a xilogravura de capa, checa a métrica automaticamente e monta o folheto final em .docx (capa + miolo, no tamanho tradicional pequeno). Também atende cordel de encomenda para aniversário, casamento, formatura ou evento corporativo. Use esta skill sempre que o usuário mencionar "cordel", "folheto", "mote", "xilogravura", "sextilha", "repente" ou pedir um poema popular nordestino — mesmo que não diga explicitamente "cordel".
---

# Skill Cordel

Skill para escrever, avaliar e corrigir literatura de cordel, com saída
final em formato de folheto (.docx, capa + miolo).

Antes de mais nada: leia `references/estrutura-cordel.md` — ele traz o
detalhamento de todas as formas de estrofe, o esquema de rima de cada
uma, a regra de métrica portuguesa e o registro de linguagem esperado.
Este SKILL.md assume que você já consultou aquele arquivo.

Toda escrita, avaliação ou correção de cordel passa pelo **pipeline
único** descrito em `references/pipeline-criativo.md` — 6 etapas em
ordem de precedência, que consultam obrigatoriamente
`references/dicionario.md` nas Etapas 1, 3 e 4. Não existe um
pipeline diferente por modo: os modos A-E abaixo são só pontos de
entrada e saída diferentes no mesmo pipeline (a tabela de pontos de
entrada está no topo de `pipeline-criativo.md`). Leia aquele arquivo
antes de escrever, avaliar ou corrigir — as seções abaixo não repetem
os passos, só dizem onde cada modo entra.

## Recursos bundlados

```
skill-cordel/
├── SKILL.md
├── scripts/
│   ├── contar_silabas.py     — conta sílabas poéticas de um verso/arquivo
│   ├── checar_rima.py        — verifica o esquema de rima de uma estrofe
│   └── gerar_folheto.py      — monta o .docx final (capa + miolo)
└── references/
    ├── estrutura-cordel.md   — formas de estrofe, métrica, rima, narrativa, xilogravura
    ├── pipeline-criativo.md  — o pipeline único: 6 etapas, ordem de precedência, pontos de entrada por modo
    ├── dicionario.md         — dicionário de vocabulário/gírias/ditados nordestinos, com registro (tradicional × urbano) e categoria — consulta obrigatória nas Etapas 1, 3 e 4
    └── schema-folheto.md     — schema do JSON usado por gerar_folheto.py
```

## Identifique o modo de uso

| Pedido do usuário | Modo |
|---|---|
| Já tem um tema/mote definido, quer o cordel escrito | **A — Escrever a partir de mote** |
| Deu palavras soltas sem tema claro | **B — Palavras soltas → mote → cordel** |
| Trouxe um cordel pronto (dele ou de outra pessoa) para nota/crítica | **C — Avaliar** |
| Trouxe um cordel com problemas de métrica/rima para consertar | **D — Corrigir** |
| É para aniversário, casamento, formatura, evento corporativo | **E — Cordel de encomenda** (entra no pipeline único pela Etapa 1) |

---

## Modo A — Escrever a partir de um mote

Entrada direta na **Etapa 1** do pipeline único
(`references/pipeline-criativo.md`). Só confirme o mote com o usuário
se ele estiver vago (ex.: "a chegada do PIX no sertão" é específico o
suficiente; "sobre tecnologia" não é — peça o ângulo/história) e siga
o pipeline até a Etapa 6.

## Modo B — Palavras soltas → definir mote → escrever

1. Peça a lista de palavras soltas, se ainda não tiver.
2. Gere **2-3 propostas de mote** que conectem as palavras de forma
   coerente e interessante (não force todas as palavras a aparecerem
   literalmente no texto — elas devem inspirar o tema, não virar uma
   lista de itens no poema).
3. Apresente as propostas ao usuário para escolha (ou, se o usuário
   disser "só faça"/"escolhe você", siga com a proposta mais forte).
4. Com o mote escolhido, entre na **Etapa 1** do pipeline único, igual
   ao Modo A.

## Modo C — Avaliar um cordel existente

Percorra as **Etapas 1 a 4** do pipeline único como grade de
critérios de leitura (mote/Etapa 1, arco narrativo/Etapa 2, métrica e
rima/Etapa 4, registro contra `dicionario.md`/Etapa 4) — sem passar
pelas Etapas 5-6 e sem escrever nada:

1. **Métrica:** rode `scripts/contar_silabas.py --arquivo <arquivo>
   --alvo <N>` (N conforme a forma identificada) e liste quais versos
   fogem do alvo.
2. **Rima:** rode `scripts/checar_rima.py --forma <forma> --arquivo
   <arquivo>` e liste exatamente quais versos quebram o esquema
   esperado (ver seção 1 de estrutura-cordel.md para o esquema de cada
   forma). Não avalie rima "de ouvido" sem rodar o script primeiro.
3. **Estrutura narrativa:** a 1ª estrofe cumpre o papel de argumento?
   Há desenvolvimento, clímax e conclusão/moral?
4. **Oralidade e registro:** o texto soa bem lido em voz alta? Confira
   contra `references/dicionario.md` se os termos usados condizem com
   a ambientação do cordel (registro `trad` vs. `urb` — gíria urbana
   recente na boca de personagem do sertão antigo é um erro de
   verossimilhança tão real quanto errar a métrica) e se não viraram
   caricatura.
5. **Coerência do mote:** o poema se mantém fiel ao tema anunciado do
   início ao fim?

Dê um parecer concreto por critério (não apenas nota solta) e termine
com 2-4 sugestões de melhoria priorizadas. Não reescreva o cordel a
menos que o usuário peça — isso é o Modo D.

## Modo D — Corrigir um cordel existente

Reentra pontualmente na **Etapa 4** do pipeline único (localizar o
problema) e depois na **Etapa 3** só no trecho afetado (reescrever) —
sem refazer as Etapas 1-2 do zero:

1. Rode a mesma bateria de checagem do Modo C primeiro (métrica com
   `contar_silabas.py`, rima com `checar_rima.py`, e registro contra
   `dicionario.md`), para saber exatamente o que está fora do padrão.
2. Pergunte ao usuário (se não estiver claro): prefere **correção
   mínima** (ajustar só os versos problemáticos, preservando o resto
   ao máximo) ou **reescrita completa** de uma estrofe/trecho?
3. Aplique as correções e rode `contar_silabas.py` e `checar_rima.py`
   de novo nos versos/estrofes alterados para confirmar que entraram
   na métrica e na rima.
4. Mostre um "antes/depois" dos trechos alterados, não o poema inteiro
   repetido, a menos que a maior parte tenha mudado.

## Modo E — Cordel de encomenda (evento)

Alimenta a **Etapa 1** do pipeline único (item 1.4) antes de seguir
normalmente. Colete antes de escrever (agrupe as perguntas):
- Tipo de evento (aniversário, casamento, formatura, evento
  corporativo etc.) e nome(s) do(s) homenageado(s)
- 2-3 detalhes/anedotas pessoais reais — é isso que torna o cordel
  único; sem eles, o resultado fica genérico
- Tom desejado: mais engraçado/zombeteiro, mais emocionado/celebratório,
  ou uma mistura

Depois, siga o pipeline único normalmente, com o "argumento" (Etapa 2)
já anunciando o motivo da celebração e o remate final (Etapa 3)
incluindo votos/desejos ao homenageado.

---

## Montando o folheto (.docx)

Depois que o texto do cordel, título, subtítulo, autor e descrição da
xilogravura estiverem prontos:

1. Monte um JSON seguindo `references/schema-folheto.md`.
2. Rode:
   ```bash
   python3 scripts/gerar_folheto.py --config <config.json> --out <nome-do-cordel>.docx
   ```
3. Converta para PDF e confira visualmente antes de entregar (mesmo
   fluxo usado por outras skills de documento: `soffice.py --headless
   --convert-to pdf`, depois `pdftoppm` para rasterizar e checar com a
   ferramenta de visualização de imagem). Corrija quebras de página
   estranhas ou estrofes cortadas ao meio entre páginas, se houver.
4. Copie o `.docx` final para a pasta de saída e entregue ao usuário
   com `present_files`.

Se o usuário tiver acesso a geração de imagem (Visualizer, Claude in
Chrome, ou outra ferramenta de imagem) e quiser uma capa com ilustração
real em vez da caixa de texto, gere a imagem a partir da descrição da
xilogravura e substitua a caixa de texto por uma imagem inserida via
`python-docx` (mesma lógica do skill de docx para inserir imagens).

Se o usuário pedir apenas o texto (sem folheto), entregue o cordel
formatado em markdown no chat/artifact, sem rodar o gerador de docx —
o folheto é o formato default apenas quando o pedido é por um
documento entregável.
