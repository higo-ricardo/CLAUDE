# Presets de gênero — baseline do SESSION_STATE

Aplicados automaticamente na Interação 2 da inicialização de projeto (SKILL.md §3.4
e `translator_pipeline.py start`), para reduzir a entrevista a no máximo duas trocas.
O usuário só precisa informar `registro`, `tratamento`, `público-alvo` ou `modo de
entrega` quando quiser **divergir** do baseline do gênero escolhido.

| Gênero | Registro | Tratamento | Público-alvo | Modo de entrega |
|---|---|---|---|---|
| `literario` | neutro | você | adulto geral | capitulo |
| `tecnico` | formal | você | profissional/técnico | chunk |
| `infantil` | coloquial | você | infantil | capitulo |
| `academico` | erudito | você | acadêmico especializado | chunk |
| `outro` | neutro | você | adulto geral | livre |

## Racional por campo

- **Registro**: técnico e acadêmico partem de tom mais formal/erudito porque
  terminologia precisa costuma pesar mais que fluidez coloquial nesses gêneros;
  infantil parte de coloquial pelo motivo oposto.
- **Tratamento**: `você` como padrão universal — é a forma neutra mais comum em
  tradução comercial no PT-BR; `tu` fica reservado a pedido explícito (ex: tradução
  regionalizada ou personagem específico), nunca inferido do gênero.
- **Modo de entrega**: `chunk` (500 palavras) para técnico/acadêmico, onde revisão
  granular importa mais; `capitulo` para literário/infantil, onde manter a unidade
  narrativa reduz fragmentação de contexto; `livre` só no fallback `outro`, por
  falta de sinal para decidir.

## Trade-off assumido

Presets por gênero podem preencher errado em casos atípicos (ex: livro técnico com
tom deliberadamente coloquial, ou literário que exige `tu`). O custo de errar é baixo:
qualquer campo pode ser sobrescrito na Interação 2 ou depois via
`state_manager.py update --field project/<campo> --value <novo>`. Presets errados nunca
bloqueiam o pipeline — só os campos em `BLOCKING_FIELDS` (título, autor, gênero,
registro, tratamento) continuam obrigatórios, e o baseline já garante valor para
registro/tratamento.

## Correspondência de gênero em texto livre (Interação 1)

Para casar a resposta livre do usuário com uma chave da tabela acima:

| Usuário pode escrever | Gênero mapeado |
|---|---|
| literário, literario, ficção, romance, novela | `literario` |
| técnico, tecnico, manual, documentação | `tecnico` |
| infantil, juvenil, infanto-juvenil | `infantil` |
| acadêmico, academico, científico, tese | `academico` |
| qualquer outro texto / não reconhecido | `outro` (nunca bloquear por gênero não mapeado) |
