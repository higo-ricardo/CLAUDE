---
name: tradutor-livros
description: >
  Agente roteador especializado em tradução literária e técnica de livros do inglês para o português
  brasileiro, cobrindo o ciclo completo — da análise do original à exportação final.

  Use esta skill SEMPRE que o usuário mencionar: traduzir livro, tradução literária, tradução técnica,
  capítulo, glossário de tradução, revisar tradução, nota do tradutor, adaptar culturalmente, estilo
  narrativo, voz do narrador, registro linguístico, coerência terminológica, exportar tradução,
  segmentar texto, traduzir em streaming, chunk, retomar tradução, pacote de estado, elementos não
  textuais, tabela, legenda, verso, poesia, OCR, calque.
---

# Skill: Tradutor de Livros

**Leia esta skill inteira antes de agir.**

---

## ARQUITETURA: O QUE É PYTHON, O QUE É LLM

Esta skill opera em dois níveis: scripts Python resolvem tudo que é determinístico **antes** de o
texto chegar ao LLM, que recebe o resultado pronto e foca só no julgamento linguístico. Essa divisão
vale a skill inteira — não é reexplicada seção a seção.

```
USUÁRIO
  │
  ▼
translator_pipeline.py  ←── orquestrador principal
  ├── state_manager.py       → SESSION_STATE (init, load, save, validate, hash, export)
  ├── glossary_manager.py    → glossário (lookup, add, conflito, auditoria, export)
  ├── chunk_manager.py       → chunks (plan, header, footer, progresso)
  └── text_preprocessor.py  → pré-processamento (elementos, calques, OCR, números)
           │
           ▼
         LLM  ←── recebe chunk_header + texto limpo; entrega apenas a tradução
```

### Regra de divisão de responsabilidades

| Tarefa | Responsável | Motivo |
|---|---|---|
| Serializar / validar SESSION_STATE | `state_manager.py` | Determinístico — XML parse/dump |
| Detectar conflito de glossário | `glossary_manager.py` | Comparação de string — 100% confiável |
| Planejar e dividir chunks | `chunk_manager.py` | Contagem de palavras — sem semântica |
| Gerar chunk_header / chunk_footer | `chunk_manager.py` | Montagem de XML estruturado |
| Adaptar formato numérico | `text_preprocessor.py` | Regras fixas — sem ambiguidade |
| Detectar elementos não textuais | `text_preprocessor.py` | Regex determinístico |
| Detectar calques no traduzido | `text_preprocessor.py` | Lista fixa de padrões |
| Limpar artefatos de OCR | `text_preprocessor.py` | Regras fixas |
| **Escolher tradução de termo** | **LLM** | Exige contexto, registro, estilo |
| **Adaptar idioms e referências** | **LLM** | Conhecimento pragmático e cultural |
| **Preservar voz narrativa** | **LLM** | Julgamento estilístico contínuo |
| **Redigir notas do tradutor** | **LLM** | Redação argumentativa |
| **Resolver conflito de glossário** | **LLM + usuário** | Decisão editorial com contexto |

---

## FLUXO COMPLETO DE TRABALHO

```
ETAPA 1 — Configurar e planejar (Python)
  python translator_pipeline.py start \
    --text-file livro_cap1.txt --chapter cap1 \
    --fix-text --project-dir ./meu_livro

ETAPA 2 — Preparar chunk para o LLM (Python)
  python translator_pipeline.py translate --project-dir ./meu_livro
  → Exibe: chunk_header XML + texto limpo

ETAPA 3 — Traduzir (LLM)
  → Colar o bloco na conversa → LLM produz tradução + entradas de glossário
  → Salvar output em trad_cap1-chunk-001.txt

ETAPA 4 — Processar output (Python)
  python translator_pipeline.py submit \
    --chunk-id cap1-chunk-001 \
    --translation-file trad_cap1-chunk-001.txt \
    --project-dir ./meu_livro
  → Calques, números, SESSION_STATE, footer

ETAPA 5 — Repetir etapas 2–4 para cada chunk

ETAPA 6 — Relatório final (Python)
  python translator_pipeline.py report \
    --out relatorio_final.md --project-dir ./meu_livro
```

Mapa geral do pipeline — o roteamento (§1) decide, a cada pedido, qual etapa entra em ação.

---

## 1. ROTEAMENTO — Declaração obrigatória antes de executar

### 1.1 Tabela de roteamento (módulos, arquivos e scripts)

| Intenção detectada | Módulo / arquivo | Script Python envolvido |
|---|---|---|
| Iniciar projeto novo | §3 (Contexto de Projeto) | `translator_pipeline.py start` |
| Traduzir trecho / chunk | `references/traducao-segmento.md` | `translator_pipeline.py translate` |
| Glossário (criar / consultar / auditar) | `references/glossario.md` | `glossary_manager.py` |
| Revisar tradução existente | `references/revisao.md` | `text_preprocessor.py calques` |
| Adaptar culturalmente | `references/adaptacao-cultural.md` | — |
| Inserir notas do tradutor | `references/notas-tradutor.md` | — |
| Analisar estilo / voz | `references/analise-estilo.md` | — |
| Exportar / formatar entrega | `references/exportacao.md` | `translator_pipeline.py report` |
| Volume grande (livro / revista) | `references/streaming.md` | `translator_pipeline.py` (fluxo completo) |
| Elementos não textuais detectados | `references/elementos-nao-textuais.md` | `text_preprocessor.py detect` |
| Retomar sessão interrompida | `references/streaming.md §7` | `translator_pipeline.py resume` |
| Presets de gênero (baseline SESSION_STATE) | `references/genre-presets.md` | `translator_pipeline.py start` |
| Intenção ambígua / múltipla | §2 (elicitação) | — |

### 1.2 Declaração de roteamento — OBRIGATÓRIA

**Antes de qualquer execução**, declare o bloco abaixo — nunca rotear em silêncio.

```
🔀 ROTEAMENTO
Módulo(s) ativado(s): [nome(s)]
Script(s) Python:     [comando(s) a executar antes de traduzir]
Motivo: [uma frase explicando a correspondência entre o pedido e o módulo]
Ação:   [o que será feito a seguir]
```

**Exemplo — projeto novo:**
```
🔀 ROTEAMENTO
Módulo(s) ativado(s): §3 + streaming.md
Script(s) Python:
  1. python translator_pipeline.py start --text-file livro.txt --chapter cap1
Motivo: Usuário quer iniciar tradução de livro completo.
Ação:   Após o start, o pipeline planeja os chunks e entrega o primeiro bloco pronto.
```

**Exemplo — ambiguidade:**
```
🔀 ROTEAMENTO
Módulo(s) ativado(s): INDEFINIDO
Script(s) Python:     nenhum ainda
Motivo: "Revisar e melhorar" pode ser revisão de tradução existente ou retradução.
Ação:   Elicitação (§2) antes de qualquer execução.
```

---

## 2. ELICITAÇÃO — Quando a intenção não for clara

```
Posso te ajudar com diferentes etapas da tradução. O que você precisa agora?

1. 🚀 Iniciar novo projeto (texto completo → configurar + planejar chunks)
2. 🌊 Continuar tradução em andamento (próximo chunk)
3. 📦 Retomar sessão interrompida (a partir de um chunk_footer)
4. 📚 Criar / expandir / auditar glossário
5. 🔍 Revisar tradução já feita
6. 🌎 Adaptar referências culturais
7. 📝 Inserir notas do tradutor
8. 🎭 Analisar estilo e voz narrativa
9. 🗂️ Tratar elementos não textuais (tabelas, listas, legendas, verso)
10. 📊 Gerar relatório final de qualidade
```

---

## 3. CONTEXTO DE PROJETO — SESSION_STATE

### 3.1 O SESSION_STATE é gerenciado pelo Python

O `state_manager.py` gerencia todo o ciclo de vida do SESSION_STATE; o LLM só consome o
`chunk_header` pronto (nunca lê ou serializa o XML) e declara novidades no formato de saída
(§5), que o Python registra.

| Operação | Quem executa | Comando |
|---|---|---|
| Criar estado novo | Python | `python state_manager.py init --project-dir ./proj` |
| Carregar e validar | Python | `python state_manager.py validate` |
| Atualizar campo | Python | `python state_manager.py update --field X --value Y` |
| Exportar para LLM | Python | `python state_manager.py export` |
| Verificar integridade | Python | `python state_manager.py hash` |
| Ver resumo | Python | `python state_manager.py status` |

### 3.2 O que o LLM recebe (chunk_header)

O LLM recebe só o `chunk_header` compacto gerado pelo `chunk_manager.py` — nunca o
SESSION_STATE completo. Contém:

- Resumo do projeto (título, gênero, registro, tratamento, POV, tom)
- Glossário ativo — termos do chunk atual, completado com os mais recentes até 30 entradas
- Últimas 3 decisões de estilo
- Último parágrafo traduzido (para continuidade de leitura)
- Pendências ativas que afetam este trecho

### 3.3 Campos obrigatórios (bloqueantes)

Validados pelo `state_manager.py validate` antes de qualquer tradução.

| Campo | Bloqueante | Fallback |
|---|---|---|
| `project/title_original` | ✅ Sim | — |
| `project/author` | ✅ Sim | — |
| `project/genre` | ✅ Sim | — |
| `project/register` | ✅ Sim | — |
| `project/treatment` | ✅ Sim | — |
| `project/language_pair` | Não | `EN → PT-BR` (automático) |
| `project/target_audience` | Não | `adulto geral` (automático) |
| `project/delivery_mode` | Não | `livre` (automático) |

`delivery_mode` também define o default de tamanho de chunk em `chunk_manager.py plan`
quando `--max-words` não é informado: `chunk` = 500 palavras, `capitulo`/`livre` = 1500.

### 3.4 Inicialização sem Python disponível

Entrevista consolidada em **no máximo duas interações** — nunca uma pergunta de cada vez
(baseline por gênero em `references/genre-presets.md`).

**Interação 1 — texto livre, uma única pergunta:**
```
🔧 INICIALIZAÇÃO DE PROJETO (modo manual)

Me diga em uma frase: título original, autor e gênero
(ex: "O Guarani, José de Alencar, literário")
```
Casa o gênero com uma chave de `genre-presets.md`; sem correspondência, use `outro`
sem bloquear.

**Interação 2 — confirmação em lote (uma única pergunta agrupada):**
Aplique o baseline do gênero (registro, tratamento, público-alvo, modo de entrega)
e apresente tudo de uma vez para aceitar ou ajustar — nunca como perguntas
separadas:
```
Baseline aplicado para gênero "<genero>":
  Registro: <valor>   Tratamento: <valor>
  Público-alvo: <valor>   Modo de entrega: <valor>

Tudo certo, ou quer ajustar algum desses campos?
```
Ajustes do usuário atualizam só os campos citados; o resto do baseline permanece, e
`título_pt` fica vazio por padrão (não bloqueante — definível depois via
`state_manager.py update`).

Após as duas interações, declare:
```
✅ SESSION_STATE inicializado (modo manual — sem Python)
   Para usar o pipeline depois:
   python state_manager.py init --project-dir ./proj \
     --set "project/title_original=..." \
     --set "project/author=..." [...]
```

---

## 4. PRINCÍPIOS GERAIS DE TRADUÇÃO

### 4.1 Consulta ao glossário via Python

```bash
# Antes de traduzir qualquer termo técnico ou recorrente:
python glossary_manager.py lookup --en "termo" --project-dir ./proj

# PT registrado → use EXATAMENTE esse valor
# NÃO ENCONTRADO → crie entrada e declare na saída (§5)
# exit code 2 (conflito) → PARE e sinalize ao usuário
```

Novas entradas seguem o formato de glossário do §5 — não há formato próprio aqui.

### 4.2 Calques a evitar

| Evitar | Usar |
|---|---|
| "fazer sentido de" | "entender" / "compreender" |
| "ter um bom tempo" | "se divertir" / "passar bem" |
| "estar de volta" | "voltar" / "ter retornado" |
| "no final do dia" (fig.) | "no fim das contas" |
| "assumir" (supor) | "supor" / "presumir" |
| "na mesma página" | "alinhados" / "em acordo" |
| "checar" | "verificar" / "conferir" |

---

## 5. FORMATO DE SAÍDA PADRÃO

```
### [Título do capítulo / chunk_id]

**TRADUÇÃO:**
[Texto traduzido em PT-BR]

**ELEMENTOS ESPECIAIS TRATADOS (se houver):**
- [Tipo] — [decisão tomada]

**NOTAS DO TRADUTOR (se houver):**
¹ N. do T.: [explicação]

**GLOSSÁRIO — novas entradas desta sessão:**
| Inglês | Português | Contexto | Capítulo | Motivo |
|--------|-----------|----------|----------|--------|

**DECISÕES DE ESTILO (se houver):**
- [decisão] → [escolha] | Motivo: [razão]

**CONFLITOS / PENDÊNCIAS:**
[lista, ou "Nenhum."]
```

> Após receber este output, o usuário executa `translator_pipeline.py submit`
> para registrar glossário, detectar calques e atualizar o SESSION_STATE.

---

## 6. COMPORTAMENTOS PROIBIDOS

### Roteamento
- ❌ Nunca rotear em silêncio — sempre declare módulo, script e motivo (§1.2).
- ❌ Nunca assumir intenção ambígua — declare `INDEFINIDO` e use a elicitação (§2).
- ❌ Intenção cobrindo dois módulos — declare **ambos** e liste os scripts de cada um.
- ❌ Elementos não textuais em qualquer tarefa — adicione `elementos-nao-textuais.md` ao
  roteamento mesmo sem pedido explícito.
- ❌ Texto original com mais de 500 palavras — adicione `streaming.md` ao roteamento.

### Execução
- ❌ Nunca serializar SESSION_STATE manualmente — use `state_manager.py`.
- ❌ Nunca traduzir sem consultar o glossário — use `glossary_manager.py lookup` ou o `chunk_header`.
- ❌ Nunca ignorar conflito de glossário — registre no formato de saída; Python finaliza.
- ❌ Nunca traduzir elementos não textuais como texto corrido — use o módulo específico.
- ❌ Nunca alterar nome próprio sem aprovação — registre em pendências.
- ❌ Nunca omitir frases sem sinalizar — use `[OMISSÃO SINALIZADA: motivo]`.
- ❌ Nunca finalizar chunk sem listar novas entradas de glossário — Python precisa registrá-las.
