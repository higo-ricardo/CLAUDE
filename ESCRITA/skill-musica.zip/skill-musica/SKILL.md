---
name: skill-musica
description: >
  Compõe, corrige, avalia e analisa letras de música em português,
  com conceitos como motivo, forma, textura, dinâmica e prosódia —
  sem notação musical, foco em texto cantável. Cobre formas
  internacionais (verso-refrão, AABA, estrófica) e gêneros brasileiros
  (samba-canção, partido-alto, moda de viola, sertanejo, forró, MPB,
  bossa nova, funk, axé/pagode). Use sempre que o usuário quiser
  escrever letra de música, compor refrão/gancho, corrigir uma letra
  para caber na melodia, checar se o verso 2 tem a mesma métrica do
  verso 1, avaliar a estrutura (verso/refrão/ponte), adaptar uma letra
  para um gênero brasileiro, ou partir de palavras soltas / uma frase
  para criar ou revisar uma canção identificando o tema central. Ative
  mesmo sem termos técnicos — "escreve uma letra de sertanejo sobre X",
  "tenho essas palavras: mar, farol, voltar — faz uma música", "essa
  estrofe não encaixa na melodia", "monta a estrutura dessa música" ou
  "corrige pra cantar certo" já bastam.
---

# Oficina de Letras

Uma skill para escrever letra de música em português com o vocabulário
certo (motivo, forma, textura, prosódia) sem perder de vista que esses
conceitos servem à canção — não são um fim em si. O trabalho não é só
fazer a métrica bater: é entender que toda linha vai ser cantada em
cima de uma melodia (mesmo que ela não exista ainda, ou não seja
composta por você), e que isso muda as regras em relação a escrever um
poema para ser lido.

A diferença mais importante para poesia: **seções do mesmo tipo
geralmente compartilham a mesma melodia.** Se "Verso 2" tem uma sílaba
a mais que "Verso 1" na mesma posição, alguém vai ter que esticar a
melodia, cortar uma nota, ou a frase simplesmente não vai caber — e se
o esquema de rima muda de ABAB para ABCD entre as duas, a segunda
estrofe perde o efeito sonoro que a primeira criou, mesmo com a
métrica perfeita. Por isso a consistência *entre* seções repetidas
(sílabas e rima) importa tanto quanto a métrica *dentro* de cada
verso.

Esta skill tem **3 modos**, cada um com pipeline própria (Etapas →
Tarefas) em `references/`, e **2 workflows** que combinam esses modos
numa ordem fixa:

- **Modo CRIAÇÃO** (`pipeline-criacao.md`) — escreve uma letra **nova**
  do zero. Nunca parte de uma letra existente.
- **Modo REVISÃO** (`pipeline-revisao.md`) — corrige/refatora uma
  letra que **já existe**. Nunca escreve seção nova nem decide tema.
- **Modo AVALIAÇÃO** (`pipeline-avaliacao.md`) — diagnostica uma letra
  já escrita (forma, gancho, consistência, rima, e o núcleo do modo:
  **musicalidade** — frases pesadas, cacofonia, eco, excesso de
  palavras). Nunca edita, só diagnostica.

CRIAÇÃO e REVISÃO são **independentes** — criar é diferente de
refatorar algo pronto — mas os dois **compartilham** o modo AVALIAÇÃO
como fase de diagnóstico, cada um aplicando-a ao seu próprio conteúdo e
momento:

> **Workflow CRIAR = modo CRIAÇÃO → modo AVALIAÇÃO** (avalia o que
> acabou de ser escrito, ao final).
> **Workflow REVISAR = modo AVALIAÇÃO → modo REVISÃO**, nessa ordem
> (avalia o que já existe **antes** de mexer em qualquer linha — o
> diagnóstico é o que decide o que revisar).

Para um pedido pontual que não é nem criar nem revisar uma letra
inteira (só tirar dúvida de conceito, só consultar um gênero), vá
direto à referência correspondente sem rodar pipeline nenhuma.

Todos os modos compartilham a mesma base de conceitos — leia primeiro:

- `references/pipeline-criacao.md`, `references/pipeline-revisao.md`,
  `references/pipeline-avaliacao.md` — as três pipelines (Etapas →
  Tarefas), com os pontos exatos onde a tarefa varia conforme o
  gênero.
- `references/elementos-musicais.md` — motivo, frase/período, forma,
  textura, dinâmica, andamento/prosódia, timbre, tensão e resolução,
  aplicados a decisões concretas de letra.
- `references/formas-e-generos.md` — catálogo de formas internacionais
  (verso-refrão, AABA, estrófica) e gêneros brasileiros (samba-canção,
  partido-alto, moda de viola, sertanejo universitário, forró, MPB,
  bossa nova, funk carioca, axé/pagode), com a sequência típica de
  seções e o que caracteriza cada um.
- `references/dicionario-generos.md` — termos, interjeições,
  instrumentos e registro típicos de cada gênero (o *léxico*; a forma
  em si está em `formas-e-generos.md`). Fonte de dados:
  `scripts/dicionario_generos.json`, consultável via
  `--vocabulario <genero>`.
- `references/tema-e-campo-semantico.md` — como transformar palavras
  soltas ou uma frase em um tema central, e campos semânticos
  recorrentes na canção brasileira para expandir esse tema em imagens.

## Partir de palavras soltas ou de uma frase

Quando o ponto de partida não é um pedido já formado ("escreve sobre
X"), mas uma lista de palavras soltas ("mar, farol, voltar") ou uma
frase inteira, o primeiro passo — antes de forma, motivo ou métrica —
é identificar o **tema central**: não o assunto (o que as palavras
nomeiam), mas o ângulo emocional que as conecta (o que a canção vai
*dizer* sobre elas). Abra `references/tema-e-campo-semantico.md` para
o roteiro completo; em resumo:

1. Agrupe as palavras por campo semântico e procure o fio emocional
   que as liga — a mesma lista de palavras admite mais de um ângulo
   possível (ex.: "mar, farol" pode virar solidão, coragem de partir
   ou alívio de reencontro).
2. Escolha um ângulo e diga-o numa frase antes de escrever qualquer
   verso ("uma letra sobre..."). Se o pedido deixar isso genuinamente
   ambíguo entre caminhos muito diferentes, faça uma pergunta curta
   em vez de arriscar escrever na direção errada; se o contexto já
   decide (tom da frase, gênero pedido, uma palavra com carga óbvia),
   nomeie a escolha na resposta e siga.
3. Distribua as palavras-semente a partir do ângulo escolhido: qual
   vira candidata a motivo/gancho (a mais carregada ou mais sonora),
   quais viram imagens nos versos, e se alguma sugere gênero ou forma.
4. Se o pedido for revisar uma letra já existente (não criar do
   zero), identifique primeiro o tema que ELA já carrega antes de
   assumir que a palavra/tema novo substitui o antigo — às vezes o
   pedido é reforçar, não trocar.

Depois de decidido o tema central, siga para o **modo CRIAÇÃO** ou
**modo REVISÃO** normalmente.

## Marcação de seções

Para o script funcionar, escreva (ou peça para o usuário colar) a letra
com cabeçalhos de seção entre colchetes, um por linha, numerando
repetições do mesmo tipo:

```
[Verso 1]
linha 1
linha 2

[Refrão]
linha 1
linha 2

[Verso 2]
linha 1
linha 2

[Refrão]
linha 1
linha 2
```

Tipos comuns: `Verso`, `Pré-Refrão`, `Refrão`, `Ponte`, `Intro`,
`Outro`. Para AABA use `A 1`, `A 2`, `B`, `A 3`. Se o usuário mandar uma
letra sem cabeçalhos, ou é porque ainda não pensou em seções (tudo bem
— trate como rascunho livre e sugira uma divisão), ou porque quer só
checar versos soltos (aí o script funciona igual, sem comparação entre
seções).

## `scripts/analisar_letra.py`

Contar sílabas de cabeça é enganoso, e comparar duas estrofes "de
ouvido" para ver se cabem na mesma melodia é ainda mais — use o script
sempre que precisar de uma checagem confiável:

```bash
# relatório por seção: sílabas de cada linha + esquema de rima
python3 scripts/analisar_letra.py --arquivo letra.txt

# checagem crucial: seções do mesmo tipo têm a mesma contagem
# silábica E o mesmo esquema de rima linha a linha? (senão, não
# encaixam na mesma melodia, mesmo que a métrica sozinha pareça ok)
python3 scripts/analisar_letra.py --arquivo letra.txt --consistencia

# relatório de rima expandido por seção (tonicidade, qualidade sonora)
python3 scripts/analisar_letra.py --arquivo letra.txt --rima

# sugere palavras que rimam com uma dada — pra compor, não só avaliar
# (banco interno de ~450 palavras comuns; consoantes primeiro, toantes depois)
python3 scripts/analisar_letra.py --buscar-rima "farol"

# só a sequência de seções e quantas linhas cada uma tem
python3 scripts/analisar_letra.py --arquivo letra.txt --estrutura

# compara a sequência de seções contra o perfil de um gênero cadastrado
python3 scripts/analisar_letra.py --arquivo letra.txt --validar sertanejo_universitario
python3 scripts/analisar_letra.py --listar-generos   # ver todos os perfis estruturais

# termos, interjeições, instrumentos e registro típicos de um gênero
# (léxico — diferente de --validar, que é estrutura)
python3 scripts/analisar_letra.py --vocabulario forro_pe_de_serra

# ritmo e musicalidade: eco, candidatas a cacofonia, frases pesadas,
# excesso de palavras/muletas — ver "Modo AVALIAÇÃO" abaixo
python3 scripts/analisar_letra.py --arquivo letra.txt --musicalidade

# contagens objetivas: seções, linhas, palavras, média de sílabas
python3 scripts/analisar_letra.py --arquivo letra.txt --stats

# densidade do gancho: detecta automaticamente linhas que se repetem
# verbatim (candidatas a motivo/gancho) e aponta onde aparecem
python3 scripts/analisar_letra.py --arquivo letra.txt --gancho

# ou conta quantas vezes uma frase específica aparece (exata ou como
# trecho de linha maior) e em quais seções
python3 scripts/analisar_letra.py --arquivo letra.txt --gancho "Volta, que a luz não apaga"

# verso avulso, sem seção nenhuma
python3 scripts/analisar_letra.py "Vim de longe pra te ver"
```

**Densidade do gancho, na prática:** um motivo lírico que aparece só
uma vez (nunca se repete) provavelmente não vai "grudar" na memória de
quem ouve — vale considerar repetir em mais um retorno do refrão. Um
motivo repetido mais de 4-5 vezes ao longo da letra corre o risco
oposto, de cansar, a menos que o gênero peça exatamente essa repetição
(funk, axé, forró de salão costumam tolerar — e até querer — bem mais
repetição do que MPB ou balada). Sem argumento, `--gancho` também serve
de checagem rápida antes de fechar uma letra: se nenhuma linha se
repete em lugar nenhum, pode ser sinal de que o motivo ainda não foi
fixado — vale perguntar ao usuário se isso é intencional.

**Buscador de rimas, na prática:** `--buscar-rima` separa
`rimas_consoantes` (som idêntico a partir da vogal tônica — a rima
"cheia") de `rimas_toantes` (mesma vogal tônica, consoante final
livre — mais fraca, mas ainda soa como rima em muitos gêneros,
principalmente os de fluxo mais falado). Prefira consoante por padrão;
ofereça toante quando o banco não tiver opção consoante boa, ou quando
o gênero tolerar bem rima mais solta. O banco cobre ~450 palavras
comuns — não é dicionário completo, então quando ele não retornar nada
bom (`observacao` no resultado avisa isso), gere candidatas
manualmente a partir do campo semântico do tema (ver
`tema-e-campo-semantico.md`) em vez de forçar uma das opções fracas do
banco.

**O script é uma ferramenta de apoio, não um oráculo.** A separação
silábica e a acentuação do português têm exceções (hiatos sem acento
gráfico, nomes próprios, regionalismos), e uma divergência de 1 sílaba
entre duas estrofes pode caber perfeitamente numa melodia real (uma
nota vira duas, uma pausa absorve a diferença) — principalmente em
gêneros de fluxo mais falado (funk, trechos de forró, rap). Trate o
relatório como ponto de partida objetivo: mostre o número, mas
converse sobre se a divergência é problema ou é uma variação que o
usuário quer manter.

## Modo CRIAÇÃO

Versão resumida da `pipeline-criacao.md` para consulta rápida; a
pipeline tem o detalhamento completo em Etapas → Tarefas.

1. Confirme (ou infira do pedido) tema, tom emocional e gênero/forma
   desejados. Se o ponto de partida for palavras soltas ou uma frase
   em vez de um tema já definido, resolva isso primeiro (ver "Partir
   de palavras soltas ou de uma frase" acima). Sem gênero especificado,
   o padrão pop enxuto
   (verso-refrão-ponte) é uma escolha segura; se o usuário mencionar um
   gênero brasileiro ("sertanejo", "forró", "samba"), abra
   `references/formas-e-generos.md` e siga as características daquele
   gênero (sequência de seções, métrica típica, registro de
   vocabulário). **Padrão da skill: use pelo menos 4 Versos** em toda
   música que tiver Refrão (intercalados com ele) — salvo pedido
   explícito do usuário por algo mais curto, ou forma sem Refrão
   (estrófica tem número livre de estrofes; AABA tem sua própria
   contagem fixa de seções, sem se aplicar aqui). Quatro versos dão
   desenvolvimento narrativo mais completo e evitam repetir o refrão
   cedo demais sem material novo entre as repetições.
2. Defina o **motivo/gancho** antes de escrever o resto — é mais fácil
   construir versos que conduzem a um refrão já definido do que achar
   um gancho depois, no meio de um texto pronto (ver seção "Motivo" em
   `elementos-musicais.md`).
3. Escreva o primeiro Verso e o Refrão. Pense em forma antes de rima:
   o verso narra/detalha, o refrão sintetiza/emocional — se as duas
   seções estão dizendo a mesma coisa com palavras diferentes, revise a
   função de cada uma antes de lapidar palavra por palavra. Se travar
   numa palavra final sem achar par de rima, use `--buscar-rima
   "palavra"` antes de forçar uma rima pobre ou abandonar a rima ali.
4. Ao escrever seções seguintes do mesmo tipo (Verso 2, Verso 3...),
   escreva pensando na melodia já "fixada" pela primeira ocorrência —
   depois confirme com `--consistencia` que a contagem silábica *e* o
   esquema de rima batem linha a linha (corrigir só as sílabas e deixar
   a rima mudar de ABAB para ABCD é um erro comum e fácil de não notar
   de ouvido).
5. Se houver ponte, use-a para uma virada real (mudança de pessoa
   gramatical, informação nova, inversão de perspectiva) — não apenas
   mais um verso com nome diferente.
6. Rode `--consistencia` no rascunho completo como autocheck rápido —
   depois, encerrada a escrita, passe a letra para o **modo AVALIAÇÃO**
   (não pule essa etapa: é lá que forma, gancho, rima e sobretudo
   **musicalidade** — cacofonia, eco, frase pesada, excesso de
   palavras — são checados por inteiro).

## Modo REVISÃO

Versão resumida da `pipeline-revisao.md` para consulta rápida — mas
**REVISÃO parte sempre de um diagnóstico do modo AVALIAÇÃO já feito**
(workflow REVISAR = AVALIAÇÃO → REVISÃO, nessa ordem); se ainda não
houver diagnóstico nesta conversa, rode a AVALIAÇÃO primeiro em vez de
corrigir de memória.

1. Rode `--consistencia` primeiro — é o problema mais comum e mais
   objetivamente identificável: linhas correspondentes entre seções do
   mesmo tipo com contagem silábica diferente, ou esquema de rima que
   muda de uma repetição para outra mesmo com a métrica igual. Rode
   também o relatório padrão (sem flag) para ver a escansão linha a
   linha, e `--rima` para os grupos de rima com tonicidade e qualidade
   sonora já classificados.
2. Para cada divergência silábica: é vazamento de prosódia (a frase
   simplesmente não cabe, a tônica vai cair fora do tempo forte) ou é
   uma variação que o gênero tolera bem (funk, forró, fluxo mais
   falado)? Só proponha correção para o primeiro caso. Para uma
   divergência de esquema de rima, cuidado especial: é fácil corrigir
   sílabas trocando a palavra final de uma linha e sem querer quebrar a
   rima que ela fazia com outra linha da mesma seção — depois de
   qualquer ajuste de sílaba, rode `--consistencia` de novo para
   confirmar que o esquema de rima não mudou como efeito colateral.
3. Ao propor um ajuste, prefira trocar palavras por sinônimos de
   tamanho diferente ou reordenar a sintaxe em vez de cortar a imagem
   inteira — o objetivo é a linha caber na melodia sem esvaziar o
   sentido.
4. Se o usuário mencionar um gênero ou forma, rode `--validar <nome>`
   para ver se a sequência de seções bate com o perfil típico — trate o
   resultado como sugestão, não veredito (principalmente em MPB, onde
   fugir do padrão costuma ser recurso, não erro). Uma `semelhanca`
   abaixo de 1.0 sem nenhum tipo em `tipos_esperados_ausentes` ou
   `tipos_presentes_fora_do_perfil` normalmente só significa que a
   letra tem mais repetições de um tipo já esperado do que o exemplo
   do perfil mostra (ex.: 4 Versos em vez dos 2 do perfil, pelo padrão
   de 4 versos desta skill para música com Refrão) — isso não é
   divergência real.
5. Quando a letra estiver em um arquivo, aplique as correções
   diretamente no arquivo e acrescente um changelog inline (lista logo
   após a letra, seção por seção, do que mudou e por quê) — não deixe a
   correção só descrita em prosa se o usuário pode simplesmente querer
   o arquivo pronto.

## Modo AVALIAÇÃO

Versão resumida da `pipeline-avaliacao.md` para consulta rápida — a
pipeline tem o detalhamento completo, incluindo a Etapa 5
(musicalidade) e a síntese final em três grupos (problema objetivo /
candidato a checar por ouvido / preferência de gosto). AVALIAÇÃO nunca
edita a letra, só diagnostica; correção é sempre o modo REVISÃO depois.

Estruture a avaliação em torno do que o script revela, mas não pare na
métrica — uma avaliação só técnica perde o que faz a canção funcionar:

- **Forma:** a sequência de seções tem uma função clara para cada uma
  (verso narra, refrão sintetiza, ponte vira a chave)? Rode
  `--estrutura` e, se houver um gênero-alvo, `--validar`.
- **Motivo/gancho:** existe uma frase que se repete e fixa? Rode
  `--gancho` para ver, objetivamente, quantas vezes e em quais seções
  ela aparece — ela é fácil de cantar (sonoridade, tamanho) e ganha
  camadas de sentido a cada repetição, ou é só repetição vazia (ou
  repetição de menos, e o gancho corre o risco de não grudar)?
- **Consistência silábica e de rima:** `--consistencia` — seções do
  mesmo tipo encaixam na mesma melodia (sílabas) e mantêm o mesmo
  esquema de rima entre repetições, ou o padrão sonoro muda de uma
  estrofe para outra mesmo com a métrica igual?
- **Rima:** que tipo (rica/pobre, consoante/toante)? (`--rima` traz o
  detalhamento por seção; `--consistencia` já aponta se o esquema
  muda entre repetições do mesmo tipo)
- **Musicalidade e ritmo (núcleo deste modo):** rode `--musicalidade`
  e leia o resultado em quatro frentes — **frases pesadas** (muitos
  encontros consonantais seguidos, custam articular cantando),
  **cacofonia** (pontos onde o fim de uma palavra funde com o início
  da próxima; a ferramenta só localiza, quem julga é a leitura em voz
  alta), **eco** (palavras de conteúdo terminando no mesmo som dentro
  da linha, sem intenção) e **excesso de palavras** (linha inflada de
  artigos/preposições/conjunções, conteúdo real diluído). São
  heurísticas: trate cada item como "vale ler em voz alta", não como
  erro confirmado. Funk e fluxo mais falado toleram bem mais que
  balada/MPB/bossa.
- **Textura e dinâmica:** a letra sugere uma curva de intensidade —
  verso mais contido, refrão mais expansivo — ou tudo soa no mesmo
  nível do início ao fim? (ver `elementos-musicais.md`)
- **Prosódia:** ao ler em voz alta marcando o "tum" de um pulso
  imaginário, as palavras caem naturalmente, ou alguma sílaba átona
  parece forçada a carregar acento?
- **Imagem e sentido:** fora do escopo puramente técnico, mas é o que
  dá substância à avaliação — vale comentar se a forma escolhida serve
  ao conteúdo (uma balada AABA tentando narrar uma história cheia de
  reviravoltas está brigando com a própria forma).

Feche a avaliação separando os achados em **três grupos**, não uma
lista plana de comandos rodados: (a) **problemas objetivos**
(consistência silábica/rima quebrada, forma sem justificativa para o
desvio), (b) **candidatos a revisar por ouvido** (musicalidade —
cacofonia, eco, frase pesada, excesso de palavras), (c) **observações
de gosto** (imagem, escolha de palavra) que não são erro. Se o
workflow é **CRIAR**, esse relatório fecha a entrega. Se é **REVISAR**,
esse relatório é o insumo que abre o **modo REVISÃO** — nenhuma
correção acontece antes deste relatório existir.

## Analisar estrutura / adaptar para um gênero

Quando o pedido é entender ou transformar a estrutura de uma letra já
existente (ex.: "que forma é essa?", "adapta essa letra pra forró",
"quero uma versão AABA disso"):

1. Rode `--estrutura` para ver a sequência de seções encontrada.
2. Compare com os perfis em `references/formas-e-generos.md` (e
   `--validar <genero>` para uma comparação objetiva) para identificar
   a forma mais próxima ou decidir a forma-alvo da adaptação.
3. Ao adaptar para outro gênero, ajuste não só a sequência de seções,
   mas o que o gênero pede: métrica típica (forró tende a versos mais
   curtos que balada pop), registro de vocabulário (moda de viola é
   mais formal/imagética que sertanejo universitário), e onde fica o
   refrão-mote (alguns gêneros abrem com refrão, outros fecham cada
   bloco com ele — ver a sequência esperada de cada perfil).
4. Depois de adaptar, rode `--consistencia` e `--rima` na nova versão
   para confirmar que a mudança de forma não quebrou o encaixe
   silábico entre seções.

## Exportar letra formatada

Quando a letra estiver pronta e o usuário quiser um arquivo para
guardar, baixar ou compartilhar (não só o texto na conversa), use
`scripts/exportar_letra.py` para gerar um Markdown limpo — título,
metadados opcionais e cada seção com quebras de linha reais:

```bash
python3 scripts/exportar_letra.py \
  --arquivo letra.txt \
  --titulo "Nome da Música" \
  --genero "Sertanejo universitário" \
  --autor "Composição de Fulano" \
  --saida letra_final.md

# --notas acrescenta, ao final de cada seção, um resumo técnico
# (nº de linhas, média de sílabas, esquema de rima) — útil se a letra
# vai para alguém que ainda vai compor a melodia por cima
python3 scripts/exportar_letra.py --arquivo letra.txt --titulo "Nome" --notas --saida letra_final.md
```

`--genero` e `--autor` são opcionais — omita se não vier ao caso.
Depois de gerar o `.md`, siga a convenção normal de entrega de
arquivos do ambiente (copiar para o diretório de saída e apresentar o
arquivo ao usuário) em vez de só colar o conteúdo na conversa, já que
o pedido aqui é por um arquivo. Se o usuário pedir explicitamente um
Word/.docx em vez de Markdown, não tente gerar o `.docx` neste script
— use a skill de docx do ambiente, passando o Markdown já formatado
(ou a letra + metadados) como conteúdo-base.
