#!/usr/bin/env python3
"""
analisar_letra.py — análise estrutural de letras de música em português:
sílabas poéticas por verso, rima, consistência silábica entre seções que
repetem a mesma melodia, e validação contra formas/gêneros musicais.

A letra deve ser marcada por seções entre colchetes, uma por linha, ex.:

    [Verso 1]
    Vim de longe pra te ver
    Trouxe o sol dentro da mão

    [Refrão]
    E é assim que o tempo passa
    Devagar, devagar

    [Verso 2]
    Vim de longe pra ficar
    Trouxe a chuva e o verão

    [Refrão]
    E é assim que o tempo passa
    Devagar, devagar

O rótulo entre colchetes pode ter um número ("Verso 1", "Verso 2") para
marcar repetições do mesmo tipo de seção — é essa numeração que o
--consistencia usa para comparar se as linhas correspondentes têm o
mesmo número de sílabas e o mesmo esquema de rima (importante porque,
em geral, seções do mesmo tipo dividem a mesma melodia: se "Verso 2"
tem uma sílaba a mais que "Verso 1" na mesma posição, ou a melodia se
ajusta ou a frase não cabe; e se o esquema de rima muda de ABAB para
ABCD, a segunda estrofe perde o efeito sonoro que a primeira criou,
mesmo que a métrica continue perfeita).

Uso:
    python analisar_letra.py --arquivo letra.txt
        (relatório por seção: sílabas de cada verso + esquema de rima)

    python analisar_letra.py --arquivo letra.txt --consistencia
        (compara seções do mesmo tipo linha a linha — sílabas E esquema
        de rima — crucial para cantabilidade, já que reaproveitam a
        mesma melodia; um esquema de rima que muda entre repetições é
        problema mesmo quando as sílabas batem)

    python analisar_letra.py --arquivo letra.txt --rima
        (relatório de rima expandido por seção: tonicidade e qualidade
        sonora de cada grupo)

    python analisar_letra.py --arquivo letra.txt --estrutura
        (só a sequência de seções e quantas linhas cada uma tem)

    python analisar_letra.py --arquivo letra.txt --validar <genero>
        (compara a sequência de seções contra o perfil de um gênero/forma
        cadastrado em generos.json — ver lista com --listar-generos)

    python analisar_letra.py --arquivo letra.txt --stats
        (contagens objetivas: seções, linhas, palavras, média de sílabas)

    python analisar_letra.py --arquivo letra.txt --gancho
        (detecta automaticamente linhas que se repetem verbatim na letra
        — candidatas a motivo/gancho — e aponta em quais seções aparecem)

    python analisar_letra.py --arquivo letra.txt --gancho "Volta, que a luz não apaga"
        (conta quantas vezes essa frase específica aparece — exata ou
        como trecho de uma linha maior — e em quais seções)

    python analisar_letra.py "um verso avulso"
        (sem seções: escande só a linha, útil para checar um verso solto)

    python analisar_letra.py --buscar-rima "farol"
        (sugere palavras de um banco interno de ~450 palavras comuns em
        português que rimam com "farol" — consoantes primeiro, depois
        toantes — útil para compor, não só para avaliar rima existente)

    python analisar_letra.py --arquivo letra.txt --musicalidade
        (heurísticas de ritmo/musicalidade: eco (repetição sonora não
        intencional dentro da linha), candidatas a cacofonia (pontos de
        fusão vocálica entre palavras), frases pesadas (densidade de
        encontros consonantais) e excesso de palavras/muletas
        (proporção de conectivos) — ver observação no próprio resultado
        sobre como interpretar)

    python analisar_letra.py --vocabulario forro_pe_de_serra
        (termos, interjeições, instrumentos e nota de registro típicos
        do gênero — ver dicionario_generos.json; mesmos nomes de
        gênero usados em --validar)

IMPORTANTE — isto é uma ferramenta de apoio, não um oráculo. A separação
silábica e a acentuação do português têm exceções reais, e "sílaba
poética" (a que importa para caber na melodia) não é sempre igual a
"sílaba gramatical" — regionalismos, nomes próprios e liberdades de
fraseado do cantor mudam a conta. Trate os números como ponto de
partida objetivo para revisão, não como veredito final: um verso "quase
certo" (1 sílaba de diferença) pode caber perfeitamente cantado, e um
verso "certo" no papel pode soar estranho na melodia real.
"""

import json
import re
import sys
import unicodedata
from difflib import SequenceMatcher
from pathlib import Path

VOGAIS = "aeiouáéíóúâêôãõà"
VOGAIS_ACENTUADAS_HIATO = "íúÍÚ"
ONSETS_VALIDOS = {
    "pr", "pl", "br", "bl", "tr", "tl", "dr", "cr", "cl",
    "gr", "gl", "fr", "fl", "vr", "vl", "ch", "lh", "nh",
    "qu", "gu",
}

ATONAS_COMUNS = {
    "o", "a", "os", "as", "um", "uns", "uma", "umas",
    "de", "em", "por", "com", "sem", "sob", "sobre", "ante", "após",
    "até", "desde", "entre", "para", "perante", "trás",
    "e", "ou", "mas", "nem", "que", "se", "como", "quando", "porque", "pois",
    "me", "te", "lhe", "nos", "vos", "lhes", "lo", "la", "los", "las", "no", "na",
}


# ---------------------------------------------------------------------
# Escansão silábica (mesma lógica usada para versos: sinalefa + conta
# até a última sílaba tônica — é o que determina quantos "encaixes"
# melódicos o verso ocupa quando cantado)
# ---------------------------------------------------------------------

def _is_vowel(ch):
    return ch.lower() in VOGAIS


def separar_silabas(palavra):
    w = palavra.lower()
    if not w:
        return []
    nucleos = []
    i, n = 0, len(w)
    while i < n:
        if _is_vowel(w[i]):
            j = i + 1
            while j < n and _is_vowel(w[j]):
                if w[j] in VOGAIS_ACENTUADAS_HIATO.lower():
                    break
                j += 1
            nucleos.append((i, j))
            i = j
        else:
            i += 1
    if not nucleos:
        return [w]

    silabas = []
    limite_anterior = 0
    for idx, (ini, fim) in enumerate(nucleos):
        consoantes_antes = w[0:ini] if idx == 0 else w[limite_anterior:ini]
        if idx == 0:
            silabas.append(consoantes_antes + w[ini:fim])
        else:
            cluster = consoantes_antes
            if len(cluster) <= 1:
                onset, coda_anterior = cluster, ""
            elif cluster[-2:] in ONSETS_VALIDOS:
                onset, coda_anterior = cluster[-2:], cluster[:-2]
            else:
                onset, coda_anterior = cluster[-1:], cluster[:-1]
            silabas[-1] += coda_anterior
            silabas.append(onset + w[ini:fim])
        limite_anterior = fim
    silabas[-1] += w[limite_anterior:]
    return silabas


def _tem_acento(silaba):
    return any(ch in "áéíóúâêô" for ch in silaba)


def posicao_tonica(silabas, palavra=None):
    n = len(silabas)
    if n == 1:
        if palavra and re.sub(r"[.,;:!?]+$", "", palavra.lower()) in ATONAS_COMUNS:
            return None
        return 0
    for i, s in enumerate(silabas):
        if _tem_acento(s):
            return i
    ultima = silabas[-1]
    oxitonas_fim = ("r", "l", "z", "x", "n", "i", "u", "ã", "ão", "ãe", "im", "um")
    if ultima.endswith(("em", "ens")):
        return n - 1
    if ultima.rstrip("s").endswith(oxitonas_fim):
        return n - 1
    return max(n - 2, 0)


def _strip_acentos(txt):
    return "".join(c for c in unicodedata.normalize("NFD", txt) if unicodedata.category(c) != "Mn")


def escandir_verso(verso):
    tokens = re.findall(r"[\wÀ-ÿ]+|[^\wÀ-ÿ\s]", verso, re.UNICODE)
    palavras = [t for t in tokens if re.match(r"[\wÀ-ÿ]+", t)]
    info_palavras = []
    for p in palavras:
        sils = separar_silabas(p)
        tonica = posicao_tonica(sils, p)
        info_palavras.append({"palavra": p, "silabas": sils, "tonica": tonica})
    if not info_palavras:
        return {"palavras": [], "total": 0, "elisoes": 0, "fusoes": []}

    sequencia = []
    for pi, info in enumerate(info_palavras):
        for si, s in enumerate(info["silabas"]):
            sequencia.append([s, pi, si == info["tonica"]])

    elisoes = 0
    fusoes = []  # pontos de fusão vocálica entre palavras — candidatas a checar cacofonia
    i = 0
    while i < len(sequencia) - 1:
        atual, prox = sequencia[i], sequencia[i + 1]
        pi_atual, pi_prox = atual[1], prox[1]
        eh_fronteira = pi_prox == pi_atual + 1
        atual_eh_monossilabo_tonico = (
            len(info_palavras[pi_atual]["silabas"]) == 1 and atual[2] is True
        )
        if (
            eh_fronteira
            and not atual_eh_monossilabo_tonico
            and atual[0][-1:].lower() in VOGAIS
            and prox[0][:1].lower() in VOGAIS
        ):
            fundida_texto = atual[0] + prox[0]
            fundida_tonica = atual[2] or prox[2]
            if pi_prox != pi_atual:  # só registra fusão na primeira sílaba fundida de cada par de palavras
                fusoes.append({
                    "palavras": (info_palavras[pi_atual]["palavra"], info_palavras[pi_prox]["palavra"]),
                    "fragmento_fundido": fundida_texto,
                })
            sequencia[i] = [fundida_texto, pi_atual, fundida_tonica]
            del sequencia[i + 1]
            elisoes += 1
            continue
        i += 1

    total_bruto = len(sequencia)
    ultimo_indice_tonico = None
    for idx, item in enumerate(sequencia):
        if item[2]:
            ultimo_indice_tonico = idx
    total = total_bruto if ultimo_indice_tonico is None else ultimo_indice_tonico + 1
    return {"palavras": info_palavras, "sequencia": sequencia, "total": total, "elisoes": elisoes, "fusoes": fusoes}


def chave_rima(palavra):
    sils = separar_silabas(palavra)
    tonica = posicao_tonica(sils)
    if tonica is None:
        tonica = len(sils) - 1
    silaba_tonica = sils[tonica]
    m = re.search(f"[{VOGAIS}]", silaba_tonica)
    silaba_tonica_sem_onset = silaba_tonica[m.start():] if m else silaba_tonica
    trecho = (silaba_tonica_sem_onset + "".join(sils[tonica + 1:])).lower()
    trecho = trecho.replace("ç", "s").replace("ss", "s")
    trecho = re.sub(r"c(?=[ei])", "s", trecho)
    trecho = trecho.replace("ch", "x")
    return _strip_acentos(trecho)


def tipo_tonicidade_rima(palavra):
    sils = separar_silabas(palavra)
    tonica = posicao_tonica(sils, palavra)
    n = len(sils)
    if tonica is None:
        return "átona"
    if tonica == n - 1:
        return "aguda/oxítona"
    if tonica == n - 2:
        return "grave/paroxítona"
    if tonica == n - 3:
        return "esdrúxula/proparoxítona"
    return "indeterminada"


def tipo_qualidade_rima(chave_a, chave_b):
    if not chave_a or not chave_b:
        return "não rima"
    if chave_a == chave_b:
        return "consoante"
    vogais_a = "".join(c for c in chave_a if c in VOGAIS)
    vogais_b = "".join(c for c in chave_b if c in VOGAIS)
    if vogais_a and vogais_a == vogais_b:
        return "toante"
    return "não rima"


def esquema_de_rima(versos):
    ultimas_palavras = []
    for v in versos:
        palavras = re.findall(r"[\wÀ-ÿ]+", v, re.UNICODE)
        ultimas_palavras.append(palavras[-1] if palavras else "")
    chaves = [chave_rima(p) if p else "" for p in ultimas_palavras]
    letras, resultado, proxima = {}, [], ord("A")
    for chave in chaves:
        if not chave:
            resultado.append("-")
            continue
        if chave not in letras:
            letras[chave] = chr(proxima)
            proxima += 1
        resultado.append(letras[chave])
    return "".join(resultado)


CLASSIFICACAO_VERSO = {
    1: "monossílabo", 2: "dissílabo", 3: "trissílabo", 4: "tetrassílabo",
    5: "redondilha menor", 6: "hexassílabo", 7: "redondilha maior",
    8: "octossílabo", 9: "eneassílabo", 10: "decassílabo",
    11: "hendecassílabo", 12: "dodecassílabo",
}


def classificar_verso(n):
    return CLASSIFICACAO_VERSO.get(n, f"{n} sílabas (fora dos padrões clássicos — comum em letra falada/rap/funk)")


# ---------------------------------------------------------------------
# Parsing de seções ([Verso 1], [Refrão], [Ponte]...)
# ---------------------------------------------------------------------

CABECALHO_RE = re.compile(r"^\s*\[(.+?)\]\s*$")


def parse_secoes(texto):
    """Divide a letra em seções a partir de cabeçalhos [Rótulo N].
    Se não houver nenhum cabeçalho, retorna uma única seção "Letra" com
    todas as linhas não vazias."""
    secoes = []
    atual = None
    for linha in texto.splitlines():
        m = CABECALHO_RE.match(linha)
        if m:
            rotulo = m.group(1).strip()
            mnum = re.match(r"^(.*?)\s*(\d+)?$", rotulo)
            tipo = mnum.group(1).strip() or rotulo
            numero = int(mnum.group(2)) if mnum.group(2) else None
            atual = {"rotulo": rotulo, "tipo": tipo, "numero": numero, "linhas": []}
            secoes.append(atual)
            continue
        if linha.strip():
            if atual is None:
                atual = {"rotulo": "Letra", "tipo": "Letra", "numero": None, "linhas": []}
                secoes.append(atual)
            atual["linhas"].append(linha.strip())
    return secoes


def relatorio_secoes(secoes):
    relatorio = []
    for sec in secoes:
        linhas_info = []
        for linha in sec["linhas"]:
            r = escandir_verso(linha)
            linhas_info.append({
                "linha": linha,
                "silabas": r["total"],
                "classificacao": classificar_verso(r["total"]),
                "elisoes": r["elisoes"],
            })
        esquema = esquema_de_rima(sec["linhas"]) if len(sec["linhas"]) > 1 else None
        relatorio.append({"rotulo": sec["rotulo"], "tipo": sec["tipo"], "linhas": linhas_info, "esquema_rima": esquema})
    return relatorio


def consistencia(secoes):
    """Agrupa seções pelo 'tipo' (Verso, Refrão...) e compara, entre
    repetições do mesmo tipo, tanto o número de sílabas linha a linha
    quanto o esquema de rima — sinaliza onde uma frase não vai caber na
    melodia já estabelecida pela primeira ocorrência daquele tipo de
    seção, e onde o padrão de rima muda de uma repetição para outra
    (ex.: Verso 1 em ABAB e Verso 2 em ABCB, mesmo com sílabas batendo)."""
    por_tipo = {}
    for sec in secoes:
        por_tipo.setdefault(sec["tipo"], []).append(sec)

    relatorio = []
    for tipo, ocorrencias in por_tipo.items():
        if len(ocorrencias) < 2:
            continue
        base = ocorrencias[0]
        silabas_base = [escandir_verso(l)["total"] for l in base["linhas"]]
        esquema_base = esquema_de_rima(base["linhas"]) if len(base["linhas"]) > 1 else None
        comparacoes = []
        for outra in ocorrencias[1:]:
            silabas_outra = [escandir_verso(l)["total"] for l in outra["linhas"]]
            esquema_outra = esquema_de_rima(outra["linhas"]) if len(outra["linhas"]) > 1 else None
            divergencias = []
            n_comum = min(len(silabas_base), len(silabas_outra))
            for i in range(n_comum):
                if silabas_base[i] != silabas_outra[i]:
                    divergencias.append({
                        "linha": i + 1,
                        "referencia": {"rotulo": base["rotulo"], "texto": base["linhas"][i], "silabas": silabas_base[i]},
                        "comparado": {"rotulo": outra["rotulo"], "texto": outra["linhas"][i], "silabas": silabas_outra[i]},
                    })
            if len(base["linhas"]) != len(outra["linhas"]):
                divergencias.append({
                    "aviso": f"{base['rotulo']} tem {len(base['linhas'])} linha(s) e "
                             f"{outra['rotulo']} tem {len(outra['linhas'])} — número de linhas diferente"
                })
            if esquema_base is not None and esquema_outra is not None and esquema_base != esquema_outra:
                divergencias.append({
                    "aviso": f"esquema de rima mudou entre {base['rotulo']} ({esquema_base}) "
                             f"e {outra['rotulo']} ({esquema_outra})"
                })
            comparacoes.append({
                "comparado_com": outra["rotulo"],
                "ok": len(divergencias) == 0,
                "esquema_rima": {"referencia": esquema_base, "comparado": esquema_outra},
                "divergencias": divergencias,
            })
        relatorio.append({"tipo": tipo, "referencia": base["rotulo"], "comparacoes": comparacoes})
    return relatorio


def relatorio_rima_secoes(secoes):
    saida = []
    for sec in secoes:
        linhas = sec["linhas"]
        if len(linhas) < 2:
            saida.append({"rotulo": sec["rotulo"], "esquema": None, "grupos": []})
            continue
        ultimas = []
        for l in linhas:
            palavras = re.findall(r"[\wÀ-ÿ]+", l, re.UNICODE)
            ultimas.append(palavras[-1] if palavras else "")
        chaves = [chave_rima(p) if p else "" for p in ultimas]
        esquema = esquema_de_rima(linhas)
        por_letra = {}
        for i, letra in enumerate(esquema):
            por_letra.setdefault(letra, []).append(i)
        grupos = []
        for letra, indices in sorted(por_letra.items()):
            if letra == "-":
                continue
            palavras_grupo = [ultimas[i] for i in indices]
            tonicidades = [tipo_tonicidade_rima(ultimas[i]) for i in indices]
            qualidade = "único" if len(indices) < 2 else tipo_qualidade_rima(chaves[indices[0]], chaves[indices[1]])
            grupos.append({"letra": letra, "linhas": [i + 1 for i in indices], "palavras": palavras_grupo,
                            "tonicidade": tonicidades, "qualidade_sonora": qualidade})
        saida.append({"rotulo": sec["rotulo"], "esquema": esquema, "grupos": grupos})
    return saida


def estrutura(secoes):
    return [{"rotulo": s["rotulo"], "tipo": s["tipo"], "n_linhas": len(s["linhas"])} for s in secoes]


def estatisticas(secoes):
    todas_linhas = [l for s in secoes for l in s["linhas"]]
    n_palavras = sum(len(re.findall(r"[\wÀ-ÿ]+", l, re.UNICODE)) for l in todas_linhas)
    totais = [escandir_verso(l)["total"] for l in todas_linhas]
    media = round(sum(totais) / len(totais), 2) if totais else 0
    por_tipo = {}
    for s in secoes:
        por_tipo.setdefault(s["tipo"], 0)
        por_tipo[s["tipo"]] += 1
    return {
        "n_secoes": len(secoes),
        "secoes_por_tipo": por_tipo,
        "n_linhas": len(todas_linhas),
        "n_palavras": n_palavras,
        "media_silabas_por_linha": media,
    }


def carregar_generos():
    caminho = Path(__file__).parent / "generos.json"
    with open(caminho, encoding="utf-8") as f:
        return json.load(f)


def carregar_dicionario_generos():
    caminho = Path(__file__).parent / "dicionario_generos.json"
    with open(caminho, encoding="utf-8") as f:
        return json.load(f)


def vocabulario_genero(nome_genero, dicionario=None):
    dicionario = dicionario or carregar_dicionario_generos()
    entrada = dicionario.get(nome_genero)
    if entrada is None:
        return {
            "erro": f"gênero '{nome_genero}' não cadastrado em dicionario_generos.json",
            "generos_disponiveis": sorted(dicionario.keys()),
        }
    return {"genero": nome_genero, **entrada}


def carregar_banco_rimas():
    caminho = Path(__file__).parent / "banco_rimas.txt"
    with open(caminho, encoding="utf-8") as f:
        return [linha.strip() for linha in f if linha.strip()]


# ---------------------------------------------------------------------
# Buscador de rimas: casa a chave_rima (mesma lógica usada para
# avaliar rima de versos) contra um banco de ~450 palavras comuns em
# português, para SUGERIR candidatas na hora de compor — não só
# avaliar rima que já existe.
# ---------------------------------------------------------------------

def buscar_rimas(palavra, banco=None, incluir_toante=True):
    banco = banco or carregar_banco_rimas()
    chave_alvo = chave_rima(palavra)
    vogais_alvo = "".join(c for c in chave_alvo if c in VOGAIS)
    alvo_normalizado = normalizar_para_comparacao(palavra)

    consoantes, toantes = [], []
    for candidata in banco:
        if normalizar_para_comparacao(candidata) == alvo_normalizado:
            continue  # não sugere a própria palavra
        chave_cand = chave_rima(candidata)
        if chave_cand == chave_alvo:
            consoantes.append(candidata)
        elif incluir_toante:
            vogais_cand = "".join(c for c in chave_cand if c in VOGAIS)
            if vogais_cand and vogais_cand == vogais_alvo:
                toantes.append(candidata)

    return {
        "palavra": palavra,
        "tonicidade": tipo_tonicidade_rima(palavra),
        "rimas_consoantes": sorted(set(consoantes)),
        "rimas_toantes": sorted(set(toantes)) if incluir_toante else [],
        "observacao": (
            "nenhuma rima encontrada no banco — banco cobre ~450 palavras "
            "comuns, não é dicionário completo; tente também variar "
            "manualmente a terminação, ou considere rima toante em vez de "
            "consoante"
        ) if not consoantes and not toantes else None,
    }


# ---------------------------------------------------------------------
# Densidade do gancho (motivo lírico): quantas vezes uma frase-chave
# se repete, e onde — ajuda a avaliar se o gancho gruda (repetição de
# menos) ou cansa (repetição de mais), e serve para localizar todas as
# ocorrências antes de editar uma delas.
# ---------------------------------------------------------------------

def normalizar_para_comparacao(txt):
    """Remove acentos, pontuação e diferenças de maiúsculas/espaço para
    comparar frases por conteúdo, não por grafia exata."""
    txt = _strip_acentos(txt.lower())
    txt = re.sub(r"[^\w\s]", "", txt, flags=re.UNICODE)
    txt = re.sub(r"\s+", " ", txt).strip()
    return txt


def densidade_gancho(secoes, frase=None):
    todas_linhas = [(s["rotulo"], l) for s in secoes for l in s["linhas"]]

    if frase:
        alvo = normalizar_para_comparacao(frase)
        ocorrencias = [
            {"secao": rotulo, "linha": linha}
            for rotulo, linha in todas_linhas
            if alvo and alvo in normalizar_para_comparacao(linha)
        ]
        secoes_distintas = sorted(set(o["secao"] for o in ocorrencias))
        return {
            "frase": frase,
            "total_ocorrencias": len(ocorrencias),
            "aparece_em": secoes_distintas,
            "ocorrencias": ocorrencias,
        }

    # sem frase: detecta automaticamente linhas repetidas verbatim (após
    # normalização) — candidatas naturais a motivo/gancho da canção
    contagem = {}
    for rotulo, linha in todas_linhas:
        chave = normalizar_para_comparacao(linha)
        if not chave:
            continue
        contagem.setdefault(chave, {"texto_original": linha, "secoes": []})
        contagem[chave]["secoes"].append(rotulo)

    repetidas = [
        {"linha": v["texto_original"], "vezes": len(v["secoes"]), "aparece_em": v["secoes"]}
        for v in contagem.values() if len(v["secoes"]) > 1
    ]

    def prioridade(item):
        eh_refrao = any(re.match(r"^refr[aã]o\b", s.strip(), re.I) for s in item["aparece_em"])
        return (-item["vezes"], 0 if eh_refrao else 1, len(item["linha"]))

    repetidas.sort(key=prioridade)
    return {
        "linhas_repetidas": repetidas,
        "candidata_a_motivo": repetidas[0] if repetidas else None,
        "observacao": (
            "nenhuma linha se repete verbatim — se há um gancho, ele está "
            "variando de redação a cada repetição (checar manualmente) ou "
            "a letra ainda não fixou um motivo lírico"
        ) if not repetidas else None,
    }


# ---------------------------------------------------------------------
# Musicalidade: frases pesadas, cacofonia, eco, excesso de palavras.
# São heurísticas de apoio para leitura em voz alta — localizam pontos
# a checar, não emitem veredito automático de "está errado". Usadas
# pelo modo AVALIAÇÃO (ver SKILL.md e pipeline-avaliacao.md).
# ---------------------------------------------------------------------

def detectar_eco(secoes):
    """Dentro de cada linha, palavras de conteúdo (não funcionais, não a
    última — essa é posição de rima, intencional) que terminam com o
    mesmo som — repetição sonora não-intencional dentro do verso."""
    resultados = []
    for sec in secoes:
        for i, linha in enumerate(sec["linhas"]):
            palavras = re.findall(r"[\wÀ-ÿ]+", linha, re.UNICODE)
            if len(palavras) < 3:
                continue
            candidatas = [
                p for p in palavras[:-1]
                if normalizar_para_comparacao(p) not in ATONAS_COMUNS and len(p) > 2
            ]
            por_chave = {}
            for p in candidatas:
                k = chave_rima(p)
                if k:
                    por_chave.setdefault(k, []).append(p)
            grupos = [
                {"som": k, "palavras": v} for k, v in por_chave.items()
                if len(v) > 1 and len(set(normalizar_para_comparacao(p) for p in v)) > 1
                # exclui repetição da MESMA palavra (ex. "vem... vem" no gancho) —
                # isso é recurso retórico intencional, não eco acidental
            ]
            if grupos:
                resultados.append({"secao": sec["rotulo"], "linha": i + 1, "texto": linha, "ecos": grupos})
    return resultados


def detectar_cacofonia_candidata(secoes):
    """Pontos de fusão vocálica entre palavras (mesmo mecanismo da
    escansão) — é exatamente onde cacofonia tende a acontecer em
    português. A ferramenta só localiza a junção; ler em voz alta pra
    julgar se soa mal é insubstituível aqui."""
    resultados = []
    for sec in secoes:
        for i, linha in enumerate(sec["linhas"]):
            r = escandir_verso(linha)
            for f in r.get("fusoes", []):
                palavra_a, palavra_b = f["palavras"]
                ambas_funcionais = (
                    normalizar_para_comparacao(palavra_a) in ATONAS_COMUNS
                    and normalizar_para_comparacao(palavra_b) in ATONAS_COMUNS
                )
                if ambas_funcionais:
                    # ex. "que"+"o", "e"+"o" — elisão função+função é extremamente
                    # comum e nunca surpreendente; não vale como candidata
                    continue
                resultados.append({
                    "secao": sec["rotulo"],
                    "linha": i + 1,
                    "texto": linha,
                    "juncao": f"{palavra_a} + {palavra_b}",
                    "fragmento_fundido": f["fragmento_fundido"],
                })
    return resultados


def detectar_frases_pesadas(secoes, limiar=0.4):
    """Proxy para 'frase pesada': proporção de sílabas com onset
    consonantal complexo (2+ consoantes antes da vogal, ex. 'tr', 'pl',
    'str') na linha. Muitos encontros consonantais em sequência custam
    mais para articular cantando — não é erro, é peso a considerar."""
    resultados = []
    for sec in secoes:
        for i, linha in enumerate(sec["linhas"]):
            r = escandir_verso(linha)
            seq = r.get("sequencia", [])
            if not seq:
                continue
            complexas = 0
            for silaba_texto, _, _ in seq:
                m = re.match(f"^[^{VOGAIS}]*", silaba_texto, re.I)
                if m and len(m.group()) >= 2:
                    complexas += 1
            razao = complexas / len(seq)
            if razao >= limiar:
                resultados.append({
                    "secao": sec["rotulo"], "linha": i + 1, "texto": linha,
                    "proporcao_onsets_complexos": round(razao, 2),
                })
    return resultados


def detectar_excesso_palavras(secoes, limiar=0.5, minimo_palavras=4):
    """Proxy para 'excesso de palavras'/muletas: proporção de palavras
    funcionais (artigos, preposições, conjunções — ATONAS_COMUNS) na
    linha. Linha curta em conteúdo real, inflada por conectivos."""
    resultados = []
    for sec in secoes:
        for i, linha in enumerate(sec["linhas"]):
            palavras = re.findall(r"[\wÀ-ÿ]+", linha, re.UNICODE)
            if len(palavras) < minimo_palavras:
                continue
            funcionais = sum(1 for p in palavras if normalizar_para_comparacao(p) in ATONAS_COMUNS)
            razao = funcionais / len(palavras)
            if razao >= limiar:
                resultados.append({
                    "secao": sec["rotulo"], "linha": i + 1, "texto": linha,
                    "proporcao_palavras_funcionais": round(razao, 2), "n_palavras": len(palavras),
                })
    return resultados


def analisar_musicalidade(secoes):
    eco = detectar_eco(secoes)
    cacofonia = detectar_cacofonia_candidata(secoes)
    pesadas = detectar_frases_pesadas(secoes)
    excesso = detectar_excesso_palavras(secoes)
    return {
        "eco": eco,
        "cacofonia_candidatas": cacofonia,
        "frases_pesadas": pesadas,
        "excesso_de_palavras": excesso,
        "observacao": (
            "heurísticas de apoio, não veredito automático. eco/frases_pesadas/"
            "excesso_de_palavras sinalizam candidatos objetivos (repetição de som, "
            "densidade consonantal, proporção de conectivos) que merecem releitura "
            "em voz alta; cacofonia_candidatas só localiza pontos de fusão vocálica "
            "entre palavras — julgar se soa mal exige ler em voz alta, a ferramenta "
            "não decide isso sozinha."
        ),
    }


def validar_estrutura(secoes, nome_genero, generos=None):
    generos = generos or carregar_generos()
    perfil = generos.get(nome_genero)
    if perfil is None:
        return {"erro": f"gênero/forma '{nome_genero}' não cadastrado em generos.json — use --listar-generos"}
    obtida = [s["tipo"] for s in secoes]
    esperada = perfil["sequencia"]
    sm = SequenceMatcher(a=esperada, b=obtida)
    ratio = round(sm.ratio(), 2)
    faltando = [t for t in esperada if t not in obtida]
    extra = [t for t in obtida if t not in esperada]
    return {
        "genero": nome_genero,
        "sequencia_esperada": esperada,
        "sequencia_obtida": obtida,
        "semelhanca": ratio,
        "tipos_esperados_ausentes": sorted(set(faltando)),
        "tipos_presentes_fora_do_perfil": sorted(set(extra)),
        "observacao": perfil.get("observacao", ""),
    }


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(1)

    if args[0] == "--listar-generos":
        generos = carregar_generos()
        for nome, perfil in generos.items():
            print(f"{nome}: {' → '.join(perfil['sequencia'])}")
            if perfil.get("observacao"):
                print(f"    {perfil['observacao']}")
        return

    if args[0] == "--buscar-rima" and len(args) > 1:
        print(json.dumps(buscar_rimas(args[1]), ensure_ascii=False, indent=2))
        return

    if args[0] == "--vocabulario" and len(args) > 1:
        print(json.dumps(vocabulario_genero(args[1]), ensure_ascii=False, indent=2))
        return

    modo = None
    genero_alvo = None
    frase_gancho = None
    if "--consistencia" in args:
        modo = "consistencia"
        args = [a for a in args if a != "--consistencia"]
    elif "--rima" in args:
        modo = "rima"
        args = [a for a in args if a != "--rima"]
    elif "--estrutura" in args:
        modo = "estrutura"
        args = [a for a in args if a != "--estrutura"]
    elif "--stats" in args:
        modo = "stats"
        args = [a for a in args if a != "--stats"]
    elif "--musicalidade" in args:
        modo = "musicalidade"
        args = [a for a in args if a != "--musicalidade"]
    elif "--gancho" in args:
        idx = args.index("--gancho")
        if idx + 1 < len(args) and not args[idx + 1].startswith("--"):
            frase_gancho = args[idx + 1]
            args = args[:idx] + args[idx + 2:]
        else:
            args = args[:idx] + args[idx + 1:]
        modo = "gancho"
    elif "--validar" in args:
        idx = args.index("--validar")
        genero_alvo = args[idx + 1]
        modo = "validar"
        args = args[:idx] + args[idx + 2:]

    if args and args[0] == "--arquivo" and len(args) > 1:
        with open(args[1], encoding="utf-8") as f:
            texto = f.read()
    elif args and args[0] == "-":
        texto = sys.stdin.read()
    elif args:
        # sem seções: trata cada argumento como um verso avulso
        r = escandir_verso(" ".join(args))
        print(f"[{r['total']} sílabas | {classificar_verso(r['total'])}]  ({r['elisoes']} elisão(ões))")
        return
    else:
        print(__doc__)
        sys.exit(1)

    secoes = parse_secoes(texto)

    if modo == "consistencia":
        print(json.dumps(consistencia(secoes), ensure_ascii=False, indent=2))
    elif modo == "rima":
        print(json.dumps(relatorio_rima_secoes(secoes), ensure_ascii=False, indent=2))
    elif modo == "estrutura":
        print(json.dumps(estrutura(secoes), ensure_ascii=False, indent=2))
    elif modo == "stats":
        print(json.dumps(estatisticas(secoes), ensure_ascii=False, indent=2))
    elif modo == "musicalidade":
        print(json.dumps(analisar_musicalidade(secoes), ensure_ascii=False, indent=2))
    elif modo == "gancho":
        print(json.dumps(densidade_gancho(secoes, frase_gancho), ensure_ascii=False, indent=2))
    elif modo == "validar":
        print(json.dumps(validar_estrutura(secoes, genero_alvo), ensure_ascii=False, indent=2))
    else:
        for sec in relatorio_secoes(secoes):
            print(f"\n[{sec['rotulo']}]")
            for i, l in enumerate(sec["linhas"], 1):
                nota = f"  ({l['elisoes']} elisão(ões))" if l["elisoes"] else ""
                print(f"  {i:2d}. [{l['silabas']:2d} sílabas | {l['classificacao']}]{nota}  {l['linha']}")
            if sec["esquema_rima"]:
                print(f"  Esquema de rima: {sec['esquema_rima']}")


if __name__ == "__main__":
    main()
