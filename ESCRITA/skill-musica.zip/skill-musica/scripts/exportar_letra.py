#!/usr/bin/env python3
"""
exportar_letra.py — gera um arquivo Markdown formatado e pronto para
entrega a partir de uma letra marcada por seções ([Verso 1], [Refrão],
[Ponte]...), no mesmo formato que analisar_letra.py usa.

Uso:
    python exportar_letra.py --arquivo letra.txt --titulo "Nome da Música" --saida letra_final.md

    python exportar_letra.py --arquivo letra.txt --titulo "Nome" \
        --genero "Sertanejo universitário" --autor "Composição de Fulano" \
        --saida letra_final.md

    python exportar_letra.py --arquivo letra.txt --titulo "Nome" --notas --saida letra_final.md
        (--notas acrescenta, ao final de cada seção, um resumo técnico:
        número de linhas, média de sílabas e esquema de rima — útil
        para quem for compor a melodia ou levar a letra pra um músico)

Produz um Markdown limpo (título, metadados opcionais, seções
formatadas com quebras de linha reais) pronto para virar artifact,
arquivo de download, ou ponto de partida para um .docx — se o usuário
pedir explicitamente Word, use a skill docx com este Markdown como
conteúdo-base em vez de gerar o .docx aqui.
"""

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from analisar_letra import parse_secoes, escandir_verso, esquema_de_rima  # noqa: E402


def formatar_markdown(secoes, titulo, genero=None, autor=None, notas=False):
    linhas_md = [f"# {titulo}", ""]

    metadados = []
    if genero:
        metadados.append(f"*Gênero: {genero}*")
    if autor:
        metadados.append(f"*{autor}*")
    if metadados:
        linhas_md.append("  \n".join(metadados))
        linhas_md.append("")

    for sec in secoes:
        linhas_md.append(f"**[{sec['rotulo']}]**")
        linhas_md.append("")
        for linha in sec["linhas"]:
            linhas_md.append(linha + "  ")  # dois espaços no fim = quebra de linha em Markdown
        linhas_md.append("")

        if notas and sec["linhas"]:
            totais = [escandir_verso(l)["total"] for l in sec["linhas"]]
            media = round(sum(totais) / len(totais), 1)
            esquema = esquema_de_rima(sec["linhas"]) if len(sec["linhas"]) > 1 else "—"
            linhas_md.append(
                f"<sub>{len(sec['linhas'])} linha(s) · média {media} sílabas/linha · rima {esquema}</sub>"
            )
            linhas_md.append("")

    return "\n".join(linhas_md).rstrip() + "\n"


def main():
    p = argparse.ArgumentParser(description="Exporta uma letra marcada por seções para Markdown formatado.")
    p.add_argument("--arquivo", required=True, help="Caminho da letra de entrada (com seções [Verso 1], [Refrão]...)")
    p.add_argument("--titulo", required=True, help="Título da música")
    p.add_argument("--genero", default=None, help="Gênero/forma (opcional, aparece como metadado)")
    p.add_argument("--autor", default=None, help="Autoria/composição (opcional, aparece como metadado)")
    p.add_argument("--notas", action="store_true", help="Acrescenta resumo técnico (sílabas/rima) por seção")
    p.add_argument("--saida", required=True, help="Caminho do arquivo .md a gerar")
    args = p.parse_args()

    texto = Path(args.arquivo).read_text(encoding="utf-8")
    secoes = parse_secoes(texto)
    if not secoes:
        print("Nenhuma seção encontrada — confira se o arquivo tem linhas de letra.", file=sys.stderr)
        sys.exit(1)

    md = formatar_markdown(secoes, args.titulo, args.genero, args.autor, args.notas)
    Path(args.saida).write_text(md, encoding="utf-8")
    print(f"Exportado para {args.saida}")


if __name__ == "__main__":
    main()
