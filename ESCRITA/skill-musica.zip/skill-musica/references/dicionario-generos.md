# Dicionário de gêneros: termos e expressões

Vocabulário idiomático por gênero — termos, interjeições, instrumentos
citáveis e uma nota de registro. É o que a Tarefa 1.4 de
`pipeline-criacao.md` e a Tarefa 6.2 de `pipeline-avaliacao.md` usam
para calibrar/checar o vocabulário de uma letra ao gênero-alvo, e o
que `--validar`/`formas-e-generos.md` NÃO cobrem (aquilo é estrutura;
isto é léxico).

**Fonte de dados:** `scripts/dicionario_generos.json` — consulte com
`python3 scripts/analisar_letra.py --vocabulario <genero>` para o JSON
completo. Esta página é a versão de leitura corrida do mesmo conteúdo.
Se um editar o outro, o JSON é a fonte de verdade (é o que o script lê).

Isto é vocabulário de apoio, não regra rígida — um sertanejo
universitário pode usar uma palavra de MPB se servir à imagem; o
dicionário existe para sinalizar o padrão esperado, não para proibir
desvio consciente dele.

## pop_padrao
**Termos:** coração, sonho, agora, instante, presente, verdade,
liberdade, promessa. **Interjeições:** oh, ah, uou. **Registro:**
neutro/universal — evita regionalismo forte ou gíria datada.

## Forma estrófica (`estrofica`)
**Termos:** antigamente, lembro, quando eu era, beira do rio, roça,
quintal. **Instrumentos:** viola, violão. **Registro:** tom
narrativo/nostálgico, mais formal e imagético que o pop contemporâneo.

## Samba-canção (`samba_cancao`)
**Termos:** morro, malandro, gafieira, saudade, orgulho, batucada,
sambista, camarote, cordão. **Interjeições:** ê, vem. **Instrumentos:**
cavaquinho, pandeiro, surdo, tamborim, violão de 7 cordas.
**Registro:** coloquial carioca, afetivo — orgulho de comunidade
misturado a melancolia.

## Partido-alto (`partido_alto`)
**Termos:** roda, mote, improviso, batuque, convite, resenha.
**Interjeições:** e aí, vem. **Instrumentos:** pandeiro, tamborim,
cavaquinho, surdo. **Registro:** conversacional, quase falado nos
versos de improviso.

## Moda de viola (`moda_de_viola`)
**Termos:** sertão, boiadeiro, cabocla/caboclo, roça, chão batido,
estrada de terra, saudade da terra, arado, jaguatirica, mata.
**Interjeições:** ai, oh. **Instrumentos:** viola caipira, violão.
**Registro:** formal e imagético, evita gíria contemporânea — próximo
do falar caipira tradicional, não do sertanejo pop atual.

## Sertanejo universitário (`sertanejo_universitario`)
**Termos:** balada, cerveja, saudade, modão, paquera, textinho,
mensagem, coração partido, arrocha, reconciliação. **Interjeições:**
eeeh, ô, vem cá, óh. **Registro:** coloquial contemporâneo, direto —
referência a celular/mensagem/balada não soa anacrônica aqui.

## Forró pé-de-serra (`forro_pe_de_serra`)
**Termos:** sanfona, sertão, caatinga, São João, fogueira, arrasta-pé,
seca, festa junina, zabumba, chão. **Interjeições:** oxente, eita,
vixe, ei. **Instrumentos:** sanfona, zabumba, triângulo. **Registro:**
regionalismo nordestino explícito é bem-vindo — parte do apelo.

## MPB livre (`mpb_livre`)
Sem vocabulário fixo por definição. **Registro:** elaborado,
metafórico — cada compositor constrói o próprio campo lexical; usar
termo de outro gênero aqui é válido se servir à imagem, não à
convenção.

## Bossa nova (`bossa_nova`)
**Termos:** mar, praia, sombra, brisa, amor, manhã, sol, verão.
**Instrumentos:** violão. **Registro:** contido, elegante, econômico —
sugestão vale mais que declaração explícita, evita gíria e apelo
gritado.

## Funk carioca (`funk_carioca`)
**Termos:** batida, bonde, quebrada, role, vibe, beat, pancadão,
fluxo. **Interjeições:** eaew, e aí, vupt. **Registro:** coloquial
urbano — gíria contemporânea é esperada e vai soar datada em poucos
anos; isso é aceito no gênero (diferente do pop/MPB).

## Axé / Pagode (`axe_pagode`)
**Termos:** trio elétrico, camarote, roda de samba, resenha, bloco,
verão, praia, beijo. **Interjeições:** vem, ei, vamo lá.
**Instrumentos:** cavaquinho (pagode), percussão (axé). **Registro:**
festivo, coletivo — "vamos" implícito é comum, letra pensada para
cantar em grupo, não para introspecção.

## AABA
Forma sem vocabulário próprio — usada por vários gêneros (jazz, MPB,
pop antigo). O registro vem do gênero que a adota, não da forma em si.
