# Elementos musicais aplicados à letra de música

Este arquivo traduz conceitos de teoria musical para decisões concretas
de escrita de letra — sem notação musical, já que quem usa esta skill
trabalha com texto, não partitura. A ideia central: cada um desses
elementos "vive" na melodia e no arranjo, mas deixa marcas na letra que
dá pra escrever, revisar e avaliar.

## Motivo

O motivo é a menor unidade musical com identidade própria — um desenho
rítmico-melódico curto (tipicamente 1-2 compassos) que se repete e se
desenvolve ao longo da música, funcionando como a "assinatura" que o
ouvinte reconhece. Na letra, o motivo geralmente aparece como o
**gancho** (hook): a frase curta — muitas vezes o próprio título — que
carrega a identidade da canção e retorna, quase sempre no início e no
fim do refrão.

Um motivo lírico forte costuma ter:
- **Poucas sílabas e sonoridade fácil de guardar** (aliteração, repetição
  de vogal tônica, consoantes que "cantam" bem — nasais, líquidas).
- **Posição de destaque**: no título, na primeira e/ou última linha do
  refrão, às vezes também fechando a ponte antes do retorno do refrão.
- **Ambiguidade produtiva**: frases que ganham uma camada extra de
  sentido a cada repetição, porque o contexto ao redor mudou (verso 1
  diz uma coisa, verso 2 recontextualiza o mesmo refrão).

Ao compor, vale escolher o motivo *antes* de escrever o resto — é mais
fácil construir versos que conduzem até um gancho já definido do que
tentar destacar um gancho no meio de um texto pronto.

## Frase e período

Um motivo se expande em **frase melódica** — uma unidade de sentido
musical maior (tipicamente ~4 compassos), que corresponde, na letra, a
uma ou duas linhas cantadas numa "respiração". Duas frases que se
completam formam um **período** (pergunta/resposta, ou
antecedente/consequente): a primeira frase cria expectativa, a segunda
resolve.

Isso é útil como critério prático ao escrever pares de versos: o
primeiro verso de um par pode terminar em suspensão (rima menos
resolvida, ideia incompleta), e o segundo fecha o pensamento — imitando
o efeito de pergunta/resposta da melodia, mesmo sem pensar em notas.

## Forma

A forma é a organização das seções ao longo do tempo — como intro,
verso, refrão, ponte etc. se sucedem. É provavelmente a decisão
estrutural mais visível de uma letra, e tem um arquivo próprio: veja
`formas-e-generos.md` para o catálogo de formas internacionais e
gêneros brasileiros, com a sequência típica de seções de cada um.

Ao pensar em forma, três perguntas guiam a escrita:
1. **O que cada seção faz que as outras não fazem?** Se o verso e o
   refrão dizem basicamente a mesma coisa com palavras diferentes, a
   forma não está cumprindo função — o verso costuma narrar/detalhar,
   o refrão costuma sintetizar/emocionar.
2. **Onde fica o pico de intensidade?** Geralmente no refrão (e, se
   houver ponte, ela prepara um pico ainda maior no retorno final do
   refrão).
3. **Quantas vezes o ouvinte precisa ouvir o refrão pra ele "grudar"?**
   Menos que isso e o gancho não fixa; mais que isso sem variação e a
   canção cansa — normalmente 3 a 4 aparições do refrão dão conta.

## Textura

Textura é a maneira como as linhas melódicas e harmônicas se combinam
— quantas "vozes" soam ao mesmo tempo e como elas se relacionam:

- **Monofonia**: uma única linha melódica, sem acompanhamento
  harmônico (voz solo a cappella). Efeito: intimidade, exposição,
  vulnerabilidade — comum em introduções ou na primeira linha de um
  verso confessional.
- **Homofonia**: uma linha melódica principal com acompanhamento
  harmônico subordinado a ela (a melodia "manda", o resto acompanha).
  É a textura-padrão da maior parte da canção popular — verso e refrão
  cantados sobre acordes que sustentam a melodia.
- **Polifonia**: duas ou mais linhas melódicas independentes soando ao
  mesmo tempo, com peso próprio (contracantos, vocal de apoio que
  "conversa" com a linha principal, coral em contraponto). Efeito:
  densidade, grandiosidade, coletividade — comum em clímax de refrão
  ou pontes corais.
- **Heterofonia**: variações simultâneas da MESMA linha melódica
  (duas vozes cantando "quase" a mesma coisa, com pequenos
  ornamentos diferentes). Comum em música regional brasileira (choro,
  música de raiz) e em vocais duplicados com pequena variação.

**Densidade textural** é como a textura muda ao longo da canção —
intro rarefeita (poucas vozes/camadas), verso mais enxuto, refrão mais
denso (vocais de apoio entram, camadas instrumentais se somam), ponte
podendo esvaziar de novo antes do clímax final. Mesmo sem escrever
arranjo, o letrista pode *sugerir* essa curva na letra: versos com
frases mais curtas e espaçadas (deixando "buracos" para o silêncio ou
para um instrumento solar) tendem a soar mais rarefeitos; refrões com
frases mais cheias, repetição e paralelismo sintático tendem a pedir —
e a soar bem com — uma textura mais densa.

## Dinâmica

Dinâmica é a variação de intensidade sonora (do suave ao forte, com
crescendos e decrescendos). Na letra, a dinâmica se traduz em
intensidade emocional e lexical: um verso introspectivo, com
vocabulário mais concreto e cotidiano, tende a corresponder a uma
dinâmica mais suave; um refrão expansivo, com imagens maiores,
verbos de ação e declarações diretas, pede uma dinâmica mais forte.
Uma letra que quer um crescendo real geralmente escala isso ao longo
das estrofes: cada verso novo intensifica um pouco a imagem ou a
urgência da anterior, preparando o pico do refrão ou da ponte.

## Andamento, compasso e prosódia

**Andamento** é a velocidade do pulso (rápido/lento); **compasso** é
como esse pulso se agrupa (binário, ternário, quaternário — "tum-tá",
"tum-tá-tá" etc.). Nenhum dos dois é escrito na letra diretamente, mas
os dois moldam a regra mais importante de letra cantada em português:

**Prosódia**: a sílaba tônica da palavra falada deveria, na maioria
dos casos, cair num tempo forte do compasso quando cantada. Quando
isso não acontece — uma sílaba átona caindo onde o ouvido espera o
acento — a palavra soa deformada ("cantô" em vez de "cantou", ênfase
estranha em "camINHÃO" quando a melodia acentua o "ca"). É o erro mais
comum (e mais fácil de corrigir) em letras de iniciantes, e a razão
pela qual `scripts/analisar_letra.py --consistencia` importa tanto:
quando um verso 2 tem sílabas a mais ou a menos que o verso 1 na mesma
posição, ou a melodia se estica de forma estranha, ou a prosódia
quebra porque a sílaba tônica migrou de lugar.

Isso não significa que toda variação silábica seja erro — melodias
podem se ajustar (uma nota vira duas mais curtas, uma pausa absorve a
diferença), e gêneros de fluxo mais falado (funk, rap, alguns trechos
de forró) toleram bem mais liberdade prosódica do que uma balada. Mas
vale sinalizar a divergência para quem está compondo decidir se ela é
intencional.

## Timbre

Timbre é a "cor" do som — o que distingue um violão de uma flauta
tocando a mesma nota, ou uma voz rouca de uma voz limpa. É
majoritariamente uma decisão de arranjo e interpretação, fora do
escopo desta skill, mas a letra pode *sugerir* timbre pela sonoridade
das palavras: consoantes plosivas e sons fechados (p, t, k, sílabas
curtas) tendem a soar mais secos/percussivos; vogais abertas, nasais e
consoantes líquidas (l, r, m, n) tendem a soar mais quentes/redondos.
Escolher palavras pela sonoridade — não só pelo sentido — é parte
legítima do ofício, especialmente no refrão, onde a palavra vai ser
sustentada e repetida.

## Tensão e resolução

Toda forma de canção usa contraste para criar expectativa e alívio: a
ponte existe justamente para introduzir uma tensão nova — de
harmonia, de ponto de vista da letra, ou das duas coisas — antes do
retorno (geralmente reforçado) do refrão. Ao escrever uma ponte, é
comum mudar de pessoa gramatical, revelar uma informação nova, ou
inverter a perspectiva do que foi dito nos versos anteriores, para que
o refrão final "pese" mais do que os anteriores.

## Rima e métrica silábica (aplicadas à melodia)

Rima e contagem silábica funcionam de forma parecida ao que se usa em
poesia (ver a skill de poemas para o aparato completo de escansão), mas
aqui com uma exigência extra: como seções do mesmo tipo (Verso 1,
Verso 2...) costumam compartilhar a mesma melodia, as linhas
correspondentes devem, em geral, ter a mesma contagem de sílabas
poéticas *e* o mesmo esquema de rima — é isso que garante que a segunda
estrofe "encaixe" na melodia composta para a primeira sem perder o
efeito sonoro que a primeira estabeleceu. É comum corrigir a métrica de
uma linha (trocar a palavra final por outra de tamanho diferente) e,
sem perceber, quebrar a rima que ela fazia com outra linha da mesma
seção — as duas coisas precisam ser checadas juntas, não uma depois da
outra. Use `scripts/analisar_letra.py --consistencia` para checar as
duas objetivamente antes de considerar uma letra pronta.
