# Formas e gêneros musicais

Catálogo de sequências estruturais típicas — o que dá para validar
objetivamente com `scripts/analisar_letra.py --validar <nome>` (perfis
cadastrados em `scripts/generos.json`, listáveis com `--listar-generos`)
e o que fica a critério de julgamento (tema, vocabulário, registro).

Lembrete importante: forma é ponto de partida, não camisa de força.
Um samba pode ter ponte, uma balada pode ser estrófica sem refrão — o
catálogo serve para saber o que é *típico* de cada gênero e decidir,
com intenção, quando seguir ou desviar do padrão.

## Formas internacionais

### Verso-Refrão (Verse-Chorus), com ou sem pré-refrão
A forma dominante da canção popular contemporânea.
- **Enxuta**: Verso – Refrão – Verso – Refrão – Ponte – Refrão
- **Com pré-refrão**: Verso – Pré-Refrão – Refrão – Verso – Pré-Refrão –
  Refrão – Ponte – Refrão

O pré-refrão existe para criar uma rampa de tensão — geralmente frases
mais curtas, harmonia mais instável, letra que já antecipa o assunto do
refrão sem entregá-lo. Sem pré-refrão, o refrão precisa entrar com
força própria, sem rampa.

### AABA (forma dos "standards")
A – A – B – A, com cada seção geralmente do mesmo tamanho (o "32
compassos" clássico do Tin Pan Alley e do jazz: 8+8+8+8). Não há refrão
separado no sentido pop — a seção A costuma carregar tanto a narrativa
quanto o gancho melódico principal, repetido com pequenas variações de
letra a cada retorno. A seção B ("bridge"/"release") contrasta
harmônica e melodicamente, geralmente mudando de tom ou de registro
emocional, e não costuma repetir.

### Forma estrófica (strophic)
Cada estrofe reaproveita a mesma melodia, sem seção de refrão separada
— comum em canção de raiz, cantigas de roda, hinos, moda de viola.
A "unidade" que se repete e fixa na memória não é um refrão, mas o
próprio padrão métrico e melódico da estrofe. Como não há seção fixa
para validar sequência, o critério de qualidade aqui é sobretudo a
consistência silábica entre estrofes (`--consistencia`).

## Gêneros brasileiros

### Samba-canção / samba de morro
Geralmente duas estrofes narrativas antes do primeiro refrão, que
depois alterna com estrofes novas: Verso – Verso – Refrão – Verso –
Refrão. O refrão tende a ser curto e ganha repetição extra na
performance ao vivo (coro, público cantando junto) — algo que a letra
escrita não precisa marcar explicitamente, mas que vale ter em mente
ao escolher um gancho fácil de cantar em coro.

### Partido-alto
Refrão – Verso – Refrão – Verso: um refrão fixo (o "mote") abre e
retorna entre estrofes que, na roda de samba, são parcialmente
improvisadas em resposta ao mote. Ao compor uma letra "fechada" nesse
molde, os versos funcionam como um roteiro-modelo — é comum deixar
alguma estrofe mais aberta ou genérica, pensando em quem for
improvisar por cima depois.

### Moda de viola / sertanejo raiz
Estrutura em duplas de versos, tradicionalmente sextilhas (estrofes de
seis versos), sem refrão fixo separado — mais próxima da forma
estrófica. Temática rural, nostálgica, de saudade da terra ou do
trabalho no campo; registro mais formal e imagético do que o sertanejo
contemporâneo, com rima quase sempre presente e regular.

### Sertanejo universitário
Verso – Pré-Refrão – Refrão – Verso – Pré-Refrão – Refrão. Pré-refrão
curto e coloquial que aumenta a tensão emocional (frases curtas, quase
faladas) antes do refrão-gancho; é comum um verso ou interjeição falada
("vem!", "ô", "eeeh") logo antes da entrada do refrão, marcando a
virada. Vocabulário coloquial, tema quase sempre romântico
(reconciliação, saudade, paquera), registro mais direto que a moda de
viola.

### Forró (baião / xote / arrasta-pé)
Verso – Refrão – Verso – Refrão, com estrofes curtas — geralmente
quadras — e um refrão-mote também curto. A métrica tende a ser mais
enxuta (redondilhas: 5 ou 7 sílabas) para acompanhar o pulso
sincopado da sanfona/zabumba/triângulo. Temas do cotidiano nordestino,
festa, seca, amor, migração — com forte apelo sonoro e de dança.

### MPB
O gênero mais resistente a um perfil fixo: pode adotar forma
estrófica, verso-refrão, AABA adaptado, ou estruturas compostas
próprias de cada compositor. Costuma ser rica em imagens poéticas,
metáforas elaboradas e, às vezes, quebra deliberada de expectativa
métrica ou de rima (a "imperfeição" é recurso expressivo, não deslize).
Ao validar estrutura de uma letra de MPB, trate divergência do perfil
de referência como normal — o interesse aqui está mais na qualidade da
imagem e da condução da narrativa do que no encaixe da forma.

### Bossa Nova
Estrutura geralmente próxima ao AABA ou ao verso-refrão enxuto, mas
com frases mais longas e sincopadas (a melodia "atrasa" ou "adianta"
em relação ao pulso). Letra geralmente intimista, contida, com imagens
mais sugeridas do que explícitas — o oposto do apelo direto do
sertanejo ou do funk.

### Funk carioca
Refrão – Verso – Refrão – Verso – Refrão: refrão-mote muito curto e
repetitivo, abrindo e fechando blocos de verso cantados/falados em
fluxo quase de fala corrida. A prosódia clássica (tônica sempre em
tempo forte) costuma ser relaxada em favor do groove e da cadência de
fala — divergências de contagem silábica entre versos são muito mais
toleráveis aqui do que numa balada.

### Axé / Pagode
Refrão de fácil canto coletivo — frases curtas, muita repetição,
vocabulário simples — alternando com versos que servem mais para
sustentar o embalo do que para narrar em detalhe. A forma costuma ser
próxima do verso-refrão simples, mas com refrão proporcionalmente maior
em relação ao verso do que em outros gêneros.

## Escolhendo a forma certa

Algumas perguntas úteis na hora de decidir (ou ao revisar uma letra que
já existe):
- **A canção tem uma virada emocional ou de ponto de vista?** Se sim,
  vale reservar uma ponte para ela — não force uma ponte numa letra que
  já disse tudo o que precisava dizer no segundo refrão.
- **O refrão precisa ser cantável em coro/festa (forró, axé, sertanejo)
  ou é mais para ser ouvido com atenção (MPB, bossa)?** Isso pesa a
  favor de refrão curto e repetitivo no primeiro caso, mais elaborado
  no segundo.
- **A história tem personagens/tempo verbal mudando?** Formas
  estróficas (sem refrão fixo) lidam melhor com narrativa longa e
  progressiva; verso-refrão pede que o "resumo emocional" do refrão
  sirva para qualquer ponto da história.
