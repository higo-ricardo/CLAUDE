# Pipeline do modo CRIAÇÃO

Escrever uma letra **nova**, do zero. Independente do modo REVISÃO
(que trabalha em cima de algo que já existe) — CRIAÇÃO nunca parte de
uma letra pronta para corrigir; se há uma letra existente na mesa, o
pedido é REVISÃO, não CRIAÇÃO (ver `pipeline-revisao.md`).

CRIAÇÃO sozinha não avalia a qualidade do resultado — isso é trabalho
do modo AVALIAÇÃO (`pipeline-avaliacao.md`), que roda **depois**, como
etapa final do workflow CRIAR:

> **Workflow CRIAR = modo CRIAÇÃO → modo AVALIAÇÃO**, nessa ordem.

Esta pipeline tem 5 etapas, cada uma com tarefas concretas. Tarefas
marcadas **(variável por gênero)** mudam de conteúdo conforme o
gênero-alvo.

## Etapa 1 — Concepção

**Objetivo:** decidir sobre o que e para quem a canção é.

- **Tarefa 1.1 — Levantar o ponto de partida.** Pedido já formado
  ("letra de forró sobre X"), ou palavras soltas/frase solta? Ver
  `tema-e-campo-semantico.md` para o segundo caso.
- **Tarefa 1.2 — Identificar o tema central.** Uma frase de ângulo
  ("uma letra sobre..."), não um tópico solto.
- **Tarefa 1.3 — Confirmar ou inferir o gênero-alvo.** Sem sinal no
  pedido, o padrão pop enxuto é a escolha segura.
- **Tarefa 1.4 (variável por gênero) — Calibrar o registro desde já.**
  `--vocabulario <genero>` (ou `dicionario-generos.md`) antes de
  escrever a primeira linha.

## Etapa 2 — Estrutura (forma)

**Objetivo:** decidir a sequência de seções e a função de cada uma.

- **Tarefa 2.1 — Escolher a forma.** `formas-e-generos.md` e o perfil
  em `generos.json` (`--listar-generos` lista todos).
- **Tarefa 2.2 — Definir a função de cada seção.** Verso
  narra/detalha, refrão sintetiza/emociona, ponte vira a chave.
- **Tarefa 2.3 — Garantir pelo menos 4 Versos.** Padrão da skill: toda
  música com Refrão usa no mínimo 4 Versos intercalados com ele, mesmo
  que o perfil do gênero liste só 2 no exemplo estrutural. Exceções:
  pedido explícito por algo mais curto, forma sem Refrão (estrófica
  tem número livre; AABA tem contagem própria).
- **Tarefa 2.4 (variável por gênero) — Ajustar a sequência às
  convenções do gênero.** Alguns abrem com refrão (funk, partido-alto);
  outros não têm refrão separado (moda de viola, estrófica).

## Etapa 3 — Motivo e gancho

**Objetivo:** definir a frase que carrega a identidade da canção antes
de escrever o resto em volta dela.

- **Tarefa 3.1 — Escolher a frase-motivo** a partir do tema central
  (ver "Motivo" em `elementos-musicais.md`).
- **Tarefa 3.2 — Testar sonoridade e tamanho** com
  `analisar_letra.py "frase candidata"`.
- **Tarefa 3.3 (variável por gênero) — Calibrar quanto o gancho vai se
  repetir.** Funk/axé/forró toleram e esperam repetição alta; MPB/bossa
  tendem a um motivo mais sutil.

## Etapa 4 — Escrita linha a linha

**Objetivo:** escrever cada seção respeitando métrica, rima e registro
do gênero.

- **Tarefa 4.1 — Escrever a seção**, linha por linha, dentro da função
  definida na Etapa 2.
- **Tarefa 4.2 — Escandir cada linha** com `analisar_letra.py "linha"`
  conforme escreve.
- **Tarefa 4.3 — Buscar rima quando travar**, com
  `--buscar-rima "palavra"`.
- **Tarefa 4.4 (variável por gênero) — Aplicar a métrica e o
  vocabulário típicos** (`--vocabulario <genero>`).

## Etapa 5 — Autocheck de consistência

**Objetivo:** um primeiro filtro rápido antes de entregar a letra ao
modo AVALIAÇÃO — não substitui a avaliação completa, evita chegar lá
com erro óbvio.

- **Tarefa 5.1 — Rodar `--consistencia`** assim que uma seção repetir
  um tipo já escrito (sílabas + esquema de rima entre repetições).
- **Tarefa 5.2 — Corrigir divergência óbvia na hora**, sem esperar a
  avaliação completa — mais barato ajustar agora do que reescrever
  depois.

## Encerramento: passe para o modo AVALIAÇÃO

Com a letra completa e o autocheck da Etapa 5 limpo, a CRIAÇÃO termina
aqui. Siga para `pipeline-avaliacao.md` — é lá que forma, gancho,
consistência fina, rima, **musicalidade** (eco, cacofonia, frases
pesadas, excesso de palavras) e registro são checados por inteiro.
Só depois da avaliação, se ela apontar algo, é que se entrega ou se
ajusta — nunca pule a avaliação achando que o autocheck da Etapa 5 já
basta.
