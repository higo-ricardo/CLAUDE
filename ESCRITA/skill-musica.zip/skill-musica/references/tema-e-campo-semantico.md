# Tema central e campo semântico

Como transformar um ponto de partida solto — uma lista de palavras
("mar, farol, voltar"), uma frase inteira ("depois da tempestade, o
barco sempre volta"), ou até uma letra já pronta que parece "sem rumo"
— num tema central que sustenta a canção inteira.

## Por que isso vem antes de forma, motivo ou métrica

Forma, motivo e métrica (ver `elementos-musicais.md`) organizam *como*
a canção é construída. Tema central decide *sobre o que* ela é — e sem
essa decisão, as outras ferramentas não têm o que organizar. Duas
letras podem usar exatamente as mesmas palavras-semente e ficarem
completamente diferentes dependendo do ângulo escolhido: "mar" e
"farol" podem virar uma canção sobre solidão de quem ficou no porto,
sobre a coragem de quem parte, ou sobre o alívio de um reencontro — a
lista de palavras não decide isso sozinha.

## Identificando o tema central a partir de palavras soltas

1. **Agrupe por campo semântico.** Separe as palavras por área de
   sentido (natureza, tempo, corpo, sentimento, lugar, ação) e note
   quais se repetem ou se reforçam. Isso mostra a "temperatura" geral
   antes de qualquer decisão de ângulo.
2. **Procure o fio emocional, não o assunto.** "Mar" é assunto;
   "esperar alguém que nunca mais voltou" é tema. Pergunte: que
   sentimento ou situação conecta essas palavras de um jeito que só
   *essa* combinação específica conecta? Duas palavras soltas quase
   sempre admitem mais de um fio possível — é normal cogitar 2-3
   ângulos antes de escolher.
3. **Escolha UM ângulo e diga-o em uma frase**, antes de escrever
   qualquer verso: "uma letra sobre [quem faz o quê / sente o quê / em
   que situação]". Essa frase vira o critério para decidir, verso a
   verso, o que fica e o que sai — inclusive descartar uma
   palavra-semente que não serve ao ângulo escolhido (nem toda palavra
   da lista precisa aparecer literalmente na letra final; algumas
   servem só de disparador de imagem).
4. **Se a lista admitir ângulos muito diferentes e o pedido não
   decidir por você, pergunte** — uma pergunta curta e objetiva
   ("essa letra é mais sobre saudade de quem ficou, ou sobre a força
   de quem parte?") evita escrever na direção errada e descartar
   trabalho depois. Se o contexto já deixa claro (tom da frase
   original, gênero pedido, uma palavra com carga emocional óbvia
   como "saudade" ou "solidão"), decida e siga, mas nomeie a decisão
   na resposta.
5. **A partir do ângulo, distribua as palavras-semente**: qual vira
   candidata a motivo/gancho e título (geralmente a mais carregada
   emocionalmente ou mais sonora), quais viram imagens espalhadas nos
   versos, e se alguma sugere gênero ou forma (ex. "festa, sanfona,
   fogueira" puxa para forró; ver `formas-e-generos.md`).

## Identificando o tema central a partir de uma frase inteira

Uma frase pronta ("depois da tempestade, o barco sempre volta") já
carrega uma estrutura de imagem e, às vezes, até uma métrica e um
motivo embutidos:
- **Extraia o núcleo de sentido** (aqui: resistência, retorno depois
  de dificuldade) e trate a frase como candidata natural a
  motivo/gancho — ela já tem a forma de refrão.
- **Verifique se ela funciona cantada**: rode a frase em
  `analisar_letra.py` para ver a contagem silábica; se for usá-la
  como refrão repetido, esse número vira a régua para o resto da
  seção (ver "Consistência" em `elementos-musicais.md`).
- **Expanda a partir de imagens correlatas** — não repita a mesma
  ideia com outras palavras; abra o campo semântico da frase (aqui:
  mar, vento, porto, âncora) para dar material aos versos sem
  esvaziar o gancho por repetição precoce do que ele diz.

## Revisando uma letra já existente a partir de um tema/palavras novas

Quando o pedido é inserir um tema ou palavras-semente numa letra que já
existe (não criar do zero):
1. **Primeiro identifique o tema que a letra JÁ carrega** — leia o
   texto (e rode `--estrutura` e o relatório padrão) antes de assumir
   que o tema novo substitui o antigo. Às vezes o pedido é reforçar um
   tema que já está lá mas fraco, não trocar de assunto.
2. **Decida onde o tema/palavra nova entra com mais força**: no
   motivo/gancho (se for central o bastante para carregar o refrão),
   numa imagem de verso (se for coadjuvante), ou como reorientação da
   ponte (se for uma virada de perspectiva).
3. **Não force a palavra-semente onde ela não cabe** — se inserir a
   palavra nova quebra a prosódia ou soa arbitrária numa linha, é
   melhor reescrever a linha em torno da ideia da palavra do que
   encaixar o termo literal à força.
4. Depois de revisar, rode `--consistencia` para confirmar que a
   mudança não quebrou o encaixe silábico com outras seções do mesmo
   tipo.

## Campos semânticos recorrentes na canção popular brasileira

Referência rápida para expandir um tema em imagens — não é lista
fechada, e um tema real costuma cruzar mais de um campo:

- **Saudade / ausência**: mar, porto, cadeira vazia, retrato, carta,
  silêncio, relógio parado, cheiro que fica.
- **Tempo passando / nostalgia**: infância, quintal, retrato antigo,
  estrada velha, poeira, calendário, cabelo branco.
- **Amor / reencontro**: coração, chama, chuva, encontro na rua,
  mensagem, abraço, porta que se abre.
- **Festa / celebração coletiva**: sanfona, fogueira, praça, luz,
  dança, grito, batida, roda.
- **Natureza / raiz / terra**: chão, semente, raiz, colheita, chuva,
  seca, sol, enxada.
- **Estrada / viagem / mudança**: mala, rodovia, poeira, retrovisor,
  horizonte, partida, adeus.
- **Superação / resistência**: tempestade, fogo, cicatriz, levantar,
  recomeço, luz no fim, âncora.
- **Paixão / desejo**: fogo, pele, olhos, noite, dança, batida do
  coração, calor.

Use esses campos como ponto de partida para gerar imagens novas a
partir de uma palavra-semente isolada — se o usuário deu só "mar", por
exemplo, esses agrupamentos ajudam a decidir se o caminho é saudade,
resistência, paixão ou outro, em vez de escrever em torno da palavra
literal sem direção emocional.
