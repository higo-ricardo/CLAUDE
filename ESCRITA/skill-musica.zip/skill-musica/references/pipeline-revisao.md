# Pipeline do modo REVISÃO

Corrigir/refatorar uma letra que **já existe** — nunca criar do zero
(isso é CRIAÇÃO, `pipeline-criacao.md`). Os dois modos são
independentes: REVISÃO não escreve seção nova nem decide tema; parte
do que já está na página e trabalha em cima disso.

> **Workflow REVISAR = modo AVALIAÇÃO → modo REVISÃO**, nessa ordem.

REVISÃO **nunca começa direto** — ela recebe como entrada o relatório
de diagnóstico que o modo AVALIAÇÃO já produziu (`pipeline-avaliacao.md`,
Etapa 8). Se esse diagnóstico ainda não foi feito nesta conversa, rode
a pipeline de AVALIAÇÃO primeiro; não corrija de memória ou por
impressão de leitura só, sem o diagnóstico estruturado.

Esta pipeline tem 5 etapas. Para um pedido já bem pontual e restrito
("só ajusta essa linha pra caber a sílaba", "essa palavra rima errado,
troca") — onde o próprio usuário já apontou o problema exato — as
Etapas 1-2 podem ser só mentais, sem rodar `--musicalidade`/`--rima`
na letra inteira; vá direto à Etapa 3 para aquele ponto específico e
ainda assim reavalie (Etapa 4) antes de entregar.

## Etapa 1 — Ler o diagnóstico

**Objetivo:** partir do que a AVALIAÇÃO já separou, não redescobrir do
zero.

- **Tarefa 1.1 — Importar os três grupos** da Etapa 8 da AVALIAÇÃO:
  problemas objetivos, candidatos a revisar por ouvido, observações de
  gosto.
- **Tarefa 1.2 — Confirmar com o usuário** (quando o pedido for vago,
  tipo "revisa essa letra") quais dos três grupos ele quer que a
  REVISÃO toque — às vezes o pedido é só "conserta a métrica"
  (problemas objetivos), não "reescreve a imagem" (gosto).

## Etapa 2 — Priorizar

**Objetivo:** decidir a ordem de correção — nem tudo tem o mesmo peso.

- **Tarefa 2.1 — Problemas objetivos primeiro**: consistência
  silábica/rima quebrada e desvio de forma não-justificado sempre
  entram na correção, salvo instrução contrária do usuário.
- **Tarefa 2.2 — Candidatos de musicalidade em seguida**: releia cada
  um (cacofonia, eco, frase pesada, excesso de palavras) e decida se é
  problema real ou falso alarme da heurística antes de tocar na linha
  — corrigir um candidato que na leitura soa bem é retrabalho
  desnecessário.
- **Tarefa 2.3 — Observações de gosto por último**, e só se o usuário
  pediu ou topou quando oferecido — não são erro, não se corrige sem
  combinar.

## Etapa 3 — Aplicar a correção

**Objetivo:** editar preservando o que já funciona.

- **Tarefa 3.1 — Um problema por vez**, começando pelos objetivos.
  Para sílaba/rima: trocar por sinônimo de tamanho/som diferente ou
  reordenar a sintaxe — nunca cortar a imagem inteira só para bater o
  número.
- **Tarefa 3.2 — Para musicalidade**: cacofonia se resolve trocando a
  palavra de borda (a que gera a fusão) ou reordenando a frase; eco se
  resolve trocando uma das duas palavras que colidem em som; frase
  pesada se resolve simplificando o encontro consonantal mais denso;
  excesso de palavras se resolve cortando o conectivo menos
  necessário, não encurtando o conteúdo.
- **Tarefa 3.3 (variável por gênero) — Aplicar a tolerância do
  gênero** antes de "corrigir" algo que o registro do gênero-alvo já
  aceita bem (ver `dicionario-generos.md`).

## Etapa 4 — Reavaliar

**Objetivo:** confirmar que a correção resolveu sem quebrar outra
coisa — nunca assumir que corrigiu sem checar de novo.

- **Tarefa 4.1 — Rodar de novo só o que foi tocado**: se mexeu em
  sílaba/rima, `--consistencia`; se mexeu em musicalidade,
  `--musicalidade` na seção afetada; se mexeu em forma, `--estrutura`
  e `--validar`.
- **Tarefa 4.2 — Repetir a Etapa 3-4** até o grupo de problemas
  objetivos zerar e os candidatos de musicalidade estarem todos
  resolvidos ou conscientemente aceitos como falso alarme.

## Etapa 5 — Entrega

- **Tarefa 5.1 — Aplicar direto no arquivo, com changelog inline**
  (lista logo após a letra, seção por seção, do que mudou e por quê)
  — não deixe a correção só descrita em prosa se o arquivo já existe.
- **Tarefa 5.2 — Exportar**, se pedido (`exportar_letra.py`).
