# Pipeline do modo AVALIAÇÃO

Diagnóstico de uma letra **já escrita** — recém-composta ou existente
há tempo, não importa. É a fase comum a CRIAÇÃO e REVISÃO: os dois
precisam de avaliação de conteúdo, cada um com seu próprio conteúdo
(o que acabou de ser escrito vs. o que já existia) e seu próprio
momento no workflow:

> **Workflow CRIAR = CRIAÇÃO → AVALIAÇÃO** (avalia o que acabou de
> ser escrito, ao final).
> **Workflow REVISAR = AVALIAÇÃO → REVISÃO** (avalia o que já existe,
> **antes** de mexer em qualquer linha — o diagnóstico é o que decide
> o que revisar).

AVALIAÇÃO nunca edita a letra — só diagnostica. Se algo precisa
mudar, quem muda é o modo CRIAÇÃO (se for reescrever do zero) ou
REVISÃO (se for corrigir o que já existe).

AVALIAÇÃO também roda **sozinha**, fora dos dois workflows, quando o
pedido é só diagnóstico sem intenção de mudar nada agora ("essa letra
tá boa?", "como está o ritmo disso?") — nesse caso a Etapa 8
(síntese) já é a entrega final, sem passar para REVISÃO.

O núcleo específico deste modo é **ritmo e musicalidade**: frases
pesadas, cacofonia, eco e excesso de palavras — o que as Etapas 1-4
(forma, gancho, consistência, rima) não cobrem, porque são heurísticas
sonoras, não estruturais. Etapa 5 é onde isso mora.

## Etapa 1 — Estrutura

- **Tarefa 1.1 — `--estrutura`**: sequência de seções encontrada.
- **Tarefa 1.2 — `--validar <genero>`**, se houver gênero-alvo. Uma
  `semelhanca` abaixo de 1.0 sem nada em `tipos_esperados_ausentes` ou
  `tipos_presentes_fora_do_perfil` normalmente só reflete o padrão de
  4 Versos da skill superando o exemplo do perfil — não é defeito.

## Etapa 2 — Motivo e gancho

- **Tarefa 2.1 — `--gancho`**: existe frase que se repete e fixa?
  Repete pouco (risco de não grudar) ou demais (risco de cansar,
  calibrado por gênero)?

## Etapa 3 — Consistência entre seções repetidas

- **Tarefa 3.1 — `--consistencia`**: sílabas e esquema de rima batem
  entre todas as repetições do mesmo tipo (Verso 1×2×3×4, cada
  Refrão)?

## Etapa 4 — Rima

- **Tarefa 4.1 — `--rima`**: tipo (rica/pobre, consoante/toante) e
  esquema por seção, com tonicidade classificada.

## Etapa 5 — Musicalidade e ritmo

**Objetivo:** o que só aparece lendo/cantando em voz alta, não olhando
sílaba por sílaba. `--musicalidade` localiza candidatos objetivos;
**a ferramenta não julga sozinha se soa mal — ela aponta onde ler com
atenção.**

- **Tarefa 5.1 — Rodar `--musicalidade`** na letra inteira.
- **Tarefa 5.2 — Frases pesadas**: linhas com alta proporção de
  encontros consonantais (`proporcao_onsets_complexos`) custam mais
  para articular cantando. Releia essas linhas em voz alta — nem toda
  linha pesada precisa mudar, mas toda linha pesada merece essa
  releitura.
- **Tarefa 5.3 — Cacofonia candidata**: pontos onde o fim de uma
  palavra funde com o início da próxima (`cacofonia_candidatas`). A
  lista já filtra fusões triviais entre duas palavras funcionais (ex.
  "que"+"o"); o que sobra vale ler em voz alta — a maioria vai soar
  perfeitamente normal, mas de vez em quando aparece um "tudo isso"
  que funde em "dois". Só vira problema real se soar mal falado, não
  só porque apareceu na lista.
- **Tarefa 5.4 — Eco**: palavras de conteúdo (não a última da linha,
  essa é posição de rima intencional) que terminam no mesmo som dentro
  da mesma linha (`eco`) — repetição sonora provavelmente não
  planejada. Repetição da mesma palavra (ex. gancho "vem... vem") já é
  filtrada automaticamente, não aparece aqui.
- **Tarefa 5.5 — Excesso de palavras**: linhas com alta proporção de
  conectivos/artigos/preposições em relação ao total de palavras
  (`excesso_de_palavras`) — sinal de muleta de linguagem, conteúdo
  real diluído em função gramatical.
- **Tarefa 5.6 (variável por gênero) — Calibrar a tolerância.** Funk
  carioca e trechos de forró/rap toleram bem mais fluxo corrido,
  frase pesada e até alguma cacofonia menor — faz parte da estética de
  fala cantada. Balada, MPB e bossa pedem mais polimento nesses
  quatro pontos. Ver `registro` em `dicionario-generos.md`.

## Etapa 6 — Textura, dinâmica e registro

- **Tarefa 6.1 — Curva de intensidade**: verso mais contido, refrão
  mais expansivo (ver `elementos-musicais.md`), ou tudo no mesmo
  nível do início ao fim?
- **Tarefa 6.2 (variável por gênero) — `--vocabulario <genero>`**: os
  termos usados combinam com o registro esperado, ou vazou vocabulário
  de outro gênero?

## Etapa 7 — Prosódia

- **Tarefa 7.1 — Ler em voz alta** marcando um pulso imaginário: as
  sílabas tônicas caem no tempo forte, ou alguma átona parece forçada
  a carregar acento?

## Etapa 8 — Síntese do diagnóstico

**Objetivo:** compilar tudo num relatório utilizável — não uma lista
de comandos rodados, mas uma leitura do que está bom, do que pede
atenção e do que é preferência (não erro).

- **Tarefa 8.1 — Separar em três grupos**: (a) problemas objetivos
  (consistência silábica/rima quebrada, forma que se afasta do
  gênero sem justificativa), (b) candidatos a revisar por ouvido
  (musicalidade — cacofonia, eco, frase pesada), (c) observações de
  gosto (imagem, escolha de palavra) que não são "erro".
- **Tarefa 8.2 — Entregar o relatório.** Se o workflow é **CRIAR**,
  este relatório fecha a entrega (mais o texto da letra). Se o
  workflow é **REVISAR**, este relatório é o **insumo** que abre o
  modo REVISÃO (`pipeline-revisao.md`) — não se aplica nenhuma
  correção antes desta etapa terminar.
