# Baseline de RF/NFR por tipo de projeto

Ponto de partida para as seções 3 (Requisitos Funcionais) e 4 (Requisitos
Não Funcionais) — **não é lista para copiar cega**. Use como checklist de
"o que um projeto desse tipo normalmente precisa e o usuário pode não ter
mencionado"; adapte ao domínio real e sinalize sempre o que veio daqui
("inferido do padrão de mercado para <tipo>") vs. o que foi pedido
explicitamente. Item que não se aplica ao projeto real: descarte, não
force.

---

## Web app (CRUD / SaaS)

**RF comuns**
- Autenticação e recuperação de senha
- Paginação em listagens com mais de N itens
- Validação de formulário com feedback inline (não só no submit)
- Busca/filtro nas listagens principais
- Exportação de dados (CSV/PDF) quando há listagem tabular relevante

**NFR comuns**
- **Responsividade**: layout utilizável em viewport mobile (≥360px)
- **Sessão**: expiração/renovação de token definida explicitamente
- **Auditoria**: ações que alteram dado sensível geram log (quem, quando, o quê)
- **Rate limiting** em endpoints de autenticação e escrita pública

---

## Desktop (Python standalone — Flet, Tkinter, PyQt etc.)

**RF comuns**
- Persistência local sobrevive a fechar/reabrir o app
- Feedback visual de operação longa (spinner/progresso), nunca UI travada
- Atualização automática ou notificação de nova versão, se distribuído fora de loja
- Configurações do usuário persistidas entre sessões

**NFR comuns**
- **Portabilidade**: SO(s) alvo explícitos (Windows/macOS/Linux) — não assuma multiplataforma sem decisão
- **Consumo de recursos**: teto de uso de memória/CPU em idle, se app roda em background
- **Empacotamento**: estratégia de build de executável (PyInstaller/Nuitka/outro) como ADR, não deixado para o fim
- **Dados locais**: onde ficam (pasta do usuário, `AppData`/`~/.config`) e se há criptografia em repouso

---

## API (REST/GraphQL, sem frontend próprio)

**RF comuns**
- Versionamento de contrato explícito (`/v1/`, header, ou outro esquema)
- Autenticação de cliente (API key, OAuth, JWT) e escopo de permissões
- Paginação e ordenação padronizadas em endpoints de listagem
- Documentação de contrato gerada (OpenAPI/Swagger) a partir do código, não mantida à mão

**NFR comuns**
- **Latência**: P95 por endpoint crítico com valor concreto
- **Idempotência**: endpoints de escrita repetíveis com segurança (ex.: `POST` com chave de idempotência) quando cliente pode reenviar
- **Retrocompatibilidade**: política explícita para depreciar campo/endpoint
- **Observabilidade**: métricas e logs estruturados por request (correlação/trace id)

---

## CLI

**RF comuns**
- `--help` completo e exemplos de uso para cada comando
- Códigos de saída (`exit code`) distintos por classe de erro, não só 0/1
- Modo não-interativo (flags cobrem tudo que o modo interativo pergunta) para uso em script/CI

**NFR comuns**
- **Saída máquina-legível**: opção `--json`/`--quiet` para composição em pipeline
- **Idempotência de comando**: rodar duas vezes com mesmo input não corrompe estado
- **Instalação**: forma de distribuição (`pip install`, binário standalone) decidida como ADR

---

## Como usar

1. Na entrevista (etapa 1 do fluxo), depois de identificar o tipo de
   projeto, abra a seção correspondente aqui antes de escrever RF/NFR.
2. Cruze com o que o usuário já disse — não repita o que ele já definiu.
3. Todo item aproveitado daqui entra na spec sinalizado como inferido
   (mesma convenção de `core-sections.md`), para o usuário poder vetar.
4. Projeto que mistura tipos (ex.: web app com CLI de administração):
   consulte as duas seções, sem duplicar itens equivalentes.
