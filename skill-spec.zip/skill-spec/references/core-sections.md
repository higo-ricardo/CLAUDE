# Template universal de SPEC.md

Esqueleto fixo: sempre as mesmas 10 seções, nessa ordem. Pular uma exige
nota explícita ("não se aplica, porque X"), nunca omissão silenciosa.
Quatro pontos geram, além do conteúdo na SPEC.md, um plano separado
autoexecutável: seções 6, 8, 9 (resumo + ponteiro) e a subseção 2.8/Testes
(decisão na spec, plano ao final deste template). A seção 10 (Milestones) é
o despachante que decide quando cada etapa de cada plano entra.

Numere as seções (`## 1. ...`) e separe com `---` entre elas, como abaixo.

---

## Título + parágrafo de abertura

```markdown
# SPEC — <Nome do Projeto> (<tecnologia principal em destaque>)

<1-3 parágrafos curtos: o que o app faz, em que ele roda, qual a peça central
da arquitetura. Se deriva de outro projeto existente, diga a diferença central.>
```

O "elevator pitch" técnico: quem lê só isso já entende o que está sendo
construído e a decisão arquitetural mais importante.

---

## 1. Visão

```markdown
## Problema

<parágrafo: que dor isso resolve, para quem, o que existe hoje e por que não basta>

## Escopo

- <o que entra nesta versão>
- <o que fica explicitamente fora — evita escopo implícito>

## Usuários

- **<perfil/persona>**: <o que essa pessoa faz no sistema, o que ela precisa ver>
```

Sem resposta a essas três perguntas, todo requisito depois vira ambíguo —
não abrevie mesmo em specs pequenas.

---

## 2. ADRs (Decisões de Arquitetura por Etapa)

Fonte única de cada decisão estrutural, organizada nas 8 etapas fixas
abaixo. O resto da spec só *implementa* essas decisões; se uma seção
contradiz um ADR, o ADR vence (ou precisa ser atualizado).

Regra de ouro: ADR só existe quando havia mais de uma opção razoável.
"Usar Python" não é ADR num projeto Python. "SQLite em vez de Postgres
porque o app roda 100% local" é.

Cada etapa usa o mesmo esqueleto:

```markdown
| ADR | Decisão | Motivo |
|---|---|---|
| **ADR-1** | <decisão concreta, uma frase> | <por que essa decisão e não a alternativa óbvia> |
```

### 2.1 Onboarding

Primeira experiência do usuário: cadastro, login, tour inicial, estado
vazio.

### 2.2 Setup Inicial

Scaffolding e ferramental: gerenciador de pacotes, ambiente, config, CI.

### 2.3 Componentes

Como o sistema é dividido em blocos funcionais e por quê (não o detalhe de
cada um — isso é a seção 8).

### 2.4 Frontend

Framework/padrão de UI, gerenciamento de estado, roteamento.

### 2.5 Backend

Framework/padrão de servidor, persistência, autenticação, isolamento de
provedores externos — incluindo IA, ver `agentic-systems.md`/
`python-ai-api.md`.

### 2.6 API *(se necessário)*

Contrato de API (REST/GraphQL/RPC, versionamento, autenticação de cliente)
— pule com nota se não há API.

### 2.7 Configurações de PWA

Manifest, service worker, cache offline, instalabilidade — pule com nota se
não é PWA.

### 2.8 Testes

Estratégia de teste (unitário/integração/e2e, ferramentas, cobertura
mínima). Plano detalhado: `<slug>-test-plan.md` (estrutura ao final deste
documento).

---

## 3. Requisitos Funcionais

Já definidos pelo usuário ou, na ausência, inferidos do padrão de mercado
(ver `references/rf-nfr-baseline.md` para o baseline por tipo de projeto)
— sinalize quando inferido.

```markdown
| ID | Requisito | Critério de aceite |
|---|---|---|
| **RF-01** | <o que o sistema faz, de forma observável pelo usuário> | <como alguém confirma que está feito — comportamento, não implementação> |
```

Critério ruim: "funciona bem". Bom: "erro < 5% em 100 execuções".

---

## 4. Requisitos Não Funcionais

Mesma lógica da seção 3 (ver `references/rf-nfr-baseline.md`), cobrindo
qualidades transversais: nomenclatura, acoplamento, privacidade,
concorrência, resiliência, segurança, performance, responsividade.

```markdown
| NFR | Descrição |
|---|---|
| **<Categoria>** | <regra concreta e checável> |
```

---

## 5. Regras de Negócio e Casos de Borda

Já definidas pelo usuário ou inferidas do padrão de mercado do domínio —
sinalize quando inferido.

```markdown
### Regras de Negócio

| Regra | Descrição |
|---|---|
| **RN-01** | <condição/restrição que o sistema sempre aplica> |

### Casos de Borda

| Cenário | Comportamento esperado |
|---|---|
| <situação-limite: input vazio, concorrência, timeout, dado duplicado> | <o que o sistema faz, não o que ele "deveria" fazer> |
```

Caso de borda bom é específico do domínio — "e se a internet cair" só
entra se afeta este projeto de um jeito particular; senão é NFR (seção 4).

---

## 6. Design e UX

Resumo curto + ponteiro na SPEC.md:

```markdown
<1 parágrafo: estilo visual pretendido, tom da experiência>

Plano detalhado e autoexecutável: `<slug>-design-ux.md`.
```

Pule (com nota) para sistemas sem interface visual.

### Estrutura do arquivo `<slug>-design-ux.md`

Autoexecutável: quem implementa só esse arquivo, sem reler a spec inteira,
constrói as telas. Organize por fluxo, reaproveitando o formato de Marco
(seção 10):

```markdown
# Design e UX — <Nome do Projeto>

## Wireframes

### Tela: <nome>
\`\`\`
<wireframe ASCII — layout e hierarquia, não pixel-perfect>
\`\`\`

## Fluxos de Usuário (User Flows)

### Fluxo: <nome>
1. <passo> → <tela/estado resultante>
2. <passo> → <tela/estado resultante>

## Componentes e Widgets

| Componente | Props/Estado | Comportamento |
|---|---|---|

## Etapas de Implementação Visual

### Etapa N — <entrega>
**O que o usuário vê:** <descrição literal da tela/interação após esta etapa>
**Critério de aceite:**
- <bullet verificável>
**Arquivos:** <componentes/telas criados ou modificados>
```

---

## 7. Arquitetura

Governança, não execução: árvore de diretórios em **nível alto**
(pastas/módulos, não arquivo por arquivo) + tabela de relações. A árvore
detalhada e final é responsabilidade única de `<slug>-code-model.md`
(seção 8) — referencie-a aqui, não duplique.

```markdown
\`\`\`
app/
├── modulo_a/      # <responsabilidade da pasta, uma linha>
├── modulo_b/
└── testes/
\`\`\`

Árvore de arquivos detalhada: ver `<slug>-code-model.md`.

| Parte | Depende de | Não deve depender de |
|---|---|---|
| `<módulo>` | `<módulos que ele importa>` | `<módulos que criariam acoplamento indevido>` |
```

"Não deve depender de" torna violações de camada verificáveis por
inspeção, não só por convenção verbal.

---

## 8. Modelagem de Código

Resumo curto + ponteiro na SPEC.md:

```markdown
<1 parágrafo: paradigma geral (funcional/OOP), nível de tipagem exigido>

Plano detalhado e autoexecutável: `<slug>-code-model.md`.
```

### Estrutura do arquivo `<slug>-code-model.md`

Hierarquia de protocolos, classes e métodos, seguindo PEP 8 e SOLID
deliberadamente — em especial **DIP** (núcleo depende de abstração, não de
implementação concreta) e **ISP** (contrato só expõe o que o consumidor
usa; interface "gorda" é sinal de que deveria ser duas). Não crie interface
para tudo.

```markdown
# Modelagem de Código — <Nome do Projeto>

## Árvore de Arquivos Detalhada

\`\`\`
app/
├── principal.py       # entry point
├── modulo_a/
│   └── arquivo.py      # o que ele contém
└── testes/
    └── teste_x.py
\`\`\`

Única fonte da árvore completa — a seção 7 da spec principal só mostra o
nível alto.

## Protocolos/Interfaces

\`\`\`python
class NomeDoProtocolo(Protocol):
    def metodo(self, arg: tipo) -> tipo: ...
\`\`\`
<só modele como Protocol uma fronteira real de variação>

## Classes e Hierarquia

\`\`\`
ClasseBase
├── ClasseFilhaA   # <responsabilidade>
└── ClasseFilhaB   # <responsabilidade>
\`\`\`

## Métodos Centrais

| Classe.método | Assinatura | Contrato |
|---|---|---|

## Design Patterns Aplicados *(quando o volume de classes justificar)*

| Pattern | Onde | Por quê |
|---|---|---|

## Ordem de Implementação

### Etapa N — <o que fica pronto>
**Arquivos:** <classes/módulos criados nesta etapa>
**Depende de:** <etapa anterior ou "nenhuma">
```

---

## 9. Modelagem de Dados

Resumo curto + ponteiro na SPEC.md:

```markdown
<1 parágrafo: banco/armazenamento escolhido, nível de normalização>

Plano detalhado e autoexecutável: `<slug>-data-model.md`.
```

Pule (com nota) para sistemas sem persistência própria.

### Estrutura do arquivo `<slug>-data-model.md`

```markdown
# Modelagem de Dados — <Nome do Projeto>

## Entidades/Schemas

\`\`\`python
class NomeDaEntidade(BaseModel):
    campo: tipo
    outro_campo: tipo | None = None   # comente regras não óbvias
\`\`\`

## Relações

| Entidade A | Relação | Entidade B | Regra |
|---|---|---|---|
| `<Entidade>` | 1:N / N:N / 1:1 | `<Entidade>` | <cascade, obrigatoriedade, unicidade> |

## Migrations *(se aplicável)*

<estratégia de versionamento de schema — ferramenta e convenção>

## Ordem de Implementação

### Etapa N — <o que fica pronto>
**Arquivos:** <migrations/modelos criados nesta etapa>
**Depende de:** <etapa anterior ou "nenhuma">
```

---

## 10. Estratégia de Entregas por Fases (Milestones)

O **despachante**: os planos separados descrevem *o quê* e *como*; só o
Milestone decide *quando* — em que marco cada etapa entra, e em que ordem
os planos se cruzam (ex.: etapa 1 de dados antes da etapa 2 de código, que
depende do schema existir). Sem esta seção, os planos são partes soltas
sem sequência.

Marcos sequenciais, cada um com entrega testável pelo usuário — nunca um
marco que só "prepara terreno". Todo marco que envolve um plano separado
referencia a etapa que ele fecha, via "Planos referenciados" abaixo.

```markdown
### Marco N — <nome da entrega>

**O que o usuário vê:**
\`\`\`bash
<comando real que o usuário roda>
# → <saída/efeito observável esperado, literal>
\`\`\`

**Comando de verificação:**
\`\`\`bash
<comando de teste automatizado que confirma o marco>
\`\`\`

**Critério de aceite:**
- <bullet verificável, comportamento observável — não implementação>

**Planos referenciados:** <ex.: "Etapa 2 de `<slug>-code-model.md` + Etapa 1 de `<slug>-data-model.md` + casos C1-C3 de `<slug>-test-plan.md`" — vazio só se o marco não toca nenhum plano separado>

**Arquivos criados:**
\`\`\`
<lista de arquivos novos>
\`\`\`

**Arquivos modificados:** *(quando aplicável)*
\`\`\`
<lista de arquivos alterados>
\`\`\`
```

Marco com armadilha conhecida: liste ao final — economiza retrabalho.

Ao final, tabela resumo (mesmo comando de verificação de cada marco):

```markdown
| Marco | O que entrega | Comando de verificação | Dias |
|---|---|---|---|
```

---

## Estrutura do arquivo `<slug>-test-plan.md`

Gerado sempre que a etapa 2.8 não for "não se aplica". Fontes obrigatórias
de caso de teste: cada linha de **Casos de Borda** (seção 5) vira pelo
menos um caso; todo método de **Métodos Centrais** (`<slug>-code-model.md`)
com contrato não-trivial (validação, cálculo, decisão) vira pelo menos um.
Sem teste de getter/setter trivial só para "cobrir".

```markdown
# Plano de Testes — <Nome do Projeto>

## Casos de Teste

| ID | Origem | Tipo | Cenário | Resultado esperado |
|---|---|---|---|---|
| **T-01** | <RF-XX / Caso de Borda / Classe.método> | unit/integration/e2e | <o que é exercitado> | <asserção concreta, não "funciona corretamente"> |

## Ordem de Implementação

### Etapa N — <o que fica coberto>
**Casos:** <IDs desta etapa>
**Depende de:** <etapa do plano de código/dados que precisa existir antes, ou "nenhuma">
```

"Origem" é o que torna o plano rastreável: todo caso remonta a um
requisito, regra, caso de borda ou contrato de método — nunca solto.
