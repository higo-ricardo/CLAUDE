---
name: spec-skill
description: >
  Gera/revisa specs técnicas de software em 10 seções fixas (Visão, ADRs,
  Requisitos, Regras de Negócio e Casos de Borda, Design/UX, Arquitetura,
  Modelagem de Código e de Dados, Milestones), com planos separados
  autoexecutáveis para Design/UX, Código, Dados e Testes. Use para
  documentar arquitetura, formalizar ADRs, planejar app antes de codar,
  wireframes, modelagem de classes/dados, casos de teste. Cobre sistemas
  agênticos (OpenAI Agents SDK, Google ADK, outros) e API de IA direta
  (OpenAI/Anthropic SDK). Ativa mesmo sem a palavra "spec" — ex.: "antes de
  programar, vamos definir a arquitetura".
---

# Spec Skill

Gera documentos de especificação técnica completos e consistentes, sempre na
mesma estrutura de 10 seções, com ou sem IA/agentes — ver
`references/core-sections.md` para o template exato.

As ADRs (seção 2) são organizadas em 8 etapas fixas: Onboarding, Setup
Inicial, Componentes, Frontend, Backend, API, PWA, Testes. A Modelagem de
Código (seção 8) segue PEP 8 e SOLID deliberadamente.

## Por que esse formato

Uma boa spec registra **decisões** (com motivo), define contratos
verificáveis e quebra a implementação em marcos testáveis — cada seção
elimina um tipo de ambiguidade que causaria retrabalho. Separar Design/UX,
Código e Dados em planos próprios permite implementar cada frente lendo só
o seu arquivo, sem a spec inteira em contexto.

## Fluxo de trabalho

### 1. Entrevista em lote — no máximo duas interações

Nunca gere a spec inteira a partir de uma frase curta, mas também não
transforme a entrevista em pergunta solta atrás de pergunta solta. Cubra o
essencial em duas interações:

1. **Texto livre, uma mensagem só**: nome e objetivo do projeto (seção 1),
   tecnologias já decididas (linguagem, frameworks, banco).
2. **Uma leva única de múltipla escolha** (`ask_user_input_v0`, até 3
   perguntas no mesmo turno): tipo de projeto (web app/CLI/API/mobile/
   desktop/biblioteca/multiagente + é PWA?); envolve IA/LLM (agêntico + qual
   framework, ou API direta + qual SDK/provedor, ou não usa); tem interface
   visual (wireframe/referência já em mente ou a skill propõe do zero).

Não pergunte "requisitos/regras já definidos" em aberto: assim que o tipo
de projeto é conhecido, puxe `references/rf-nfr-baseline.md` e proponha o
RF/NFR já escrito, sinalizado como inferido — o usuário edita ou remove em
vez de listar do zero (ver etapa 4, esqueleto pré-preenchido).

As respostas já determinam quais das 8 etapas de ADR se aplicam (tipo de
projeto → API/PWA; pergunta de IA → agêntico vs. IA direta vs. sem IA) —
infira direto, sem pergunta extra. Só abra uma confirmação explícita quando
a resposta ficou ambígua (ex.: "tem IA" sem dizer se é agêntica).

### 2. Montar a spec seção por seção

Leia `references/core-sections.md` — formato exato das 10 seções e dos
planos separados. Antes de escrever as seções 3 e 4, abra
`references/rf-nfr-baseline.md` na entrada correspondente ao tipo de
projeto identificado na entrevista — ponto de partida a adaptar, não lista
para copiar cega. Siga à risca; não pule seção sem nota de "não se aplica,
porque X". Com IA, leia também o arquivo condicional certo antes dos ADRs
de Backend/Frontend e da Modelagem de Código:

| Projeto | Leia também | Cobre |
|---|---|---|
| Sistema agêntico (handoffs, tools, multiagente) | `agentic-systems.md` | Padrões por framework: OpenAI Agents SDK, Google ADK/Gemini SDK, genérico |
| App Python com API de IA direta | `python-ai-api.md` | Client wrapper, retries, orçamento, validação de output |
| Sem IA | nenhum | `core-sections.md` sozinho já cobre tudo |

### 3. Convenção de linguagem

Escreva no mesmo idioma da conversa. Não assuma identificadores em
português por padrão — siga a convenção do projeto (se houver código
existente, espelhe o idioma dele).

### 4. Entrega — sempre em múltiplos arquivos

A spec principal (`<slug>-spec.md`) cobre as seções 1-5, 7 e 10 por
inteiro, e resumo + ponteiro para 6, 8 e 9. Planos separados conforme o
projeto:

- `<slug>-design-ux.md` — se há interface visual (seção 6).
- `<slug>-code-model.md` — sempre que há modelagem não-trivial (seção 8).
- `<slug>-data-model.md` — se há persistência própria (seção 9).
- `<slug>-test-plan.md` — sempre que a etapa 2.8 não for "não se aplica".

Todos como arquivo `.md` (`create_file`, `/mnt/user-data/outputs/`,
`present_files` de uma vez), nunca só no chat.

Construa iterativamente: esqueleto das 10 seções primeiro, já com as
seções 3 e 4 preenchidas pelo baseline proposto na entrevista (não só
títulos vazios) — o usuário revisa conteúdo desde a primeira passada, em
vez de aprovar estrutura vazia e só depois ver o conteúdo. Confirme a
estrutura com o usuário antes de preencher o restante quando o projeto
envolve IA/agêntico, PWA ou múltiplas entidades persistidas — nesses casos
um esqueleto errado custa caro para corrigir depois. Para specs simples
(sem IA, sem PWA, persistência trivial ou nenhuma) pule direto ao
preenchimento seção por seção. Gere os planos por último nesta ordem:
dados → código → design/UX → testes — dados vem antes de código porque as
classes de repositório/serviço em `<slug>-code-model.md` referenciam os
schemas de `<slug>-data-model.md`; testes por último porque depende dos
outros.

### 5. Revisão de spec existente

Leia o(s) arquivo(s) primeiro, identifique quais seções/planos já existem
e quais faltam, e proponha o diff antes de reescrever — não descarte
conteúdo do projeto que já estava certo. Regrave só o(s) arquivo(s) cuja
seção-fonte mudou (ex.: mudança na seção 5 Casos de Borda regrava
`<slug>-test-plan.md` por rastreamento, mas não `<slug>-code-model.md` se
os métodos não mudaram) — nunca reescreva um plano separado que a mudança
não toca.

## Checklist final antes de entregar

- [ ] As 10 seções estão presentes, na ordem — nenhuma pulada sem nota de "não se aplica, porque X"
- [ ] As 8 etapas de ADR foram consideradas — API/PWA marcadas "não se aplica" quando for o caso, não omitidas
- [ ] Toda decisão de arquitetura relevante virou ADR na etapa certa, não só menção solta
- [ ] Todo RF/NFR/Regra de Negócio/Caso de Borda tem critério de aceite — claro quando foi inferido vs. pedido
- [ ] Design/UX, Código, Dados e Testes aplicáveis viraram arquivo separado, não só resumo
- [ ] Os planos são autoexecutáveis — implementáveis lendo só o arquivo, sem reabrir a spec principal
- [ ] Todo caso de teste rastreia a um RF/NFR/Regra/Caso de Borda ou método — nenhum solto
- [ ] Árvore de arquivos detalhada só em `<slug>-code-model.md` — seção 7 tem só nível alto + relações
- [ ] Milestones testável (o que o usuário vê + comando de verificação + critério) e referencia os planos que fecha
- [ ] Nenhuma seção condicional (agêntica / API de IA) incluída sem necessidade real
