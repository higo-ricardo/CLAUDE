# Changelog — Editora Ebook

## v3 — Pipeline simplificado (M4+M5 fundidos, 4 limiares → 2)

**Motivação**: M4 (Redação, limiar 6.0) e M5 (Revisão, limiar 7.0) exigiam
duas rodadas de pontuação separadas sobre o mesmo capítulo — o AUTOR se
autoavaliava em M4, e o REVISOR/CRÍTICO pontuavam de novo em M5,
frequentemente sobre as mesmas cinco dimensões (S1–S5). Isso duplicava
o trabalho de julgamento da LLM sem agregar precisão real ao gate.

**Mudanças**:
- `M4 Redação` (6.0) + `M5 Revisão` (7.0) → **M4 único "rascunho aprovado"
  (7.0)**. AUTOR escreve, REVISOR e CRÍTICO avaliam juntos com
  `analyzer.py` + um só `scorer.py --stage M4`. Não existe mais
  autoavaliação do AUTOR.
- `M6 Copywriting` (7.5) perde limiar próprio → vira **M5 Copy**, sem
  gate independente. Sua qualidade é medida junto no score final de M6.
- `M7 Validação Final` (8.0) → renumerado para **M6 "pronto pra
  publicar" (8.0)** — único segundo gate do pipeline.
- `M8 Export` → **M7**. `M9 Publicação` → **M8**.
- **4 limiares de score (6.0/7.0/7.5/8.0) → 2 (7.0 e 8.0)**.
- `scorer.py`: `STAGE_THRESHOLDS` reduzido a `{"M4": 7.0, "M6": 8.0}`,
  novo `GATE_NAMES` para exibir o nome do gate no scorecard, `--stage`
  agora só aceita `M4`/`M6`.
- `SKILL.md`, `README.md` e as referências `03`, `05`, `06`, `07`, `08`,
  `09`, `10`, `11`, `12`, `13` atualizadas com a nova numeração e regras
  globais #7/#8 reescritas (não há mais "score do CRÍTICO prevalece
  sobre autoavaliação do AUTOR" porque essa autoavaliação não existe
  mais).

**Efeito esperado**: pipeline continua com 8 estágios (era 9) e apenas
2 gates de score bloqueantes (eram 4) — menos rodadas de pontuação
repetida por capítulo, sem perder a garantia de qualidade nos dois
momentos que importam: rascunho aprovado e pronto pra publicar.

---

## v3.1 — Implementação de A, B e D (reavaliadas após a fusão M4+M5)

C foi descartada nesta rodada: a fusão de M4+M5 já eliminou a dupla
pontuação do mesmo capítulo que C tentava tornar incremental — não
sobrou redundância real para otimizar.

**A — `analyzer.py --mode all`**
Novo modo que roda `passive` + `readability` + `numbering` + `jargon`
(se `--glossary` for passado) numa única leitura/parse do texto, em vez
de até 4 invocações separadas do script sobre o mesmo arquivo. Testado.

**B — `streamer.py chunk_and_analyze`**
Duas correções, não uma:
1. *Bug real encontrado durante a implementação*: o subparser principal
   usava `dest="mode"`, e o subcomando `chunk-analyze` tinha seu próprio
   `--mode`, escrevendo no mesmo atributo do namespace — `args.mode`
   nunca valia `"chunk-analyze"`, então o dispatch em `main()` nunca
   executava essa função. `chunk-analyze` estava silenciosamente
   quebrado. Corrigido renomeando o subparser para `dest="command"`
   (e o `--command` de `stream-pipe` para `dest="command_str"`, mesmo
   problema em miniatura).
2. Depois de corrigido, o pipeline duplicava a chamada do `analyzer.py`
   por chunk (uma via `stream_pipe`, outra via `subprocess.run` só para
   capturar o JSON). Substituído por import direto de `analyzer.py`
   como módulo — cada chunk agora é uma chamada de função no mesmo
   processo, não dois subprocessos. Testado com 30 chunks: ~0,01s
   total, sem nenhum `python` adicional subindo.

**D — cache de `decisions.py --action list`**
Novo arquivo `data/.decisions_list_cache.json` guarda o `mtime` de
`decisions.json` na última listagem. Se nada mudou desde então,
`--action list` devolve um resumo de uma linha em vez da tabela
completa; `--action add`/`alter` mudam o mtime naturalmente ao
gravar, então o cache se invalida sozinho sem lógica extra. `--force`
ignora o cache. Testado: hit, miss e invalidação automática após
`--action add`.
