#!/usr/bin/env python3
"""
streamer.py — Chunk & Streaming para a Editora Ebook.

Dois modos de operação (locais, sem chamada de API externa):
  1. chunk-file   — divide arquivo .md grande em chunks para processamento paralelo
  2. stream-pipe  — executa script + captura output em streaming linha a linha
  3. chunk-analyze — chunk + análise por chunk, tudo no mesmo processo Python
                      (analyzer.py é importado como módulo, não chamado via
                      subprocess — ver CHANGELOG v3.1)

Uso:
  # Dividir capítulo longo em chunks para analyzer.py
  python scripts/streamer.py chunk-file --input cap_longo.md --size 500

  # Executar script com output em streaming (linha a linha)
  python scripts/streamer.py stream-pipe \
    --command "analyzer.py --text cap01.md --mode readability --level leigo"
"""

import argparse
import json
import os
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path

SCRIPTS_DIR = Path(__file__).parent
PROJECT_ROOT = SCRIPTS_DIR.parent

sys.path.insert(0, str(SCRIPTS_DIR))
import analyzer  # noqa: E402 — import direto para chunk-analyze rodar em processo,
                  # sem subir um subprocess Python por chunk (ver CHANGELOG v3.1)

# ─────────────────────────────────────────────────────────────────────────────
# MODO 1: CHUNK DE ARQUIVO
# ─────────────────────────────────────────────────────────────────────────────

def chunk_file(input_path: str, chunk_size: int, overlap: int, output_dir: str):
    """
    Divide um arquivo .md em chunks de N palavras com overlap configurável.
    Preserva parágrafos inteiros — nunca corta no meio de uma frase.
    Retorna manifesto JSON com metadados de cada chunk.
    """
    path = Path(input_path)
    if not path.exists():
        print(f"[CHUNK] Arquivo não encontrado: {input_path}", file=sys.stderr)
        sys.exit(1)

    text = path.read_text(encoding="utf-8")
    paragraphs = [p.strip() for p in re.split(r'\n\n+', text) if p.strip()]

    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    chunks = []
    current_words = []
    current_paras = []
    chunk_idx = 0
    total_words = len(text.split())

    print(f"[CHUNK] Arquivo: {path.name}")
    print(f"[CHUNK] Total de palavras: {total_words}")
    print(f"[CHUNK] Tamanho do chunk: {chunk_size} palavras | Overlap: {overlap} palavras")
    print()

    for para in paragraphs:
        para_words = para.split()
        current_words.extend(para_words)
        current_paras.append(para)

        if len(current_words) >= chunk_size:
            # Salvar chunk
            chunk_text = "\n\n".join(current_paras)
            chunk_file_path = out_dir / f"chunk_{chunk_idx:03d}.md"
            chunk_file_path.write_text(chunk_text, encoding="utf-8")

            word_count = len(current_words)
            chunk_meta = {
                "index": chunk_idx,
                "file": str(chunk_file_path),
                "words": word_count,
                "paragraphs": len(current_paras),
                "start_para": paragraphs.index(current_paras[0]),
            }
            chunks.append(chunk_meta)

            print(f"  chunk_{chunk_idx:03d}.md  →  {word_count} palavras  ({len(current_paras)} parágrafos)")

            # Overlap: manter últimos N palavras para contexto
            if overlap > 0:
                overlap_text = " ".join(current_words[-overlap:])
                # Encontrar parágrafo que contém essas palavras
                carry_paras = []
                carry_words = 0
                for p in reversed(current_paras):
                    carry_paras.insert(0, p)
                    carry_words += len(p.split())
                    if carry_words >= overlap:
                        break
                current_paras = carry_paras
                current_words = " ".join(carry_paras).split()
            else:
                current_paras = []
                current_words = []

            chunk_idx += 1

    # Último chunk (palavras restantes)
    if current_paras:
        chunk_text = "\n\n".join(current_paras)
        chunk_file_path = out_dir / f"chunk_{chunk_idx:03d}.md"
        chunk_file_path.write_text(chunk_text, encoding="utf-8")
        word_count = len(current_words)
        chunks.append({
            "index": chunk_idx,
            "file": str(chunk_file_path),
            "words": word_count,
            "paragraphs": len(current_paras),
        })
        print(f"  chunk_{chunk_idx:03d}.md  →  {word_count} palavras  ({len(current_paras)} parágrafos)")
        chunk_idx += 1

    # Salvar manifesto
    manifest = {
        "source": str(path.resolve()),
        "total_words": total_words,
        "total_chunks": chunk_idx,
        "chunk_size": chunk_size,
        "overlap": overlap,
        "chunks": chunks,
    }
    manifest_path = out_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    print()
    print(f"[CHUNK] {chunk_idx} chunks gerados em '{out_dir}'")
    print(f"[CHUNK] Manifesto: {manifest_path}")
    return manifest


# ─────────────────────────────────────────────────────────────────────────────
# MODO 2: STREAM-PIPE — script com output linha a linha
# ─────────────────────────────────────────────────────────────────────────────

def stream_pipe(command: str, label: str):
    """
    Executa um script da Editora Ebook e entrega output linha a linha (streaming).
    Captura stderr separadamente. Mede tempo de execução.
    """
    try:
        parts = shlex.split(command)
    except ValueError as e:
        print(f"[STREAM-PIPE] Comando malformado (aspas não fechadas?): {e}", file=sys.stderr)
        return 1, 0, 0
    if not parts:
        print("[STREAM-PIPE] Comando vazio.", file=sys.stderr)
        return

    script_name = parts[0]
    script_path = SCRIPTS_DIR / script_name
    if not script_path.exists():
        print(f"[STREAM-PIPE] Script não encontrado: {script_name}", file=sys.stderr)
        return

    cmd = [sys.executable, str(script_path)] + parts[1:]

    # Resolver caminhos relativos
    resolved_cmd = []
    for i, arg in enumerate(cmd):
        if i > 1 and not arg.startswith("-"):
            candidate = PROJECT_ROOT / arg
            if candidate.exists() and not Path(arg).exists():
                resolved_cmd.append(str(candidate))
                continue
        resolved_cmd.append(arg)

    tag = f"[{label}]" if label else f"[{script_name}]"
    print(f"{tag} Executando: {command}")
    print("─" * 60)

    start = time.time()
    lines_out = 0

    try:
        proc = subprocess.Popen(
            resolved_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=str(PROJECT_ROOT),
        )

        # Streaming linha a linha
        for line in proc.stdout:
            print(line, end="", flush=True)
            lines_out += 1

        proc.wait()
        stderr_out = proc.stderr.read()
        elapsed = time.time() - start

        print("─" * 60)
        print(f"{tag} Concluído em {elapsed:.3f}s | {lines_out} linhas | exit={proc.returncode}")

        if stderr_out.strip():
            print(f"{tag} STDERR: {stderr_out[:200]}", file=sys.stderr)

        return proc.returncode, elapsed, lines_out

    except Exception as e:
        print(f"{tag} Erro: {e}", file=sys.stderr)
        return 1, 0, 0


# ─────────────────────────────────────────────────────────────────────────────
# MODO 4: CHUNK + ANALYZE (pipeline completo)
# ─────────────────────────────────────────────────────────────────────────────

def _analyze_chunk_in_process(chunk_path: str, mode: str, level: str, glossary_path: str):
    """
    Analisa um chunk chamando as funções de analyzer.py diretamente no mesmo
    processo — sem subprocess. Substitui as duas chamadas via subprocess que
    existiam antes (uma via stream_pipe, outra via subprocess.run repetindo
    o mesmo comando só para capturar o JSON).
    """
    with open(chunk_path, "r", encoding="utf-8") as f:
        text = f.read()

    if mode == "passive":
        results = analyzer.detect_passive(text)
        return {"total": len(results), "ocorrencias": results}
    elif mode == "readability":
        return analyzer.readability_report(text, level)
    elif mode == "jargon":
        with open(glossary_path, "r", encoding="utf-8") as f:
            glossary = json.load(f)
        results = analyzer.detect_jargon(text, glossary)
        return {"total_sem_definicao": len(results), "termos": results}
    elif mode == "numbering":
        issues = analyzer.numbering_report(text)
        return {"total_inconsistencias": len(issues), "problemas": issues}
    return {}


def chunk_and_analyze(input_path: str, mode: str, level: str, chunk_size: int, overlap: int):
    """
    Pipeline completo: chunk → analyzer em cada chunk (in-process) → consolida.
    """
    out_dir = f"/tmp/editora_chunks_{Path(input_path).stem}"

    print(f"[PIPELINE] Arquivo: {input_path}")
    print(f"[PIPELINE] Modo de análise: {mode}")
    print(f"[PIPELINE] Chunk size: {chunk_size} palavras | Overlap: {overlap} palavras")
    print()

    # Step 1: Chunking
    print("═" * 60)
    print("FASE 1 — CHUNKING")
    print("═" * 60)
    manifest = chunk_file(input_path, chunk_size, overlap, out_dir)

    # Step 2: Analyzer em cada chunk (in-process, sem subir um Python por chunk)
    print()
    print("═" * 60)
    print(f"FASE 2 — ANÁLISE ({mode.upper()}) POR CHUNK")
    print("═" * 60)

    glossary_path = str(PROJECT_ROOT / "data/glossary.json")
    all_results = []
    total_start = time.time()

    for chunk in manifest["chunks"]:
        chunk_start = time.time()
        chunk_result = _analyze_chunk_in_process(chunk["file"], mode, level, glossary_path)
        elapsed = time.time() - chunk_start

        chunk_result["_chunk"] = chunk["index"]
        chunk_result["_words"] = chunk["words"]
        chunk_result["_elapsed"] = round(elapsed, 4)
        all_results.append(chunk_result)

        print(f"[chunk_{chunk['index']:03d}] {chunk['words']} palavras processadas em {elapsed:.4f}s")

    total_elapsed = time.time() - total_start

    # Step 3: Consolidação
    print()
    print("═" * 60)
    print("FASE 3 — CONSOLIDAÇÃO DOS RESULTADOS")
    print("═" * 60)
    print()
    consolidate_results(all_results, mode, manifest, total_elapsed)


def consolidate_results(results: list, mode: str, manifest: dict, total_elapsed: float):
    """Consolida resultados de múltiplos chunks em relatório unificado."""

    print(f"Arquivo original: {Path(manifest['source']).name}")
    print(f"Total de palavras: {manifest['total_words']}")
    print(f"Chunks processados: {manifest['total_chunks']}")
    print(f"Tempo total de análise: {total_elapsed:.2f}s")
    print()

    if mode == "passive":
        total = sum(r.get("total", 0) for r in results)
        all_occ = []
        for r in results:
            all_occ.extend(r.get("ocorrencias", []))
        print(f"Ocorrências de voz passiva: {total}")
        if all_occ:
            print("\nExemplos encontrados:")
            for o in all_occ[:5]:
                print(f"  Linha {o['linha']}: {o['trecho'][:80]}...")

    elif mode == "readability":
        medias = [r["media_palavras_por_frase"] for r in results if "media_palavras_por_frase" in r]
        fleschs = [r["flesch"] for r in results if "flesch" in r]
        if medias:
            avg_media = round(sum(medias) / len(medias), 1)
            avg_flesch = round(sum(fleschs) / len(fleschs), 1)
            classificacoes = [r.get("classificacao", "") for r in results]
            mais_comum = max(set(classificacoes), key=classificacoes.count)
            print(f"Média de palavras/frase (agregada): {avg_media}")
            print(f"Índice Flesch médio: {avg_flesch}")
            print(f"Classificação predominante: {mais_comum}")

            total_longas = sum(r.get("frases_acima_limite", 0) for r in results)
            print(f"Total de frases acima do limite: {total_longas}")

    elif mode == "jargon":
        all_terms = set()
        for r in results:
            all_terms.update(r.get("termos", []))
        print(f"Jargões sem definição (únicos): {len(all_terms)}")
        if all_terms:
            print(f"Termos: {', '.join(sorted(all_terms))}")

    elif mode == "numbering":
        total = sum(r.get("total_inconsistencias", 0) for r in results)
        print(f"Inconsistências de numeração: {total}")

    print()
    print("[PIPELINE] Análise por chunks concluída.")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Streamer da Editora Ebook v2 — Chunk & Streaming",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # chunk-file
    p1 = sub.add_parser("chunk-file", help="Dividir arquivo .md em chunks")
    p1.add_argument("--input", required=True)
    p1.add_argument("--size", type=int, default=300, help="Palavras por chunk (padrão: 300)")
    p1.add_argument("--overlap", type=int, default=50, help="Palavras de overlap (padrão: 50)")
    p1.add_argument("--output-dir", default="/tmp/editora_chunks")

    # stream-pipe
    p3 = sub.add_parser("stream-pipe", help="Executar script com output em streaming")
    p3.add_argument("--command", dest="command_str", required=True, help="Ex: 'analyzer.py --text cap.md --mode passive'")
    p3.add_argument("--label", default="")

    # chunk-and-analyze (pipeline completo)
    p4 = sub.add_parser("chunk-analyze", help="Pipeline completo: chunk + análise por chunks")
    p4.add_argument("--input", required=True)
    p4.add_argument("--mode", choices=["passive", "readability", "jargon", "numbering"],
                    default="readability")
    p4.add_argument("--level", default="intermediario")
    p4.add_argument("--size", type=int, default=300)
    p4.add_argument("--overlap", type=int, default=50)

    args = parser.parse_args()

    if args.command == "chunk-file":
        chunk_file(args.input, args.size, args.overlap, args.output_dir)
    elif args.command == "stream-pipe":
        stream_pipe(args.command_str, args.label)
    elif args.command == "chunk-analyze":
        chunk_and_analyze(args.input, args.mode, args.level, args.size, args.overlap)


if __name__ == "__main__":
    main()
