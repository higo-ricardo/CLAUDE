# 01 — Definição do Projeto

**Agente**: ORQUESTRADOR + ARQUITETO  
**Estágio**: M1

---

## Objetivo
Coletar todas as informações necessárias para iniciar a produção do ebook com
clareza de propósito, público e escopo.

---

## Checklist de Briefing

Colete **todas** as informações abaixo antes de avançar:

### Identidade do Projeto
- [ ] **Título provisório** (pode ser alterado depois)
- [ ] **Subtítulo** (opcional, mas recomendado para não-ficção)
- [ ] **Gênero** — ex: autoajuda, negócios, ficção científica, técnico, educacional, receitas...
- [ ] **Subgênero / nicho** — ex: produtividade para mães, romance distópico YA, Python para iniciantes

### Público-Alvo
- [ ] **Perfil demográfico** — idade, escolaridade, profissão
- [ ] **Nível de conhecimento** no tema — leigo / intermediário / avançado / especialista
- [ ] **Dores e desejos** do leitor — o que ele quer resolver ou conquistar?
- [ ] **Onde ele lê** — celular, e-reader Kindle, tablet, desktop?

### Proposta de Valor
- [ ] **Transformação prometida** — qual mudança o leitor terá depois de ler?
- [ ] **Diferencial** — o que torna este ebook único em relação a outros sobre o tema?
- [ ] **Tom e voz** — formal, informal, inspirador, técnico, narrativo, didático?

### Escopo
- [ ] **Número estimado de capítulos** (ou deixar que o ARQUITETO sugira)
- [ ] **Tamanho alvo** — curto (10-30p) / médio (30-80p) / longo (80p+)
- [ ] **Material de referência** — o usuário tem textos, notas, PDFs, links para incorporar?
- [ ] **Deadline** — há prazo de entrega?

### Distribuição
- [ ] **Canal de publicação** — Amazon KDP, Hotmart, Eduzz, site próprio, gratuito?
- [ ] **Formato de saída** — EPUB, PDF, DOCX, Markdown, HTML?
- [ ] **Necessidade de capa?** — gerar prompt de imagem para IA de geração visual

---

## Template de Coleta (use em forma de perguntas)

Se o usuário não forneceu todas as informações, faça as perguntas de forma
conversacional — **não em formulário**. Priorize:

1. Tema + gênero (obrigatório)
2. Público + nível (obrigatório)
3. Tom + voz (obrigatório)
4. Tamanho + formato (importante)
5. Demais campos (complementar)

---

## Output Esperado de M1

Ao concluir o briefing, produza um **Documento de Projeto v1.0** com:
gênero, público-alvo, nível de linguagem, tom e voz, transformação
prometida, diferencial, tamanho estimado (capítulos/páginas), formato
de saída, canal de publicação, 10-15 palavras-chave temáticas e uma
persona do leitor (3-5 linhas).

Após aprovação do usuário, avance para `references/04-estrutura-organizacao.md`.

---

## Funcionalidades Extras

**Geração de Persona Automática** — se o usuário fornecer só tema e
público, gerar uma persona fictícia detalhada para guiar decisões
editoriais subsequentes.

**Análise de Concorrência** (com busca web) — se o canal for KDP ou
similar: buscar os 5 títulos mais vendidos no nicho, identificar gaps,
sugerir ângulos diferenciados.

**Gerador de Títulos (ToT)** — 9 opções (3 por abordagem): Benefício
(foco no resultado do leitor), Curiosidade (desperta interesse
imediato), Autoridade (posiciona como referência).
