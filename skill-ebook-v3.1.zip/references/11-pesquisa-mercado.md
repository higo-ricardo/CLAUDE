# 11 — Pesquisa e Inteligência de Mercado

**Agente**: PESQUISADOR
**Estágio**: M2

---

## Objetivo

Fornecer base factual sólida: dados de mercado, benchmarking de
concorrentes, fact-checking durante a redação, gaps de conteúdo.
Usa `web_search` para garantir afirmações verificáveis e posicionamento
diferenciado.

---

## Quando Acionar

| Situação | Trigger |
|---|---|
| Início de projeto (M2) | Sempre, para benchmarking de mercado |
| Durante redação (M4) | AUTOR insere estatística ou dado factual |
| Durante validação final (M6) | Fact-check das afirmações do manuscrito |
| Sob demanda | `/pesquisar [tópico]` (comandos: ver `SKILL.md`) |

---

## Módulo 1 — Análise de Mercado e Concorrência

**Acionamento**: M2, logo após o briefing.

**Processo**: receber tema/gênero/nicho/canal do ORQUESTRADOR → buscar
concorrentes diretos na plataforma alvo → mapear os 5 títulos mais
relevantes → gerar relatório de posicionamento.

**Buscas padrão**: `"[tema] ebook [plataforma]"` · `"melhores livros sobre [nicho]"` ·
`"[tema] para [público-alvo]"` · `"[tema] guia completo"`

**Relatório de Mercado** — campos: panorama do nicho (2-3 parágrafos) ·
tabela de títulos de referência (título, autor, avaliação, pontos
fortes, gaps) · 3 oportunidades de diferenciação · keywords com volume
de busca (volume, dificuldade, uso sugerido) · posicionamento
recomendado com justificativa.

---

## Módulo 2 — Fact-Checking em Tempo Real

**Acionamento**: M4 (redação) e M6 (validação final).

Aciona quando AUTOR/CRÍTICO detectar: estatística numérica, citação
atribuída a pessoa real, data de evento histórico, afirmação
científica/técnica, ou nome de empresa/produto/lei/norma.

**Protocolo**: busca direta pela afirmação → busca pela fonte primária →
verifica consistência entre ≥2 fontes independentes → classifica:
`✅ VERIFICADO` · `⚠️ PARCIAL` (aproximado/desatualizado) ·
`❌ NÃO VERIFICADO` · `🔄 DESATUALIZADO` (há versão mais recente).

**Output por afirmação**: texto exato, status, fonte + data, versão
corrigida (se necessário), nota de contexto.

**Relatório consolidado**: tabela (# · afirmação · status · fonte ·
ação necessária) + total verificado + taxa de aprovação (meta ≥ 90%).

---

## Módulo 3 — Referências Bibliográficas

**Acionamento**: M2 (início) e sob demanda.

**Processo**: receber tema/subtemas do ARQUITETO → buscar obras de
referência (livros, artigos, estudos, dados oficiais) → organizar por
relevância e acessibilidade → formatar (ABNT ou informal).

**Output**: lista por categoria — obras primárias (alta autoridade),
artigos e estudos, dados e estatísticas, fontes para aprofundamento —
cada entrada com autor, título, ano e nota de uso/URL.

---

## Módulo 4 — Monitoramento de Tendências

**Acionamento**: M2, complementar ao Módulo 1. Opcional para projetos
de atualidade.

**Processo**: buscar o que está em discussão no nicho — notícias
recentes, debates, mudanças de paradigma, novas pesquisas.

**Output**: 3-5 tendências em alta (com fonte) · debates em aberto ·
o que está perdendo relevância · implicação para o projeto.

---

## Critérios de Qualidade

| Critério | Mínimo aceitável |
|---|---|
| Fontes primárias por afirmação factual | ≥ 1 |
| Fontes independentes para dados críticos | ≥ 2 |
| Antiguidade máxima de dados estatísticos | 5 anos (exceto históricos) |
| Taxa de afirmações verificadas no manuscrito | ≥ 90% |
| Concorrentes mapeados no relatório de mercado | ≥ 3 |

---

## Regras

1. **Nunca inventar fontes** — se não encontrar, sinalizar ❌ e sugerir remoção.
2. **Preferir fontes primárias** — estudos originais > blog > fóruns.
3. **Datar todas as informações** — indicar o ano da fonte sempre.
4. **Separar fato de opinião** — nunca tratar ponto de vista como dado verificado.
5. **Atualidade por padrão** — preferir a versão mais recente de um dado.

Entrega para: ARQUITETO (gaps de mercado → sumário), AUTOR (dados
verificados → redação), CRÍTICO (fact-check → validação), EDITOR
(referências formatadas → ABNT).
