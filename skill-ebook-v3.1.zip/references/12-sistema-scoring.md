# 12 — Sistema de Scoring

**Agente**: ORQUESTRADOR (coordena) + REVISOR/CRÍTICO (avaliam seções)
**Estágio**: M4, M6

---

## Regra fundamental

**A LLM avalia. O script calcula.**
REVISOR e CRÍTICO atribuem notas brutas S1–S5 juntos — AUTOR não se
autoavalia. O `scorer.py` faz a média ponderada, compara com o limiar
do gate e gera o scorecard formatado. Só existem dois gates de score
no pipeline: M4 (rascunho aprovado, fecha redação+revisão) e M6
(pronto pra publicar, fecha copywriting+validação final).

```bash
python scripts/scorer.py \
  --s1 [nota] --s2 [nota] --s3 [nota] --s4 [nota] --s5 [nota] \
  --stage [M4|M6] \
  --chapter "[nome]" --version [vX.Y]
```

---

## O que cada seção avalia (para o agente atribuir a nota)

| Seção | Peso | Avalie |
|---|---|---|
| **S1 — Gancho** | 20% | Impacto emocional/cognitivo da abertura; curiosidade gerada |
| **S2 — Desenvolvimento** | 35% | Clareza, suporte a afirmações, densidade adequada ao nível |
| **S3 — Público** | 20% | Tom correto, vocabulário no nível, analogias presentes |
| **S4 — Integridade Factual** | 15% | Afirmações verificáveis, absolutas justificadas |
| **S5 — Fechamento** | 10% | Síntese presente, transição para próximo capítulo |

Escala: **0 a 10** por seção, uma casa decimal.

---

## Limiares por gate (enforçados pelo scorer.py)

| Gate | Limiar | O que cobre | Consequência se não atingido |
|---|---|---|---|
| M4 — Rascunho aprovado | 7.0 | AUTOR (redação) + REVISOR/CRÍTICO (revisão), avaliados juntos | Seção mais fraca indica quem retrabalha: AUTOR/REVISOR se S2/S3/S4, CRÍTICO revalida se S4 |
| M6 — Pronto pra publicar | 8.0 | COPYWRITER (M5, sem gate próprio) + validação final do CRÍTICO | Seção mais fraca indica quem retrabalha: COPYWRITER se S1/S5, AUTOR/REVISOR se S2/S3/S4 |

M5 (Copywriting) não tem limiar independente — o COPYWRITER atua entre
os dois gates e sua qualidade só é medida no score de M6.

---

## Score consolidado do projeto

```bash
# Tabela de todos os capítulos com status
python scripts/scorer.py --consolidate

# Scorecard detalhado de um capítulo específico
python scripts/scorer.py --scorecard "Cap. 1"
```

---

## Regras

1. Nunca calcule score manualmente — use sempre `scorer.py`.
2. Só REVISOR/CRÍTICO pontuam — não há auto-avaliação do AUTOR para prevalecer sobre.
3. Toda nota abaixo de 7.0 em qualquer seção exige comentário justificando.
4. Score não arredondado — usar uma casa decimal.
