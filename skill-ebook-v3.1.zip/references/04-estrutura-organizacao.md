# 04 — Estrutura e Organização

**Agente**: ARQUITETO
**Estágio**: M3

---

## Objetivo
Projetar a arquitetura completa do ebook: sumário, progressão temática,
arcos narrativos (ficção) ou lógica argumentativa (não-ficção).

---

## Modelos de Estrutura por Gênero

### Não-ficção / Autoajuda / Negócios

**Problema-Solução** (clássico)
```
Introdução — A promessa e o leitor ideal
Parte 1: O Problema (1-3 cap.) — custo de não resolver, por que soluções comuns falham
Parte 2: O Framework (3-5 cap.) — 1 pilar da solução por capítulo
Parte 3: A Implementação (2-3 cap.) — passo a passo, obstáculos e superação
Conclusão — A transformação e os próximos passos
Bônus / Apêndices (opcional)
```

**Jornada do Herói** (autoajuda narrativo)
```
Ato 1: O Mundo Comum → Ato 2: O Chamado → Ato 3: A Provação → Ato 4: O Retorno
```

**Pilares** (livros técnicos)
```
Introdução → Fundamentos (1-2) → Pilar 1 (3-4) → Pilar 2 (5-6) → Pilar 3 (7-8) → Integração (9) → Conclusão + Referências
```

### Ficção

**Três Atos**
```
Ato 1 (25%): Apresentação — mundo, protagonista, incidente incitante
Ato 2a (25%): Complicação — protagonista tenta resolver, falha
Ponto de Virada Central (1 cena)
Ato 2b (25%): Crise — tudo piora, protagonista muda
Ato 3 (25%): Clímax + Resolução
```

**Save the Cat** (15 batidas)
```
1.Imagem de abertura 2.Tema 3.Setup 4.Catalisador 5.Debate 6.Break into Two
7.B Story 8.Fun and Games 9.Midpoint 10.Bad Guys Close In 11.All Is Lost
12.Dark Night of the Soul 13.Break into Three 14.Finale 15.Final Image
```

---

## Geração de Sumário (output padrão)

Estrutura: Introdução (propósito, público, como usar) → Partes numeradas,
cada uma com capítulos (título, objetivo, tópicos, desfecho esperado) →
Conclusão (síntese, próximos passos, CTA) → Apêndices, se houver.

---

## Princípios de Arquitetura Editorial

1. **Progressão**: cada capítulo constrói sobre o anterior
2. **Proporção**: nenhuma parte > 40% do total
3. **Equilíbrio teoria/prática**: máx. 60% teoria em livros práticos
4. **Ganchos entre capítulos**: antecipação ao final de cada um
5. **Densidade crescente**: começar acessível, aprofundar gradualmente
6. **Fechamento satisfatório**: conclusão responde às promessas da introdução

---

## Funcionalidades Extras

**Reorganizador de Conteúdo** — dado um sumário/lista desordenada: identifica
agrupamentos naturais, detecta lacunas, sugere nova ordem com justificativa,
identifica conteúdo redundante a mesclar.

**Divisão Automática de Texto Longo** — dado texto contínuo sem capítulos:
detecta mudanças de tema, propõe divisão com títulos, gera sumário retroativo.

**Análise de Gap** e **Calculadora de Equilíbrio** — usar `analyzer.py --mode gap`
e `--mode balance` (ver `SKILL.md`); a LLM interpreta o resultado, não recalcula.
