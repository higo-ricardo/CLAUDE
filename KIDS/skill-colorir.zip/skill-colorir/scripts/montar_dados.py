#!/usr/bin/env python3
"""
Monta o dados_brutos.json final combinando a BÍBLIA do livro (fatos fixos e
já aprovados: protagonista, coadjuvante, estilo, moldura, formato etc.) com
a lista de páginas de uma rodada de geração (a primeira, ou uma extensão de
um livro já existente).

Existe pra que o protagonista/estilo/moldura NUNCA precisem ser reconstruídos
de memória a partir da conversa — eles são lidos de um arquivo, sempre.

Uso:
    python3 montar_dados.py bible.json paginas.json -o dados_brutos.json

Formato de bible.json: os mesmos campos de dados_brutos.json, exceto que
cada versão em "versoes" NÃO tem "paginas" (isso é o que este script anexa).

Formato de paginas.json — um dict mapeando o título de cada versão à lista
de páginas daquela rodada:
{
  "Título da versão 1": [ {"atividade": "...", "perspectiva": "...", "cena": "..."}, ... ],
  "Título da versão 2": [ ... ]
}
"""

import argparse
import json
import sys


def montar(bible: dict, paginas_por_versao: dict) -> dict:
    if "versoes" not in bible:
        print("❌ bible.json não tem o campo 'versoes'")
        sys.exit(1)

    dados = {k: v for k, v in bible.items() if k != "versoes"}
    dados["versoes"] = []

    for v in bible["versoes"]:
        titulo = v.get("titulo")
        paginas = paginas_por_versao.get(titulo)
        if paginas is None:
            print(f"❌ Não há páginas definidas para a versão '{titulo}' em paginas.json")
            print(f"   Títulos disponíveis em paginas.json: {list(paginas_por_versao.keys())}")
            sys.exit(1)
        nova_versao = dict(v)
        nova_versao["paginas"] = paginas
        dados["versoes"].append(nova_versao)

    return dados


def main():
    parser = argparse.ArgumentParser(description="Monta dados_brutos.json a partir da bíblia + páginas")
    parser.add_argument("bible_json", help="Caminho para bible.json (fatos fixos do livro)")
    parser.add_argument("paginas_json", help="Caminho para paginas.json (páginas desta rodada)")
    parser.add_argument("-o", "--saida", required=True, help="Caminho do dados_brutos.json de saída")
    args = parser.parse_args()

    with open(args.bible_json, "r", encoding="utf-8") as f:
        bible = json.load(f)
    with open(args.paginas_json, "r", encoding="utf-8") as f:
        paginas_por_versao = json.load(f)

    dados = montar(bible, paginas_por_versao)

    with open(args.saida, "w", encoding="utf-8") as f:
        json.dump(dados, f, ensure_ascii=False, indent=2)
    print(f"✅ dados_brutos montado em {args.saida}")


if __name__ == "__main__":
    main()
