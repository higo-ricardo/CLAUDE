#!/usr/bin/env python3
"""
Validador de prompts do livro de colorir.

Confere, para um pacote de prompts gerado (JSON), que:
  - cada versão tem a quantidade de páginas esperada (se informada)
  - cada prompt (capa e páginas) contém os termos técnicos obrigatórios
  - não há combinação (atividade, perspectiva) duplicada dentro da mesma versão

Uso:
    python3 validar_prompts.py dados.json [--paginas-esperadas N] [--historico anterior.json]

Com --historico, as combinações atividade+perspectiva do arquivo anterior também
entram na checagem de duplicatas (por título de versão), para quando o usuário
pedir para ESTENDER um livro já gerado com páginas novas.

Formato esperado do JSON:
{
  "versoes": [
    {
      "titulo": "...",
      "capa_prompt": "...",
      "paginas": [
        {"prompt": "...", "atividade": "...", "perspectiva": "..."},
        ...
      ]
    },
    ...
  ]
}

Saída: imprime um relatório e termina com exit code 0 se tudo estiver ok,
ou 1 se houver algum problema (para ser fácil de checar em um script maior).
"""

import argparse
import json
import sys

TERMOS_OBRIGATORIOS = [
    "300 DPI",
    "fundo branco puro",
]

# Pelo menos um destes precisa aparecer (variações aceitáveis da mesma exigência)
TERMOS_PB_ALTERNATIVOS = [
    "preto e branco",
    "preto e branco.",
]


def checar_termos(prompt: str, contexto: str, problemas: list):
    texto = prompt.lower()
    for termo in TERMOS_OBRIGATORIOS:
        if termo.lower() not in texto:
            problemas.append(f"{contexto}: falta o termo obrigatório '{termo}'")
    if not any(t.lower() in texto for t in TERMOS_PB_ALTERNATIVOS):
        problemas.append(f"{contexto}: falta a exigência de 'somente em preto e branco'")


def carregar_historico(caminho: str | None) -> dict:
    """Devolve {titulo_versao: {(atividade, perspectiva), ...}} de um pacote anterior."""
    if not caminho:
        return {}
    with open(caminho, "r", encoding="utf-8") as f:
        dados = json.load(f)
    historico = {}
    for v in dados.get("versoes", []):
        usadas = set()
        for pagina in v.get("paginas", []):
            atividade = pagina.get("atividade", "").strip().lower()
            perspectiva = pagina.get("perspectiva", "").strip().lower()
            if atividade and perspectiva:
                usadas.add((atividade, perspectiva))
        historico[v.get("titulo", "(sem título)")] = usadas
    return historico


def validar(dados: dict, paginas_esperadas: int | None, historico: dict | None = None) -> list:
    problemas = []
    historico = historico or {}
    versoes = dados.get("versoes", [])
    if not versoes:
        problemas.append("Nenhuma versão encontrada no JSON.")
        return problemas

    for v in versoes:
        titulo = v.get("titulo", "(sem título)")
        paginas = v.get("paginas", [])

        if paginas_esperadas is not None and len(paginas) != paginas_esperadas:
            problemas.append(
                f"Versão '{titulo}': tem {len(paginas)} páginas, esperado {paginas_esperadas}"
            )

        capa_prompt = v.get("capa_prompt", "")
        if not capa_prompt:
            problemas.append(f"Versão '{titulo}': prompt de capa ausente")
        else:
            checar_termos(capa_prompt, f"Versão '{titulo}' (capa)", problemas)

        combinacoes_anteriores = historico.get(titulo, set())
        combinacoes_usadas = set()
        for i, pagina in enumerate(paginas, start=1):
            prompt = pagina.get("prompt", "")
            if not prompt:
                problemas.append(f"Versão '{titulo}', página {i}: prompt ausente")
                continue
            checar_termos(prompt, f"Versão '{titulo}', página {i}", problemas)

            atividade = pagina.get("atividade", "").strip().lower()
            perspectiva = pagina.get("perspectiva", "").strip().lower()
            if atividade and perspectiva:
                chave = (atividade, perspectiva)
                if chave in combinacoes_usadas:
                    problemas.append(
                        f"Versão '{titulo}', página {i}: combinação atividade+perspectiva "
                        f"repetida ({atividade} / {perspectiva})"
                    )
                elif chave in combinacoes_anteriores:
                    problemas.append(
                        f"Versão '{titulo}', página {i}: combinação atividade+perspectiva "
                        f"já usada no livro anterior ({atividade} / {perspectiva})"
                    )
                combinacoes_usadas.add(chave)

    return problemas


def main():
    parser = argparse.ArgumentParser(description="Valida prompts do livro de colorir")
    parser.add_argument("arquivo_json", help="Caminho para o JSON com os prompts gerados")
    parser.add_argument(
        "--paginas-esperadas",
        type=int,
        default=None,
        help="Quantidade de páginas internas esperada por versão",
    )
    parser.add_argument(
        "--historico",
        default=None,
        help="JSON renderizado de um livro anterior, para evitar repetir combinações ao estender",
    )
    args = parser.parse_args()

    with open(args.arquivo_json, "r", encoding="utf-8") as f:
        dados = json.load(f)

    historico = carregar_historico(args.historico)
    problemas = validar(dados, args.paginas_esperadas, historico)

    if problemas:
        print(f"❌ {len(problemas)} problema(s) encontrado(s):\n")
        for p in problemas:
            print(f"  - {p}")
        sys.exit(1)
    else:
        print("✅ Todos os prompts passaram na validação.")
        sys.exit(0)


if __name__ == "__main__":
    main()
