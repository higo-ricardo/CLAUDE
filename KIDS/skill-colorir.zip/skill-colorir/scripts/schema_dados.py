"""
Validação leve de schema para o JSON bruto de entrada do renderizador
(dados_brutos.json). Propositalmente sem depender de bibliotecas externas
(ex. jsonschema) — só Python puro — para não exigir mais uma instalação
num script que já roda em cima de Jinja2 e Pillow em ambientes variados.

Produz mensagens de erro específicas por campo, por versão e por página,
em vez de deixar um KeyError genérico do Jinja2 estourar no meio da
renderização sem dizer qual campo faltou nem onde.
"""

CAMPOS_RAIZ_OBRIGATORIOS = {
    "faixa_etaria": str,
    "faixa_etaria_min": int,
    "estilo": str,
    "ferramenta": str,
    "formato": str,
    "usar_moldura": bool,
}

CAMPOS_VERSAO_OBRIGATORIOS = {
    "titulo": str,
    "protagonista": str,
    "protagonista_resumido": str,
    "cena_capa": str,
}

CAMPOS_PAGINA_OBRIGATORIOS = {
    "atividade": str,
    "perspectiva": str,
    "cena": str,
}


def validar_schema_bruto(dados: dict) -> list:
    """Devolve uma lista de strings com os problemas de schema encontrados.
    Lista vazia = dados válidos o suficiente para tentar renderizar."""
    problemas = []

    if not isinstance(dados, dict):
        return ["o JSON bruto precisa ser um objeto (dict) no nível raiz"]

    for campo, tipo in CAMPOS_RAIZ_OBRIGATORIOS.items():
        if campo not in dados:
            problemas.append(f"campo raiz '{campo}' ausente")
        elif not isinstance(dados[campo], tipo):
            problemas.append(
                f"campo raiz '{campo}' deveria ser do tipo {tipo.__name__}, "
                f"veio {type(dados[campo]).__name__}"
            )

    versoes = dados.get("versoes")
    if not isinstance(versoes, list) or not versoes:
        problemas.append("campo raiz 'versoes' ausente, vazio ou não é uma lista")
        return problemas  # sem versões válidas, não dá pra checar mais nada

    usar_moldura = dados.get("usar_moldura")

    for i, v in enumerate(versoes, start=1):
        if not isinstance(v, dict):
            problemas.append(f"versão {i}: não é um objeto JSON válido")
            continue

        titulo = v.get("titulo", f"(versão {i} sem título)")

        for campo, tipo in CAMPOS_VERSAO_OBRIGATORIOS.items():
            if campo not in v:
                problemas.append(f"versão {i} ('{titulo}'): falta o campo '{campo}'")
            elif not isinstance(v[campo], tipo):
                problemas.append(
                    f"versão {i} ('{titulo}'): campo '{campo}' deveria ser "
                    f"{tipo.__name__}, veio {type(v[campo]).__name__}"
                )

        if usar_moldura is True and not v.get("moldura_desc"):
            problemas.append(
                f"versão {i} ('{titulo}'): usar_moldura=true mas falta 'moldura_desc'"
            )

        paginas = v.get("paginas")
        if not isinstance(paginas, list) or not paginas:
            problemas.append(f"versão {i} ('{titulo}'): 'paginas' ausente, vazia ou não é uma lista")
            continue

        for j, p in enumerate(paginas, start=1):
            if not isinstance(p, dict):
                problemas.append(f"versão {i} ('{titulo}'), página {j}: não é um objeto JSON válido")
                continue
            for campo, tipo in CAMPOS_PAGINA_OBRIGATORIOS.items():
                if campo not in p:
                    problemas.append(f"versão {i} ('{titulo}'), página {j}: falta o campo '{campo}'")
                elif not isinstance(p[campo], tipo):
                    problemas.append(
                        f"versão {i} ('{titulo}'), página {j}: campo '{campo}' deveria ser "
                        f"{tipo.__name__}, veio {type(p[campo]).__name__}"
                    )

    return problemas
