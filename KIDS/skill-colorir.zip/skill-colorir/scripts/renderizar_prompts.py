#!/usr/bin/env python3
"""
Renderizador de prompts do livro de colorir (via Jinja2).

Lê um JSON "bruto" com os dados criativos (protagonista, cenas, atividades,
estilo, moldura etc.) e devolve um JSON "renderizado" com o texto final de
cada prompt, montado a partir dos templates em templates/*.j2 — garantindo
que toda exigência técnica (300 DPI, fundo branco puro, margens, idioma,
proporção) apareça sempre, sem depender de copiar o gabarito à mão.

Também aplica a TRAVA DE COMPATIBILIDADE estilo x faixa etária: se o estilo
escolhido pede uma idade mínima maior que a faixa etária informada, o script
para com um erro claro em vez de gerar prompts inadequados para a idade.

Uso:
    python3 renderizar_prompts.py dados_brutos.json -o dados_renderizados.json

Formato esperado do JSON de entrada:
{
  "faixa_etaria": "2 a 4 anos",
  "faixa_etaria_min": 2,
  "estilo": "chibi",
  "ferramenta": "Gemini / Nano Banana",
  "formato": "Quadrado 8.5x8.5 (KDP)",
  "usar_moldura": true,
  "versoes": [
    {
      "titulo": "...",
      "protagonista": "descrição completa do protagonista",
      "protagonista_resumido": "versão curta do protagonista, para repetir nas páginas",
      "cena_capa": "descrição da pose/cena da capa",
      "moldura_desc": "descrição curta da moldura temática (só usada se usar_moldura=true)",
      "coadjuvante": "nome + 1-2 traços do coadjuvante fixo (só para versões com narrativa; use dentro do texto de 'cena' sempre que o beat mencionar um amigo, apenas para documentação/consistência sua — não é lido pelo template)",
      "paginas": [
        {"atividade": "...", "perspectiva": "...", "cena": "descrição da cena da página"}
      ]
    }
  ]
}

O JSON de saída segue o formato esperado por validar_prompts.py.
"""

import argparse
import json
import sys
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from schema_dados import validar_schema_bruto

SCRIPT_DIR = Path(__file__).resolve().parent
TEMPLATES_DIR = SCRIPT_DIR.parent / "templates"
ESTILOS_PATH = SCRIPT_DIR / "estilos.json"
ESPESSURAS_PATH = SCRIPT_DIR / "espessuras.json"

FERRAMENTAS_INGLES = {"Midjourney", "DALL·E / ChatGPT Image"}

# Faixas de margem interna (gutter) por número total de páginas do livro,
# seguindo a prática comum de plataformas de auto-publicação (ex. KDP):
# quanto mais páginas, maior a margem interna precisa ser para a encadernação.
FAIXAS_MARGEM = [
    (150, 0.375),
    (300, 0.5),
    (500, 0.625),
    (700, 0.75),
    (float("inf"), 0.875),
]


def carregar_estilos():
    with open(ESTILOS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def carregar_espessuras():
    with open(ESPESSURAS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def calcular_espessura_clause(faixa_etaria_min: int, espessuras: list, idioma: str) -> str:
    for e in espessuras:
        if e["idade_min"] <= faixa_etaria_min <= e["idade_max"]:
            return e["clause_en"] if idioma == "en" else e["clause_pt"]
    # fallback de segurança — não deve acontecer com espessuras.json completo
    return espessuras[-1]["clause_en"] if idioma == "en" else espessuras[-1]["clause_pt"]


def calcular_margem_texto(paginas_internas: int) -> str:
    paginas_totais = paginas_internas + 2  # aproximação: capa + contracapa
    for limite, polegadas in FAIXAS_MARGEM:
        if paginas_totais <= limite:
            return f'{polegadas}"'
    return f'{FAIXAS_MARGEM[-1][1]}"'


def checar_trava_idade(estilo_id: str, faixa_etaria_min: int, estilos: dict):
    estilo = estilos.get(estilo_id)
    if estilo is None:
        print(f"❌ Estilo '{estilo_id}' não existe. Opções: {', '.join(estilos)}")
        sys.exit(1)

    idade_minima = estilo["idade_minima"]
    if faixa_etaria_min < idade_minima:
        print(
            f"❌ Trava de compatibilidade: o estilo '{estilo['nome']}' é recomendado "
            f"a partir de {idade_minima} anos, mas a faixa etária informada começa em "
            f"{faixa_etaria_min} anos.\n"
            f"   Ajuste a faixa etária para {idade_minima}+ anos, ou escolha um estilo "
            f"sem restrição de idade (clássico, chibi/kawaii, doodle, ligne claire)."
        )
        sys.exit(1)


def calcular_idioma_e_proporcao(ferramenta: str, formato: str):
    """Devolve (idioma, proporcao_texto, flag_capa, flag_pagina).

    As flags de capa e de página interna são diferentes de propósito: a capa
    PRECISA de texto (o título), então o negative prompt dela não pode excluir
    texto — só cor, sombreamento e marca d'água. As páginas internas não devem
    ter texto nenhum, então excluem texto também.
    """
    idioma = "en" if ferramenta in FERRAMENTAS_INGLES else "pt"
    quadrado = "quadrad" in formato.lower()

    if idioma == "pt":
        proporcao_texto = "proporção quadrada" if quadrado else "proporção retrato"
        return idioma, proporcao_texto, None, None

    proporcao_texto = "square proportion" if quadrado else "portrait proportion"
    if ferramenta != "Midjourney":
        return idioma, proporcao_texto, None, None

    ar = "--ar 1:1" if quadrado else "--ar 3:4"
    # Negative prompt: o Midjourney aceita exclusões explícitas, o que reduz a
    # chance de a IA colorir por conta própria ou acrescentar marca d'água.
    base_no = "color, colored, shading, grayscale, watermark, signature"
    flag_capa = f"{ar} --no {base_no}"
    flag_pagina = f"{ar} --no {base_no}, text, lettering"
    return idioma, proporcao_texto, flag_capa, flag_pagina


def renderizar(dados: dict) -> dict:
    problemas_schema = validar_schema_bruto(dados)
    if problemas_schema:
        print(f"❌ {len(problemas_schema)} problema(s) de schema no JSON bruto — corrija antes de renderizar:\n")
        for p in problemas_schema:
            print(f"  - {p}")
        sys.exit(1)

    estilos = carregar_estilos()
    espessuras = carregar_espessuras()
    estilo_id = dados["estilo"]
    faixa_etaria_min = dados["faixa_etaria_min"]

    checar_trava_idade(estilo_id, faixa_etaria_min, estilos)
    estilo = estilos[estilo_id]

    idioma, proporcao_texto, flag_capa, flag_pagina = calcular_idioma_e_proporcao(
        dados["ferramenta"], dados["formato"]
    )
    estilo_clause = estilo["clause_en"] if idioma == "en" else estilo["clause_pt"]
    espessura_clause = calcular_espessura_clause(faixa_etaria_min, espessuras, idioma)

    env = Environment(
        loader=FileSystemLoader(str(TEMPLATES_DIR)),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    tpl_capa = env.get_template(f"capa_{idioma}.md.j2")
    tpl_pagina = env.get_template(f"pagina_{idioma}.md.j2")

    usar_moldura = dados.get("usar_moldura", False)
    faixa_etaria = dados["faixa_etaria"]

    saida = {"versoes": []}
    for v in dados["versoes"]:
        moldura_desc = v.get("moldura_desc") if usar_moldura else None
        margem_texto = calcular_margem_texto(len(v["paginas"]))

        capa_prompt = tpl_capa.render(
            titulo=v["titulo"],
            protagonista=v["protagonista"],
            cena_capa=v["cena_capa"],
            estilo_clause=estilo_clause,
            espessura_clause=espessura_clause,
            moldura_desc=moldura_desc,
            faixa_etaria=faixa_etaria,
            proporcao_texto=proporcao_texto,
            proporcao_flag=flag_capa,
            margem_texto=margem_texto,
        ).strip()

        paginas_renderizadas = []
        for p in v["paginas"]:
            prompt = tpl_pagina.render(
                protagonista_resumido=v["protagonista_resumido"],
                cena=p["cena"],
                perspectiva=p["perspectiva"],
                estilo_clause=estilo_clause,
                espessura_clause=espessura_clause,
                moldura_desc=moldura_desc,
                faixa_etaria=faixa_etaria,
                proporcao_texto=proporcao_texto,
                proporcao_flag=flag_pagina,
                margem_texto=margem_texto,
            ).strip()
            paginas_renderizadas.append(
                {"prompt": prompt, "atividade": p["atividade"], "perspectiva": p["perspectiva"]}
            )

        saida["versoes"].append(
            {
                "titulo": v["titulo"],
                "protagonista": v["protagonista"],
                "capa_prompt": capa_prompt,
                "paginas": paginas_renderizadas,
            }
        )

    return saida


def main():
    parser = argparse.ArgumentParser(description="Renderiza os prompts do livro de colorir via Jinja2")
    parser.add_argument("arquivo_json", help="Caminho para o JSON com os dados brutos")
    parser.add_argument("-o", "--saida", default=None, help="Caminho do JSON renderizado de saída")
    args = parser.parse_args()

    with open(args.arquivo_json, "r", encoding="utf-8") as f:
        dados = json.load(f)

    resultado = renderizar(dados)

    if args.saida:
        with open(args.saida, "w", encoding="utf-8") as f:
            json.dump(resultado, f, ensure_ascii=False, indent=2)
        print(f"✅ Prompts renderizados em: {args.saida}")
    else:
        print(json.dumps(resultado, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
