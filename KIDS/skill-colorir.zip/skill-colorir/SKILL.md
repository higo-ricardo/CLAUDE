---
name: gerador-livro-colorir
description: Gera pacotes completos de prompts de ilustração para livros de colorir infantis (capa + páginas internas), em várias versões (1 a 4, padrão 3) visualmente distintas a partir de um tema e/ou imagem de referência. Use esta skill sempre que o usuário pedir para criar, montar ou gerar um "livro de colorir", "livro para colorir", "páginas para colorir", "coloring book", ilustrações lineares para crianças colorirem, ou quando enviar uma imagem de referência pedindo variações dela em estilo de colorir. Ative também para pedidos mais vagos como "preciso de um material de colorir sobre [tema] para minha filha/aluno", "cria umas folhas de atividade para colorir", ou "faz um livrinho de desenhos pra colorir" — mesmo sem o usuário usar o termo técnico "livro de colorir". Não ativar para pedidos de gerar UMA única imagem/desenho avulso para colorir (isso não precisa do fluxo completo de 3 versões) nem para livros infantis com texto/história (não são livros de colorir).
---

# Gerador de Livro de Colorir Infantil

## O que esta skill produz

Um pacote com **N versões** (1 a 4, padrão 3) visualmente distintas de um livro de colorir infantil sobre o mesmo tema, cada uma com:
- Título, protagonista fixo (e coadjuvante fixo, se houver narrativa)
- Prompt de capa e prompts de páginas internas, prontos para uma ferramenta de geração de imagens — opcionalmente em sequência narrativa (só para temas de Animais ou Pessoas)

O entregável é um **documento com todos os prompts organizados** — não a geração das imagens em si, a menos que a sessão tenha uma ferramenta de geração de imagens disponível (ver final do Passo 8).

## Arquitetura: dados criativos (você) + renderização determinística (Jinja2)

Você decide o conteúdo criativo (tema, subtemas, protagonistas, cenas, estilo, moldura) e monta isso como um JSON de dados "brutos" (schema no topo de `scripts/renderizar_prompts.py`). O script `renderizar_prompts.py` monta o texto final de cada prompt a partir dos templates em `templates/*.j2`, garantindo que a parte técnica (300 DPI, fundo branco puro, margens, idioma, proporção) apareça em 100% dos prompts e aplicando a trava de compatibilidade estilo × faixa etária antes de gerar qualquer coisa.

Nunca escreva o texto final de um prompt à mão para o pacote entregável — monte o JSON e deixe o script renderizar. É isso que garante consistência entre um livro de 8 páginas e um de 24.

## Passo 1 — Verificar imagem de referência (opcional)

Olhe se o usuário anexou uma imagem (`/mnt/user-data/uploads`). Se houver, use-a como inspiração de tema/personagens/clima — nunca copie a arte diretamente (ver Passo 2). Se não houver, siga com o tema que o usuário descrever no Passo 3; não peça uma imagem que ele não mencionou.

## Passo 2 — Diretrizes de originalidade e direitos autorais

Valem para todo o resto do fluxo, a partir daqui:
- Toda versão é uma criação original **inspirada** pelo tema/estilo geral, nunca cópia de uma obra existente. Com imagem de referência, descreva só tema/composição/clima — nunca replique detalhes identificáveis.
- Nunca inclua personagens licenciados (Disney, Pixar, marcas de brinquedos, mascotes existentes), mesmo que a referência os contenha; ofereça um personagem original com apelo semelhante.
- Nunca ofereça ou aceite estilo artístico vinculado a uma marca, franquia ou artista específico (ex. "estilo Ghibli", "estilo Disney/Pixar", "estilo [ilustrador]") — só gêneros genéricos, como os do Passo 3. Se pedirem isso, explique que não dá pra reproduzir o estilo de uma obra/autor específico e ofereça o gênero genérico mais próximo (ex. "Ghibli" → "doodle" ou "clássico" com traços mais orgânicos).

## Passo 3 — Coletar informações essenciais

Use `ask_user_input_v0` (até 3 perguntas por chamada) em 3 chamadas curtas — pule qualquer pergunta cuja resposta o usuário já tenha dado no pedido original:

**Chamada 1 (conteúdo):** Tema (Animais, Veículos e transporte, Dinossauros, Espaço, Natureza, Contos de fadas, Esportes, Outro) · Número de versões (1–4, padrão 3) · Faixa etária (ex.: 2–4, 3–8, 6–10 anos).

**Chamada 2 (formato e estilo):** Ferramenta onde os prompts serão usados (Midjourney, DALL·E/ChatGPT Image, Gemini/Nano Banana, Outra) · Formato de impressão (Retrato A4, Retrato US Letter, Quadrado 8.5×8.5" KDP, Quadrado 8×8") · Estilo artístico — ver tabela abaixo.

**Chamada 3 (moldura, narrativa, páginas):** Moldura decorativa (sim/não) · Narrativa das páginas — **só pergunte se o tema for Animais ou Pessoas**; para qualquer outro tema, siga direto com "sem narrativa" (opções quando aplicável: sem narrativa / "Um dia na vida" / "Jornada e aventura" / "Eu descrevo os momentos") · Quantidade de páginas internas por versão.

### Estilos e idade mínima

| Estilo (id) | Idade mínima |
|---|---|
| Clássico (`classico`) | qualquer idade |
| Chibi/Kawaii (`chibi`) | qualquer idade |
| Doodle/rabisco solto (`doodle`) | qualquer idade |
| Ligne claire (`ligne_claire`) | qualquer idade |
| Papel recortado/geométrico (`papel_recortado`) | a partir de 4 anos |
| Mandala/padrões repetitivos (`mandala`) | a partir de 6 anos |

Confira a compatibilidade assim que coletar as respostas, antes do Passo 4: se a idade mínima da faixa escolhida for menor que a do estilo, avise o usuário e peça para ajustar (nova chamada de `ask_user_input_v0`). `renderizar_prompts.py` repete essa checagem no Passo 7 como segurança, mas resolver aqui evita gerar o livro inteiro numa combinação que seria barrada depois.

### Idioma e proporção por ferramenta

Calculado automaticamente por `renderizar_prompts.py` a partir de `ferramenta` e `formato` — só informe os dois campos corretamente no JSON:
- Midjourney/DALL·E/ChatGPT Image → prompts em **inglês**; Midjourney também recebe `--ar` e um negative prompt (o da capa exclui só cor/sombreamento/marca d'água, já que ela precisa do título; o das páginas internas exclui texto também).
- Gemini/Nano Banana/Outra → prompts em **português**, proporção mencionada em texto.

Se o idioma for inglês, escreva os campos criativos (`protagonista`, `cena_capa`, `cena`, `moldura_desc`) em inglês — o template só monta a estrutura ao redor, não traduz.

## Passo 4 — Definir subtemas, protagonista, coadjuvante e moldura de cada versão

As versões compartilham tema, público-alvo e estilo, mas precisam ser **claramente distintas** — varie o subtema/ambientação: "Animais" → fazenda / floresta / mar; "Veículos" → urbanos / emergência / voadores-navais.

Para cada versão, defina:
- **Protagonista fixo**: nome + 2-3 traços visuais (ex.: "Mimo, um leitãozinho rosa arredondado, com orelhas grandes caídas e rabinho enrolado"), mais uma versão resumida (`protagonista_resumido`, ex.: "Mimo, o leitãozinho") para repetir nas páginas sem inflar o prompt. Se o tema pedir humanos, o protagonista é uma criança com 2-3 traços fixos; se for veículo/animal, ele mesmo é o personagem.
- **Cena da capa** (`cena_capa`): pose/cenário central do subtema.
- **Moldura** (`moldura_desc`, só se pedida no Passo 3): 3-5 palavras do motivo decorativo coerente com o subtema (floresta → "folhinhas e galhos simples"; mar → "ondinhas e bolhinhas simples"), sempre ao redor da cena, nunca preenchendo o centro livre para colorir.
- **Coadjuvante fixo** (`coadjuvante`, só se houver narrativa): nome + 1-2 traços, mais simples que o protagonista (ex.: "Renato, um passarinho azul pequeno e atrapalhado") — é quem aparece toda vez que um beat mencionar "um amigo", pra não trocar de personagem a cada página.

**Com narrativa**, defina também a lista de *beats* (momentos) de cada versão — ver `references/arcos_narrativos.md` para os arcos "Um dia na vida" e "Jornada e aventura" e como adaptá-los ao número de páginas e ao subtema. Beats com "amigo" usam sempre o coadjuvante fixo. Se o usuário escolheu "Eu descrevo os momentos", peça a sequência a ele em texto antes de continuar.

## Passo 5 — Prévia: aprovar capas (e beats, se houver) antes de gerar tudo

Monte o JSON só com as capas (título, protagonista, `cena_capa`, moldura) e rode `renderizar_prompts.py` para obter os `capa_prompt` finais. Apresente ao usuário com os títulos — e, se houver narrativa, a lista de beats de cada versão (só os nomes dos momentos, sem prompts completos ainda). Pergunte com `ask_user_input_v0` (single_select) se pode seguir para as páginas internas.

**Assim que aprovado**, grave a **bíblia do livro** (`bible.json`): todos os campos fixos — raiz (`faixa_etaria`, `faixa_etaria_min`, `estilo`, `ferramenta`, `formato`, `usar_moldura`) e por versão (`titulo`, `protagonista`, `protagonista_resumido`, `cena_capa`, `moldura_desc`, `coadjuvante`), sem `paginas`. A partir daqui esses fatos são **canônicos**: leia sempre de `bible.json`, nunca os reconstrua de memória da conversa — nem no resto deste fluxo, nem numa extensão futura do livro, para não arriscar uma deriva silenciosa (ex. o protagonista "mudar de cor").

## Passo 6 — Definir as páginas internas de cada versão

Para cada página, defina `atividade`, `perspectiva` e `cena`.
- **Sem narrativa**: use `references/banco_variacoes.md` (banco de atividades/perspectivas/poses) e não repita a mesma combinação atividade+perspectiva dentro da versão.
- **Com narrativa**: a `atividade` vem do beat correspondente (ordem definida e aprovada nos Passos 4-5); perspectiva e pose seguem vindo de `banco_variacoes.md`, variando para não deixar a sequência repetitiva mesmo com beats diferentes.

## Passo 7 — Renderizar e validar

Monte `paginas.json` (dict título da versão → lista de páginas, schema no topo de `scripts/montar_dados.py`) e rode a cadeia completa numa única chamada de bash:

```bash
python3 scripts/montar_dados.py bible.json paginas.json -o dados_brutos.json && \
python3 scripts/renderizar_prompts.py dados_brutos.json -o dados_renderizados.json && \
python3 scripts/validar_prompts.py dados_renderizados.json --paginas-esperadas N
```

`montar_dados.py` combina bíblia + páginas novas; `renderizar_prompts.py` valida o schema do JSON bruto (erro específico por campo/versão/página em vez de um erro genérico) e só depois a trava de idade × estilo; `validar_prompts.py` confere contagem de páginas, termos técnicos obrigatórios e ausência de combinação atividade+perspectiva repetida. O `&&` interrompe a cadeia na primeira falha — corrija o apontado e rode de novo; não entregue um pacote que falhou em qualquer validação.

**Estendendo um livro já gerado** ("adiciona mais 8 páginas nessa versão"): não recomece do zero nem reconstrua protagonista/estilo de memória — use o `bible.json` daquele livro (entregue junto com o pacote original, ver Passo 8; peça ao usuário se não estiver mais disponível). Monte só o `paginas.json` novo, rode a mesma cadeia, e valide contra o livro anterior:

```bash
python3 scripts/validar_prompts.py novas_paginas_renderizadas.json --historico dados_renderizados_anterior.json
```

Isso estende a checagem de duplicatas às combinações já usadas na primeira leva.

## Passo 8 — Montar e entregar o documento

Use `dados_renderizados.json` (já validado) para montar um `.docx` (consulte a skill `docx`), organizado por Versão → Protagonista (e Coadjuvante, se houver) → Capa → Páginas 1..N, com as dimensões ajustadas ao formato do Passo 3.

Nomeie os arquivos dinamicamente a partir do tema — nunca um nome fixo/genérico: `livro_colorir_<tema-em-slug>_<AAAAMMDD>.docx` e `livro_colorir_<tema-em-slug>_<AAAAMMDD>_bible.json` (data atual da conversa). Gere ambos em `/mnt/user-data/outputs` e apresente os dois com `present_files` — a bíblia é o que permite estender o livro (ou reaproveitar protagonista/estilo) numa sessão futura sem deriva.

Se a sessão tiver alguma ferramenta/conector de geração de imagens disponível (confira antes de assumir que não há), ofereça gerar as ilustrações direto — a prévia do Passo 5 já cumpre esse papel: gere as capas de verdade primeiro, deixe o usuário escolher a direção, só depois as páginas internas.
