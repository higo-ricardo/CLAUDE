# Banco de variações — atividades, perspectivas e poses

Use esta lista como ponto de partida ao montar as páginas internas. O objetivo é que nenhuma combinação de **atividade + perspectiva** se repita dentro da mesma versão — isso é o que faz o livro parecer variado em vez de repetitivo, mesmo com um único protagonista fixo.

Para livros com muitas páginas (16+), monte uma tabelinha simples (pode ser mental ou um rascunho em texto) marcando as combinações já usadas nesta versão antes de escrever o prompt da próxima página, para não repetir.

## Atividades (adapte ao tipo de protagonista — pessoa, animal ou veículo)

comendo · brincando · correndo · pulando · dormindo/cochilando · dançando · nadando · voando/saltando alto · lendo/olhando um livro · construindo algo · cumprimentando um amigo · explorando um lugar novo · descansando na sombra · brincando na chuva ou na neve · escondendo-se · procurando algo · comemorando · ajudando um amigo · aprendendo algo novo · fazendo uma parada para descansar

## Perspectivas

de frente · de perfil (lado) · de costas · plano baixo (visto de baixo para cima, dá sensação de grandeza) · plano alto (visto de cima) · close-up (foco no rosto/expressão) · plano aberto (mostra o cenário ao redor)

## Poses

parado · em movimento/andando · sentado · deitado · em pulo · em equilíbrio · esticando-se · agachado

## Como combinar

1. Escolha uma atividade que ainda não foi usada nesta versão.
2. Escolha uma perspectiva que ainda não foi usada com essa mesma atividade nesta versão.
3. Escolha uma pose que combine naturalmente com a atividade (não force combinações estranhas, ex. "dormindo" + "em pulo" não faz sentido).
4. Descreva um cenário/elemento de fundo simples e coerente com o subtema da versão (mas sem virar o foco principal — o protagonista continua sendo o centro da cena).
