# Arcos narrativos (storytelling guiado)

**Escopo: só use isto quando o tema for Animais ou Pessoas.** Para veículos, dinossauros, espaço, natureza, esportes e qualquer outro tema, não ofereça storytelling — vá direto para o banco de variações solto (`banco_variacoes.md`), sem sequência narrativa. Objetos/veículos não têm "rotina" ou "jornada" plausível da mesma forma que um personagem vivo, e forçar isso soa artificial.

Cada arco abaixo é uma lista-modelo de *beats* (momentos), em ordem cronológica/causal. A **atividade** de cada página vem do beat; a **perspectiva** e a **pose** continuam vindas de `banco_variacoes.md` para dar variedade visual — não repita a mesma perspectiva em beats consecutivos.

## Como adaptar ao número de páginas pedido

- Sempre mantenha o primeiro e o último beat do arco (eles fecham a história).
- Para N menor que o tamanho da lista-modelo, distribua os beats restantes uniformemente ao longo da lista, preservando a ordem.
- Para N maior, desdobre um beat em duas páginas com ângulos diferentes (ex.: "brincando de manhã" → uma página chegando na brincadeira, outra no meio dela) em vez de inventar um beat fora de ordem.
- Adapte a redação de cada beat ao subtema da versão (ex. "atividade especial do dia" numa versão de fazenda vira "ajudando a colher ovos no galinheiro"; na floresta vira "seguindo pegadas de um amigo").

## Arco 1 — Um dia na vida

1. Acordando e espreguiçando
2. Tomando café da manhã
3. Se arrumando para o dia
4. Saindo de casa/da toca
5. Cumprimentando um amigo
6. Brincando de manhã
7. Fazendo a atividade especial do dia (ligada ao subtema)
8. Ajudando alguém
9. Almoçando
10. Descansando um pouco depois do almoço
11. Explorando algo novo à tarde
12. Aprendendo uma habilidade nova
13. Brincando com amigos à tarde
14. Lanche da tarde
15. Voltando para casa
16. Jantando
17. Se preparando para dormir
18. Dormindo, boa noite

## Arco 2 — Jornada e aventura

1. Saindo de casa em busca de algo
2. Encontrando um amigo pelo caminho
3. Atravessando um lugar novo (ligado ao subtema)
4. Um primeiro obstáculo pequeno aparece
5. Pensando em como resolver o obstáculo
6. Pedindo ajuda a um amigo
7. Superando o primeiro obstáculo
8. Descobrindo uma pista ou algo interessante
9. Um obstáculo maior aparece
10. Trabalhando em equipe para superá-lo
11. Alcançando o objetivo da jornada
12. Comemorando a conquista
13. Compartilhando a conquista com os amigos
14. Voltando para casa, feliz

## Arco 3 — "Eu descrevo os momentos" (personalizado)

Quando o usuário escolher esta opção, peça a ele (em texto normal, não precisa de `ask_user_input_v0`) a lista de momentos que ele quer ver, na ordem que quiser. Use essa lista como os beats de todas as 3 versões, adaptando a redação de cada beat ao subtema de cada versão — a estrutura narrativa fica igual entre as versões, só muda a ambientação.
