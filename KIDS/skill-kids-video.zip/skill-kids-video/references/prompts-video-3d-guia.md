# Prompts de Vídeo 3D por Cena

## Por que cada prompt precisa ser autocontido

Ferramentas de geração de vídeo por IA (Runway, Sora, Kling, Pika, Veo e similares) geram cada clipe de forma isolada — não existe memória entre cenas nem entre cortes dentro do mesmo prompt. Se você escrever "o mesmo personagem da cena anterior", a ferramenta não sabe o que isso significa. Por isso todo prompt de cena repete a descrição visual completa do personagem.

## Gere o bloco de personagem com o script — uma vez por episódio, nunca reescreva de memória

Reescrever a descrição de um personagem de cabeça, cena após cena, é exatamente como o drift visual acontece: uma palavra trocada aqui, uma cor esquecida ali, e depois de 10 cenas o personagem já não bate mais com a bíblia. Por isso essa parte do prompt não é escrita à mão — mas também não precisa ser recomputada a cada cena, já que o bloco de um personagem é sempre o mesmo dentro do episódio. Rode o script **uma única vez**, logo no início do Passo 6, passando de uma vez todos os personagens que aparecem em algum prompt do episódio:

```bash
python scripts/render_bloco_personagem.py character-bible.md "Fon" "Tarta" "Piu"
```

(troque os nomes pelo elenco fixo + convidado do episódio) e guarde a saída. Depois, em cada prompt de cena, cole só as linhas dos personagens que aparecem *naquela* cena específica — sem editar o texto e sem rodar o script de novo por cena. Nunca abrevie com algo como "(mesma descrição visual de sempre)": mesmo que pareça óbvio para você, o modelo de vídeo não tem acesso à bíblia, só ao texto do prompt.

O restante do prompt (ação, background, câmera, luz, trilha) continua sendo escrito por você, cena a cena — é aí que a criatividade do episódio mora, e um template rígido para essa parte tenderia a gerar cenas genéricas.

## Estrutura recomendada por prompt

```
[ESTILO/RENDER] + [DESCRIÇÃO COMPLETA DO(S) PERSONAGEM(NS) EM CENA] + [AÇÃO] + [BACKGROUND] + [CÂMERA] + [LUZ] + [ÁUDIO/TRILHA] + [DURAÇÃO]
```

Exemplo de prompt de cena (ilustrativo — adapte ao elenco real da série):

> Animação 3D estilizada, estilo Pixar, cores vibrantes e saturadas, render limpo e macio. [Nome do protagonista]: [colar aqui a descrição visual completa da bíblia — espécie, cor primária e secundária, textura, olhos grandes, roupa fixa, marca visual única]. Ele pula três vezes sobre uma poça d'água azul-turquesa brilhante, fazendo splashes redondos e satisfatórios que respingam gotas em formato de coração. Ao fundo, uma floresta de árvores arredondadas em tons de verde-limão e pêssego, sol da tarde entrando em raios suaves entre as folhas, borboletas grandes e coloridas voando em loop lento. Câmera baixa, levemente inclinada para cima, seguindo o pulo em plano médio. Luz quente e difusa, sem sombras duras. Trilha: xilofone saltitante acompanhando cada pulo, SFX de splash a cada pouso. Duração: 6 segundos.

## Boas práticas

- **Um prompt por cena do roteiro**, na mesma ordem e numeração das cenas — nunca combine duas batidas narrativas em um único prompt de vídeo (a maioria das ferramentas gera clipes curtos, de 4 a 10 segundos; um episódio de 3-4 minutos vira várias dezenas de clipes).
- **O bloco de personagem vem sempre do script**, nunca de memória ou de uma abreviação — ver seção acima.
- **Repita a paleta de cores da série** em toda cena, mesmo quando o cenário muda — é o que dá identidade visual consistente ao longo dos episódios.
- **Descreva o movimento em termos físicos e específicos** ("pula três vezes", "gira em círculos duas vezes"), nunca em termos abstratos ("se move de forma feliz") — modelos de vídeo seguem melhor instruções de movimento concretas.
- **Aponte a duração estimada do clipe** ao final do prompt, alinhada ao timecode da cena no roteiro.
- **Não inclua diálogo falado dentro do prompt de vídeo** a menos que a ferramenta usada suporte fala sincronizada — combine com o usuário se o áudio (fala e música) será adicionado depois em pós-produção ou gerado junto.
