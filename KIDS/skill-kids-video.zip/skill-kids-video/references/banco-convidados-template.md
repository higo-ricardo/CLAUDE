# Banco de Convidados — [Nome da Série]

Este arquivo vive ao lado de `character-bible.md`, na mesma pasta do projeto, com o nome `banco-convidados.md`. Ele existe por dois motivos:

1. **Evitar reaproveitar um nome sem querer.** Se o episódio 7 tem um convidado "Zeca" e o episódio 15 também, sem essa checagem eu poderia desenhar dois "Zeca" completamente diferentes achando que é a primeira vez. O `scripts/banco_convidados.py checar` avisa se o nome já existe.
2. **Permitir trazer um convidado de volta com consistência**, se o usuário decidir usar alguém de novo sem torná-lo formalmente "recorrente" na bíblia — a descrição visual completa já fica registrada aqui, pronta para o `render_bloco_personagem.py` reaproveitar.

Nunca edite este arquivo à mão fora do fluxo normal — use `scripts/banco_convidados.py` para registrar (`registrar`) e para checar (`checar`) um nome antes de criar um convidado novo. Isso mantém a tabela e os blocos YAML sempre no mesmo formato, que os scripts dependem para funcionar.

## Índice de episódios

| Episódio | Título | Convidado | Lição | Recorrente? |
|---|---|---|---|---|
| 1 | A Vez de Brincar | Piu | esperar a vez para brincar | Não |

## Fichas dos convidados

Um bloco por convidado (a primeira vez que aparece). Convidados não competem pela paleta de 5 cores exclusiva do elenco fixo — podem repetir cor entre si ou com o elenco sem problema, já que não aparecem sempre lado a lado no mesmo plano com a mesma frequência.

### Piu (Episódio 1)

```yaml personagem
nome: "Piu"
tipo: "passarinho antropomórfico"
estagio_vida: "jovem"
altura_relativa: 0.4  # sempre em relação ao protagonista da série (1.0)
descricao_visual_completa: "passarinho pequeno, penas azul-elétrico brilhante, peito branco, bico laranja curto, olhos redondos grandes e vivos, voa de forma rápida e um pouco desajeitada"
tique_de_fala: "[opcional — convidados de episódio único nem sempre têm catchphrase fixa]"
movimento_caracteristico: "voa em linha irregular, para de repente no ar"
```

Campos como `tipo`, `estagio_vida`, `altura_relativa`, `tique_de_fala` e `movimento_caracteristico` seguem o mesmo schema da bíblia (ver `character-bible-template.md`), mas para convidados são opcionais — preencha o que já estiver definido na hora de escrever o episódio; `nome` e `descricao_visual_completa` são os únicos obrigatórios, porque são os dois campos que os scripts efetivamente usam hoje (render e checagem de drift). Convidados não competem pela paleta de 5 cores exclusiva do elenco fixo, então `cor_assinatura` é opcional aqui.
