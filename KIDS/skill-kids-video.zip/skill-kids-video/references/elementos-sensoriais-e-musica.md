# Estímulo Sensorial e Música Contagiante

## Por que estímulo sensorial explícito, cena a cena

Vídeos infantis de sucesso (Cocomelon, Baby Shark, Word Party) não retêm a atenção de crianças pequenas pela trama — retêm pela densidade de estímulo sensorial simultâneo e previsível. Por isso cada cena do roteiro precisa marcar, de forma explícita, pelo menos:

- **Cor**: um elemento de cor saturada e nomeável entra ou muda na cena (não decoração de fundo genérica — algo que o roteiro e o prompt de vídeo apontem: "a bola fica verde-limão quando quica")
- **Textura/movimento**: algo com movimento repetitivo e satisfatório de acompanhar (quicar, girar, esguichar, inflar/desinflar, balançar) — esse é o elemento mais "hipnótico" desse gênero e o que mais aparece em prompts de vídeo gerado por IA
- **Som**: um som específico e reconhecível, não "música de fundo" genérica — onomatopeias funcionam bem em texto (boing, splash, tin-tin)

Banco de ideias por categoria (adapte ao cenário do episódio, não use sempre os mesmos):
- Cor: objetos que mudam de cor ao serem tocados, arco-íris, luzes que pulsam no ritmo da música, roupas que trocam de padrão
- Textura/movimento: bolhas, água, massinha, tecidos esvoaçantes, folhas caindo, engrenagens girando, coisas que crescem/encolhem
- Som: instrumentos de brinquedo, animais, água, sinos, eco, contagem em voz alta

## Música contagiante — o que faz um refrão "colar"

- **Repetição do refrão pelo menos 2 vezes** dentro da mesma música — a criança precisa da segunda exposição para começar a cantar junto
- **Frase-gancho de 4-8 sílabas**, fácil de repetir por uma criança de 2-5 anos
- **Rima simples** (AABB ou ABAB) — não force rimas complexas ou raras
- **Ligação direta com um gesto**: toda canção-chave de episódio deve vir com uma sugestão de gesto/dança de 1-2 movimentos que a criança consegue imitar sentada (bater palma, girar o pulso, tocar a cabeça) — anote isso junto da letra
- **Andamento e instrumentação**: escolha um andamento consistente com a energia da cena (uma canção de embalar não deve ter o mesmo BPM da canção-chave de ação) e 2-3 instrumentos "de brinquedo" reconhecíveis (xilofone, ukulele, kazoo, glockenspiel)

## Integração com skill-cantiga

Esta skill escreve apenas a **letra** e a **direção de estilo** das músicas do episódio — ela não produz áudio. Se a sessão tiver acesso à skill `skill-cantiga` (ou outra skill de geração musical), delegue a produção do áudio final para ela, passando a letra e a direção de estilo definidas aqui como entrada.
