# Bíblia de Personagens — [Nome da Série]

Preencha uma seção completa como esta para CADA personagem do elenco fixo. Esta é a fonte da verdade: todo prompt de vídeo 3D e toda cena futura deve copiar a descrição visual literalmente, palavra por palavra, para o personagem não "derivar" de episódio para episódio.

**Limite de elenco por episódio**: o número de personagens ativos em um episódio (elenco fixo + convidados) tem **padrão 3** (protagonista + coadjuvante + 1 convidado) e **não deve passar de 5**. Acima disso a criança perde a capacidade de acompanhar quem é quem em 3-4 minutos — é o mesmo motivo pelo qual séries do gênero raramente têm mais de 3-4 personagens falantes por episódio. `scripts/validar_roteiro.py` checa esse limite automaticamente contando quantos personagens conhecidos (da bíblia + do banco de convidados) aparecem nos prompts de vídeo do episódio.

## Traços físicos elegíveis (banco fixo da série)

Este é o banco de opções apresentado ao usuário no Passo 1 (Rodada B) via `ask_user_input_v0`, um personagem por vez. Copie para cada personagem, na seção dele mais abaixo, só os traços que o usuário efetivamente marcou — não aplique os 10 de uma vez em ninguém, o objetivo é cada personagem ter uma combinação própria e reconhecível.

**Grupo 1 — Cabeça e feições**
1. Cabeça desproporcionalmente grande (estilo chibi) — ajuda a leitura de expressão à distância e em telas pequenas
2. Olhos grandes e expressivos — o traço mais importante para transmitir emoção sem diálogo
3. Bochechas rosadas e volumosas — reforça a leitura de "fofura" e bom humor
4. Orelhas ou apêndices grandes (orelhas, chifres, antenas) — dá silhueta reconhecível mesmo em contraluz

**Grupo 2 — Corpo e contorno**
5. Contornos bem redondos e macios — sem quinas nem ângulos, reduz a sensação de ameaça visual
6. Corpo baixo e atarracado (proporção "bebê") — cabeça maior que o corpo, centro de gravidade baixo
7. Barriga redonda e saliente — bom ponto de apoio visual para gestos de "abraço" e comédia física

**Grupo 3 — Textura e movimento**
8. Mãos e pés arredondados, sem dedos detalhados — mais fácil de animar e de ler em telas pequenas
9. Textura macia tipo pelúcia (em vez de realista) — reforça o convite ao toque/carinho
10. Movimento saltitante e elástico (squash-and-stretch exagerado) — dá vida e comicidade mesmo em poses estáticas

Se o usuário pedir um traço fora desses 10, registre-o normalmente na ficha do personagem como traço próprio — o banco acima é o ponto de partida oferecido, não um limite rígido.

## [Nome do Personagem] — Protagonista / Coadjuvante

- **Tipo** (também vai para o YAML, campo `tipo`): criança, animal antropomórfico, objeto animado, criatura fantástica...
- **Estágio de vida** (também vai para o YAML, campo `estagio_vida`): `filhote` / `jovem` / `adulto` — normalmente já implícito no Tipo (ex: "filhote de raposa"), aqui é só formalizado como categoria própria, sem precisar de uma idade em anos (que não ajuda em nada um prompt de vídeo)
- **Altura relativa** (também vai para o YAML, campo `altura_relativa`): número decimal, sempre em relação ao protagonista, que por convenção é sempre `1.0`. Ex: se o coadjuvante é um pouco mais baixo, `0.85`; se um convidado é bem menor, `0.5`. Serve para o script ancorar a proporção entre personagens quando dois ou mais aparecem juntos no mesmo prompt — sem isso, o modelo de vídeo pode desenhar a mesma dupla em tamanhos diferentes de cena para cena
- **Traços físicos escolhidos** (também vai para o YAML, campo `tracos_fisicos`, como lista — marcados pelo usuário na Rodada B do Passo 1, dentre o banco de 10 traços elegíveis no topo deste arquivo, ou os 4 curados oferecidos por padrão): [ex: "cabeça desproporcionalmente grande, olhos grandes e expressivos, contornos bem redondos e macios, movimento saltitante e elástico"]
- **Cor-assinatura** (também vai para o YAML, campo `cor_assinatura` — uma das 5 da paleta da série — amarelo, azul, vermelho, verde, rosa — e **exclusiva deste personagem** dentro do elenco fixo; `scripts/validar_roteiro.py` checa essa exclusividade automaticamente lendo os blocos YAML da bíblia): [cor escolhida]
- **Descrição visual completa** (também vai para o YAML, campo `descricao_visual_completa` — para copiar em todo prompt de vídeo): espécie/forma, tamanho relativo, formato do corpo, aplicação da cor-assinatura como cor primária (com intensidade, ex: "amarelo-canário vibrante") e uma cor secundária de apoio, textura de pele/pelo/material, olhos (formato e tamanho conforme os traços de contorno escolhidos), roupa/acessório fixo, marca visual única (uma cicatriz, um chapéu, um padrão)
- **Estilo de render**: (ex: 3D estilizado tipo Pixar, claymation digital, low-poly fofo, pelúcia 3D) — deve ser o MESMO para todos os personagens da série, por isso não vai no YAML por personagem (fica só aqui e na seção "Ambiente-base da série")
- **Personalidade em 3 traços**: (ex: curioso, impulsivo, generoso) — só prosa; nenhum script usa isso hoje, então não há ganho em estruturar
- **Papel narrativo**: o que esse personagem tipicamente representa nos conflitos (quem propõe a ideia arriscada, quem traz a razão, quem sente medo primeiro) — só prosa, mesmo motivo acima
- **Tique de fala / catchphrase** (também vai para o YAML, campo `tique_de_fala`): uma expressão que ele repete (ajuda a criança a reconhecer e imitar)
- **Leitmotif musical**: instrumento ou frase melódica curta que sempre entra quando ele age ou entra em cena (ex: "clarinete saltitante", "sino triangular") — só prosa; é usado por mim ao escrever a trilha da cena, não por nenhum script
- **Movimento característico** (também vai para o YAML, campo `movimento_caracteristico`): como ele anda/se move (pula, arrasta, flutua, gira) — usado nas instruções de "ação" do roteiro

Depois da prosa acima, inclua o bloco estruturado abaixo (mesmos dados, formato que os scripts leem). É este bloco — não a prosa solta — que é a fonte da verdade: sempre que um desses campos mudar, mude aqui primeiro.

```yaml personagem
nome: "[Nome do Personagem]"
tipo: "[tipo do personagem]"
estagio_vida: "filhote"  # filhote / jovem / adulto
altura_relativa: 1.0  # protagonista é sempre 1.0; os demais, proporcionais a ele
tracos_fisicos:
  - "[traço 1 escolhido do banco de 10]"
  - "[traço 2 escolhido do banco de 10]"
cor_assinatura: "[cor da paleta de 5, exclusiva deste personagem no elenco fixo]"
descricao_visual_completa: "[a mesma descrição visual completa de cima, em uma única string, sem quebras de linha]"
tique_de_fala: "[a catchphrase do personagem]"
movimento_caracteristico: "[como ele se move]"
```

## Personagens além do elenco fixo

Este arquivo guarda só o elenco fixo — protagonista e coadjuvante, sempre os dois, sempre presentes. Qualquer outro personagem vive em um dos dois arquivos irmãos, dependendo da natureza:

- **`personagens-facultativos.md`** — personagens que pertencem à própria franquia, criados em lote uma vez, sorteados (0 a 3 por episódio) por `scripts/sortear_elenco.py`. É o caminho padrão (a maioria dos episódios usa este pacote). Ver `references/personagens-facultativos-template.md`.
- **`banco-convidados.md`** — personagens emprestados de outra franquia (crossover). Caminho de exceção: só existem quando o usuário pede explicitamente, nunca são sorteados. Ver `references/banco-convidados-template.md`.

Se o usuário promover um personagem de `banco-convidados.md` a recorrente, ele entra em `personagens-facultativos.md` (passa a fazer parte do pacote sorteável da franquia) — nunca aqui na bíblia, que fica reservada só para o par fixo.

## Ambiente-base da série

- **Cenário-padrão**: onde a maior parte das aberturas/encerramentos acontece
- **Paleta de cores da série**: 3-4 cores dominantes de cenário/ambiente que aparecem em todo episódio, independente da história (diferente da cor-assinatura de cada personagem, que vem da paleta fixa de 5 cores — amarelo, azul, vermelho, verde, rosa — e nunca se repete entre dois personagens do elenco)
- **Ritual de abertura**: o que sempre acontece nos primeiros segundos (mesma vinheta, mesma frase de entrada)
- **Ritual de encerramento**: o que sempre acontece no final (mesma despedida, mesmo gesto)
