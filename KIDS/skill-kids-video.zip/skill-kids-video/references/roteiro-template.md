# Template de Roteiro de Episódio

Use esta estrutura, nesta ordem, para o documento final do episódio.

```markdown
# [Título do Episódio]

## Ficha do episódio
- Série: [nome]
- Elenco fixo: [protagonista], [coadjuvante]
- Convidado: [nome e uma linha de descrição]
- Lição: [uma frase concreta, ex: "esperar a vez para brincar"]
- Duração alvo: [3:00–4:00]

## Músicas do episódio
### Tema de abertura (fixo da série)
[letra completa — reaproveitar sempre a mesma]

### Canção-chave do episódio
[letra completa, com refrão marcado]
Estilo/andamento: [ex: reggae infantil, ~100 BPM, xilofone e ukulele]

### Tema de encerramento (fixo da série)
[letra completa — reaproveitar sempre a mesma]

## Roteiro cena a cena

### Cena 1 — [nome curto da cena] ([timecode, ex: 0:00–0:18])
**Background:** [ambiente 3D completo — luz, hora do dia, elementos de fundo em movimento, textura predominante]
**Ação:** [o que acontece, em linguagem de direção]
**Diálogo:**
- [Personagem]: "[fala curta]"
**Estímulo sensorial:** cor: [...] · textura/movimento: [...] · som: [...]
**Música/SFX:** [o que toca nesse momento]

[repetir para cada cena até cobrir as 6 batidas do arco]
```

## Regras de escrita de diálogo para essa faixa etária

- Uma ideia por fala. Nunca duas orações coordenadas na mesma fala de personagem.
- Repita palavras-chave da lição ao longo do episódio — a repetição é o que ensina, não a variação de vocabulário.
- Prefira perguntas diretas ao público ("Vocês conseguem ver o quê?") em pelo menos uma cena — convida a criança a participar, não só assistir.
- Toda ação física importante deve ter um som associado descrito no roteiro (mesmo que "SFX: boing") — é isso que orienta a trilha e o design de som depois.
