# Personagens Facultativos — [Nome da Série]

Este arquivo vive ao lado de `character-bible.md`, com o nome `personagens-facultativos.md`. É o pacote de personagens que **pertencem à franquia** (não são emprestados de fora) mas não fazem parte do elenco fixo — protagonista e coadjuvante continuam sendo só os dois de `character-bible.md`, sempre presentes.

**Diferença crucial em relação a `banco-convidados.md`**: os personagens daqui são criados **uma vez, em lote**, no início da série (ou quando o usuário decidir expandir o pacote) — nunca no meio de um episódio, e nunca por pedido de crossover. `scripts/sortear_elenco.py` sorteia entre 0 e 3 deles para aparecer em cada episódio (ver Passo 2 do `SKILL.md`). Um convidado de outra franquia é o caminho de exceção oposto: só existe se o usuário pedir explicitamente, nunca é sorteado, e vai para `banco-convidados.md`, não para cá.

## Personagens

Uma seção por personagem, no mesmo formato da bíblia (prosa + bloco YAML). `cor_assinatura` aqui é opcional e **não precisa ser exclusiva** entre os facultativos — a regra de cor exclusiva vale só para o elenco fixo (protagonista + coadjuvante).

### [Nome do Personagem]

- **Tipo**: ...
- **Estágio de vida**: filhote / jovem / adulto
- **Altura relativa**: número em relação ao protagonista (que é sempre 1.0)
- **Traços físicos escolhidos**: ...
- **Cor-assinatura** (opcional): ...
- **Descrição visual completa**: ...
- **Personalidade em 3 traços**: ...
- **Papel narrativo**: ...
- **Tique de fala**: ...
- **Movimento característico**: ...

```yaml personagem
nome: "[Nome do Personagem]"
tipo: "[tipo]"
estagio_vida: "[filhote/jovem/adulto]"
altura_relativa: [número relativo ao protagonista = 1.0]
tracos_fisicos:
  - "[traço 1]"
  - "[traço 2]"
cor_assinatura: "[opcional]"
descricao_visual_completa: "[descrição completa, uma única string]"
tique_de_fala: "[catchphrase]"
movimento_caracteristico: "[como se move]"
```
