# Personagens Facultativos — Raposinha e Tarta

Pacote inicial da franquia, criado em lote.

### Coco

```yaml personagem
nome: "Coco"
tipo: "filhote de macaco antropomórfico"
estagio_vida: "filhote"
altura_relativa: 0.6
tracos_fisicos:
  - "cabeça desproporcionalmente grande (estilo chibi)"
  - "movimento saltitante e elástico (squash-and-stretch exagerado)"
cor_assinatura: "vermelho"
descricao_visual_completa: "filhote de macaco antropomórfico, pelagem marrom-caramelo, barriga vermelha vibrante, orelhas redondas grandes, olhos castanhos enormes e curiosos, sempre com uma banana de brinquedo na mão"
tique_de_fala: "Eba, vamos ver!"
movimento_caracteristico: "balança de galho em galho imaginário, mesmo no chão"
```

### Lili

```yaml personagem
nome: "Lili"
tipo: "coelha antropomórfica"
estagio_vida: "jovem"
altura_relativa: 0.8
tracos_fisicos:
  - "olhos grandes e expressivos"
  - "bochechas rosadas e volumosas"
cor_assinatura: "rosa"
descricao_visual_completa: "coelha antropomórfica jovem, pelagem branco-neve com as pontas das orelhas rosa-chiclete, olhos violeta grandes, laço rosa numa orelha, sempre com uma flor atrás da outra orelha"
tique_de_fala: "Que fofurinha!"
movimento_caracteristico: "pula em círculos quando fica animada"
```
