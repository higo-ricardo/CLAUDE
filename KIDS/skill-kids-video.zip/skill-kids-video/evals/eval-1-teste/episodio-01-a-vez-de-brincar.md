# Episódio 1 — A Vez de Brincar

## Ficha do episódio
- Série: Raposinha e Tarta
- Elenco fixo: Fon (protagonista), Tarta (coadjuvante)
- Convidado: Piu, um passarinho azul pequeno e elétrico, que fala rápido demais e quer jogar tudo ao mesmo tempo
- Lição: esperar a vez para brincar
- Duração alvo: 3:30

## Músicas do episódio

### Tema de abertura (fixo da série)
Na clareira colorida, o dia começou (bora, bora, bora!)
Fon já pulou, Tarta ainda chegou (devagar, devagar!)
Raposinha e Tarta, os dois pra brincar
Vem com a gente, o sol vai clarear!

### Canção-chave do episódio — "Um de Cada Vez"
Um de cada vez, um de cada vez (refrão)
Primeiro é ele, depois é você
Um de cada vez, um de cada vez
A vez de todo mundo vai aparecer!

Fon quer já, Piu quer também
Tarta bate palma e conta assim: um, dois, três, tem!
Um de cada vez, um de cada vez
Todo mundo brinca, ninguém fica sem!

Gesto sugerido: bater palma duas vezes no "um, dois" e apontar para frente no "três, tem!"
Estilo/andamento: reggae infantil, ~100 BPM, xilofone e ukulele

### Tema de encerramento (fixo da série)
O sol já desceu, foi um dia legal (bora, bora, bora!)
Amanhã tem mais, é só esperar (devagar, devagar!)
Raposinha e Tarta, até mais pra brincar
Tchau, tchau, amiguinho, vem nos visitar!

## Roteiro cena a cena

### Cena 1 — Abertura (0:00–0:20)
**Background:** A clareira redonda da floresta, manhã ensolarada, luz dourada entrando entre folhas gigantes verde-esmeralda, borboletas turquesa voando em loop lento ao fundo, o toco central brilhando levemente com orvalho.
**Ação:** Fon pula em cima do toco central, Tarta sobe devagar logo atrás. Os dois cantam olhando para a câmera.
**Diálogo:**
- Fon: "Bora, bora, bora!"
- Tarta: "Devagar se vai ao longe!"
**Estímulo sensorial:** cor: laranja-cenoura de Fon contra o verde-esmeralda da folhagem · textura/movimento: orvalho brilhando e escorrendo do toco · som: clarinete saltitante de Fon entrando em escala ascendente
**Música/SFX:** Tema de abertura cantado por Fon e Tarta

### Cena 2 — Estabelecimento (0:20–0:55)
**Background:** Mesma clareira, agora com uma pilha de brinquedos coloridos empilhados perto do toco: uma bola amarela-sol, um pião turquesa, um arco verde.
**Ação:** Piu desce voando rápido demais, esbarra na pilha de brinquedos e pega todos ao mesmo tempo, tentando jogar com os três de uma vez.
**Diálogo:**
- Piu: "Eu quero a bola! E o pião! E o arco também!"
- Fon: "Opa, Piu, calma aí!"
**Estímulo sensorial:** cor: azul-elétrico de Piu contra o amarelo-sol da bola · textura/movimento: brinquedos rolando e se chocando no chão · som: pios acelerados de Piu e o barulho de plástico batendo
**Música/SFX:** SFX de "poc-poc-poc" a cada brinquedo caindo

### Cena 3 — Primeira tentativa (0:55–1:35)
**Background:** A clareira, agora com os brinquedos espalhados em círculo, poeira colorida levantando levemente no chão.
**Ação:** Fon tenta pegar a bola ao mesmo tempo que Piu, os dois puxam para lados opostos e a bola escapa, quicando longe. Tarta observa devagar, sem se mexer.
**Diálogo:**
- Fon: "Ei, essa bola é minha vez!"
- Piu: "Não, é a minha!"
- Tarta: "Hmm... acho que precisamos de uma ideia."
**Estímulo sensorial:** cor: a bola amarela quicando deixa um rastro de brilho dourado no ar · textura/movimento: a bola quicando em arcos cada vez mais baixos até parar · som: "boing-boing-boing" decrescente
**Música/SFX:** SFX de boing a cada quique, sem música de fundo (silêncio tenso e cômico)

### Cena 4 — Momento sensorial/musical central (1:35–2:35)
**Background:** A clareira se ilumina com um brilho mágico suave em turquesa e dourado, como se a própria floresta ajudasse Tarta a explicar a ideia; pequenas partículas de luz flutuam devagar no ar.
**Ação:** Tarta bate palma três vezes devagar e começa a cantar, organizando Fon e Piu em fila. Cada um brinca com a bola por vez, jogando para o próximo no "três, tem!".
**Diálogo:**
- Tarta: "Um de cada vez, um de cada vez!"
- Fon e Piu (cantando junto, cada vez mais animados): "Um de cada vez, um de cada vez!"
**Estímulo sensorial:** cor: partículas de luz turquesa e dourada flutuando · textura/movimento: a bola passando de mão em mão em um arco suave e repetitivo · som: xilofone e ukulele tocando o refrão, palmas marcando o tempo
**Música/SFX:** Canção-chave "Um de Cada Vez" completa, com o gesto de bater palma duas vezes e apontar

### Cena 5 — Resolução (2:35–3:10)
**Background:** A clareira volta à luz normal da tarde, os brinquedos agora organizados em fila ao lado do toco, sombras já um pouco mais compridas.
**Ação:** Fon, Tarta e Piu brincam em roda, revezando a bola, o pião e o arco em sequência, rindo juntos.
**Diálogo:**
- Piu: "Esperar a vez até que foi divertido!"
- Fon: "Bora fazer de novo, um de cada vez!"
**Estímulo sensorial:** cor: os três brinquedos (amarelo, turquesa, verde) girando em roda · textura/movimento: a roda de amigos girando devagar enquanto passam os brinquedos · som: risadas sobrepostas e o pião girando com um zumbido agudo
**Música/SFX:** Trecho instrumental leve do refrão da canção-chave, mais baixo, como música de fundo

### Cena 6 — Encerramento (3:10–3:30)
**Background:** Fim de tarde na clareira, céu em tons de pêssego e violeta, vaga-lumes turquesa começando a piscar entre as árvores.
**Ação:** Fon e Tarta se sentam no toco central abraçados, Piu pousa entre os dois. Os três acenam para a câmera.
**Diálogo:**
- Fon e Tarta: "Tchau, tchau, amiguinho, vem nos visitar!"
**Estímulo sensorial:** cor: céu em gradiente pêssego-violeta · textura/movimento: vaga-lumes piscando em loop lento · som: violoncelo grave de Tarta encerrando em nota longa e suave
**Música/SFX:** Tema de encerramento cantado por Fon e Tarta

## Prompts de Vídeo 3D

### Prompt — Cena 1 (0:00–0:20)
Animação 3D estilizada, estilo Pixar, cores vibrantes e saturadas, render macio e limpo. Fon: filhote de raposa antropomórfico, pelagem laranja-cenoura vibrante no corpo com a ponta da cauda e o peito em branco-neve macio, orelhas grandes e arredondadas, olhos enormes cor de âmbar com brilho, veste um lenço triangular azul-turquesa amarrado no pescoço, cauda grossa e felpuda que balança quando ele fala, uma pequena mancha em formato de estrela na testa. Tarta: tartaruga antropomórfica, casco grande em verde-musgo com padrão de espiral dourada no centro, corpo pequeno em verde mais claro, olhos redondos e gentis com cílios longos, usa óculos redondos vermelhos, um pequeno chapéu de palha preso no casco, movimentos e voz sempre calmos. Fon pula sobre um toco de árvore central coberto de orvalho brilhante, Tarta sobe devagar logo depois. Clareira redonda de floresta tropical, luz dourada da manhã entre folhas verde-esmeralda gigantes, borboletas turquesa voando em loop lento ao fundo. Câmera frontal baixa, leve zoom in nos dois personagens. Luz quente e suave, sombras macias. Trilha: clarinete em escala ascendente seguido de violoncelo grave sustentado. Duração: 8 segundos.

### Prompt — Cena 2 (0:20–0:55)
Animação 3D estilizada, estilo Pixar, cores vibrantes e saturadas. Piu: passarinho pequeno, penas azul-elétrico brilhante, peito branco, bico laranja curto, olhos redondos grandes e vivos, voa de forma rápida e um pouco desajeitada. Fon: filhote de raposa antropomórfico, pelagem laranja-cenoura vibrante no corpo com a ponta da cauda e o peito em branco-neve macio, orelhas grandes e arredondadas, olhos enormes cor de âmbar com brilho, veste um lenço triangular azul-turquesa amarrado no pescoço, cauda grossa e felpuda que balança quando ele fala, uma pequena mancha em formato de estrela na testa. Piu desce voando depressa, colide de leve com uma pilha de brinquedos coloridos (bola amarela-sol, pião turquesa, arco verde) perto do toco central, e tenta segurar os três ao mesmo tempo com as asinhas, deixando-os cair e rolar. Fundo: mesma clareira ensolarada. Câmera em plano médio, leve tremor de câmera no momento da colisão para dar comicidade. Luz de meio-dia, alto contraste suave. Trilha: SFX "poc-poc-poc" sincronizado com cada brinquedo caindo, pios rápidos e agudos de Piu. Duração: 7 segundos.

### Prompt — Cena 3 (0:55–1:35)
Animação 3D estilizada, estilo Pixar. Fon: filhote de raposa antropomórfico, pelagem laranja-cenoura vibrante no corpo com a ponta da cauda e o peito em branco-neve macio, orelhas grandes e arredondadas, olhos enormes cor de âmbar com brilho, veste um lenço triangular azul-turquesa amarrado no pescoço, cauda grossa e felpuda que balança quando ele fala, uma pequena mancha em formato de estrela na testa. Piu: passarinho pequeno, penas azul-elétrico brilhante, peito branco, bico laranja curto, olhos redondos grandes e vivos, voa de forma rápida e um pouco desajeitada. Tarta: tartaruga antropomórfica, casco grande em verde-musgo com padrão de espiral dourada no centro, corpo pequeno em verde mais claro, olhos redondos e gentis com cílios longos, usa óculos redondos vermelhos, um pequeno chapéu de palha preso no casco, movimentos e voz sempre calmos. Fon e Piu puxam a bola amarela-sol brilhante cada um para um lado; a bola escapa das duas mãos/asas e quica em arcos decrescentes pelo chão da clareira, deixando um rastro leve de brilho dourado no ar a cada quique. Tarta observa parada ao fundo, imóvel, olhos atentos. Poeira colorida leve subindo do chão a cada quique. Câmera acompanhando a bola em travelling lateral baixo. Luz de tarde suave. Trilha: SFX "boing-boing-boing" decrescente, sem música de fundo. Duração: 8 segundos.

### Prompt — Cena 4 (1:35–2:35)
Animação 3D estilizada, estilo Pixar. Tarta: tartaruga antropomórfica, casco grande em verde-musgo com padrão de espiral dourada no centro, corpo pequeno em verde mais claro, olhos redondos e gentis com cílios longos, usa óculos redondos vermelhos, um pequeno chapéu de palha preso no casco, movimentos e voz sempre calmos. Fon: filhote de raposa antropomórfico, pelagem laranja-cenoura vibrante no corpo com a ponta da cauda e o peito em branco-neve macio, orelhas grandes e arredondadas, olhos enormes cor de âmbar com brilho, veste um lenço triangular azul-turquesa amarrado no pescoço, cauda grossa e felpuda que balança quando ele fala, uma pequena mancha em formato de estrela na testa. Piu: passarinho pequeno, penas azul-elétrico brilhante, peito branco, bico laranja curto, olhos redondos grandes e vivos, voa de forma rápida e um pouco desajeitada. Os três em fila, revezando a bola amarela-sol entre si em um arco suave e repetitivo, no ritmo da música. A clareira se ilumina com partículas de luz turquesa e dourada flutuando lentamente no ar ao redor dos três. Tarta bate palma marcando o tempo. Câmera em plano geral suave, leve movimento circular ao redor do trio. Luz mágica quente, brilho difuso. Trilha: xilofone e ukulele tocando o refrão "Um de cada vez", palmas marcando o tempo. Duração: 10 segundos (loop de refrão, repetir 2x).

### Prompt — Cena 5 (2:35–3:10)
Animação 3D estilizada, estilo Pixar. Fon: filhote de raposa antropomórfico, pelagem laranja-cenoura vibrante no corpo com a ponta da cauda e o peito em branco-neve macio, orelhas grandes e arredondadas, olhos enormes cor de âmbar com brilho, veste um lenço triangular azul-turquesa amarrado no pescoço, cauda grossa e felpuda que balança quando ele fala, uma pequena mancha em formato de estrela na testa. Tarta: tartaruga antropomórfica, casco grande em verde-musgo com padrão de espiral dourada no centro, corpo pequeno em verde mais claro, olhos redondos e gentis com cílios longos, usa óculos redondos vermelhos, um pequeno chapéu de palha preso no casco, movimentos e voz sempre calmos. Piu: passarinho pequeno, penas azul-elétrico brilhante, peito branco, bico laranja curto, olhos redondos grandes e vivos, voa de forma rápida e um pouco desajeitada. Os três brincam em roda, revezando a bola amarela-sol, o pião turquesa e o arco verde em sequência, girando os brinquedos entre si, todos sorrindo e rindo. Clareira em luz de tarde, sombras já um pouco mais compridas, brinquedos organizados em fila ao lado do toco central. Câmera em plano geral alto, levemente inclinada para baixo, capturando a roda inteira. Luz quente dourada de fim de tarde. Trilha: trecho instrumental suave do refrão, risadas sobrepostas, zumbido agudo do pião girando. Duração: 8 segundos.

### Prompt — Cena 6 (3:10–3:30)
Animação 3D estilizada, estilo Pixar. Fon: filhote de raposa antropomórfico, pelagem laranja-cenoura vibrante no corpo com a ponta da cauda e o peito em branco-neve macio, orelhas grandes e arredondadas, olhos enormes cor de âmbar com brilho, veste um lenço triangular azul-turquesa amarrado no pescoço, cauda grossa e felpuda que balança quando ele fala, uma pequena mancha em formato de estrela na testa. Tarta: tartaruga antropomórfica, casco grande em verde-musgo com padrão de espiral dourada no centro, corpo pequeno em verde mais claro, olhos redondos e gentis com cílios longos, usa óculos redondos vermelhos, um pequeno chapéu de palha preso no casco, movimentos e voz sempre calmos. Sentados abraçados no toco central, Piu: passarinho pequeno, penas azul-elétrico brilhante, peito branco, bico laranja curto, olhos redondos grandes e vivos, voa de forma rápida e um pouco desajeitada, pousado entre os dois. Céu em gradiente pêssego-violeta ao fundo, vaga-lumes turquesa piscando em loop lento entre as árvores da clareira. Os três acenam de frente para a câmera. Câmera frontal fixa, leve zoom out final. Luz quente e difusa de entardecer. Trilha: violoncelo grave em nota longa e suave encerrando a cena. Duração: 6 segundos.
