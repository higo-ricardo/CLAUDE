# Banco de Convidados

## Índice de episódios

| Episódio | Título | Convidado | Lição | Recorrente? |
|---|---|---|---|---|
| 1 | A Vez de Brincar | Piu | esperar a vez para brincar | Não |

## Fichas dos convidados


### Piu (Episódio 1)

```yaml personagem
nome: "Piu"
tipo: "passarinho antropomórfico"
estagio_vida: "jovem"
altura_relativa: 0.4
movimento_caracteristico: "voa em linha irregular, para de repente no ar"
descricao_visual_completa: "passarinho pequeno, penas azul-elétrico brilhante, peito branco, bico laranja curto, olhos redondos grandes e vivos, voa de forma rápida e um pouco desajeitada"
```
