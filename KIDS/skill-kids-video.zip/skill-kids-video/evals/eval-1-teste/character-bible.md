# Bíblia de Personagens — Raposinha e Tarta

## Fon — Protagonista

- **Tipo**: filhote de raposa antropomórfico
- **Descrição visual completa**: raposa pequena e atarracada, pelagem laranja-cenoura vibrante no corpo com a ponta da cauda e o peito em branco-neve macio, orelhas grandes e arredondadas, olhos enormes cor de âmbar com brilho, veste um lenço triangular azul-turquesa amarrado no pescoço, cauda grossa e felpuda que balança quando ele fala, uma pequena mancha em formato de estrela na testa
- **Estilo de render**: 3D estilizado tipo Pixar, superfícies macias e arredondadas, sem texturas realistas de pelo fio a fio (pelo em blocos estilizados)
- **Personalidade em 3 traços**: curioso, impulsivo, generoso
- **Papel narrativo**: sempre o primeiro a propor a ideia arriscada ou empolgante
- **Tique de fala**: "Bora, bora, bora!"
- **Cor-assinatura**: laranja-cenoura
- **Leitmotif musical**: clarinete saltitante, sempre em escala ascendente quando ele corre
- **Movimento característico**: pula em vez de andar, para de repente quando algo chama atenção

```yaml personagem
nome: "Fon"
tipo: "filhote de raposa antropomórfico"
estagio_vida: "filhote"
altura_relativa: 1.0
tracos_fisicos:
  - "cabeça desproporcionalmente grande (estilo chibi)"
  - "olhos grandes e expressivos"
  - "contornos bem redondos e macios"
  - "movimento saltitante e elástico (squash-and-stretch exagerado)"
cor_assinatura: "laranja-cenoura"
descricao_visual_completa: "filhote de raposa antropomórfico, pelagem laranja-cenoura vibrante no corpo com a ponta da cauda e o peito em branco-neve macio, orelhas grandes e arredondadas, olhos enormes cor de âmbar com brilho, veste um lenço triangular azul-turquesa amarrado no pescoço, cauda grossa e felpuda que balança quando ele fala, uma pequena mancha em formato de estrela na testa"
tique_de_fala: "Bora, bora, bora!"
movimento_caracteristico: "pula em vez de andar, para de repente quando algo chama atenção"
```

## Tarta — Coadjuvante

- **Tipo**: tartaruga antropomórfica
- **Descrição visual completa**: casco grande em verde-musgo com padrão de espiral dourada no centro, corpo pequeno em verde mais claro, olhos redondos e gentis com cílios longos, usa óculos redondos vermelhos, um pequeno chapéu de palha preso no casco, movimentos e voz sempre calmos
- **Estilo de render**: mesmo estilo 3D Pixar-like do restante do elenco, superfícies macias
- **Personalidade em 3 traços**: paciente, observadora, sábia
- **Papel narrativo**: traz a razão e a solução calma para os impulsos de Fon
- **Tique de fala**: "Devagar se vai ao longe"
- **Cor-assinatura**: verde-musgo com dourado
- **Leitmotif musical**: violoncelo grave e lento, uma nota sustentada quando ela fala
- **Movimento característico**: anda em passos curtos e regulares, nunca corre

```yaml personagem
nome: "Tarta"
tipo: "tartaruga antropomórfica"
estagio_vida: "adulto"
altura_relativa: 0.75
tracos_fisicos:
  - "olhos grandes e expressivos"
  - "corpo baixo e atarracado (proporção \"bebê\")"
  - "contornos bem redondos e macios"
cor_assinatura: "verde-musgo"
descricao_visual_completa: "tartaruga antropomórfica, casco grande em verde-musgo com padrão de espiral dourada no centro, corpo pequeno em verde mais claro, olhos redondos e gentis com cílios longos, usa óculos redondos vermelhos, um pequeno chapéu de palha preso no casco, movimentos e voz sempre calmos"
tique_de_fala: "Devagar se vai ao longe"
movimento_caracteristico: "anda em passos curtos e regulares, nunca corre"
```

## Ambiente-base da série

- **Cenário-padrão**: uma clareira redonda numa floresta tropical colorida, com um grande toco de árvore no centro usado como "praça de encontro"
- **Paleta de cores da série**: laranja-cenoura, verde-musgo, turquesa e amarelo-sol
- **Ritual de abertura**: Fon pula sobre o toco central gritando "Bora, bora, bora!" enquanto Tarta sobe devagar, com a vinheta cantada da série
- **Ritual de encerramento**: os dois se abraçam sentados no toco, olhando para o pôr do sol, e cantam a última linha do tema de encerramento juntos
