---
name: skill-video-infantil-3d
description: Cria roteiros completos de episódios infantis em animação 3D — com elenco fixo (protagonista + coadjuvante), mais de 0 a 3 personagens facultativos da própria franquia sorteados por episódio (e, só por pedido explícito, um convidado crossover de outra franquia), storytelling em arco de 3 a 4 minutos, ambientação (background), estímulo sensorial (cor, textura, som, movimento) e música-tema contagiante — além dos prompts prontos para gerar cada cena em ferramentas de vídeo 3D por IA (Runway, Sora, Kling, Pika, Veo). Use sempre que o usuário pedir um episódio, roteiro, história ou vídeo infantil em 3D, mencionar "elenco fixo", personagem convidado, série animada para crianças pequenas, ou pedir prompts de cena para gerar desenho animado 3D — mesmo que não diga explicitamente "roteiro".
---

# Skill: Vídeo Infantil 3D com Elenco Fixo

Você é o showrunner de uma série de vídeos infantis 3D de 3 a 4 minutos, no estilo de séries como Cocomelon, Word Party ou Bino e Fino: elenco fixo reconhecível, repetição rítmica, cores vibrantes, música cantável e uma lição simples por episódio. Seu trabalho é escrever o roteiro completo de cada episódio E os prompts de geração de vídeo 3D cena a cena — prontos para colar em uma ferramenta de vídeo por IA.

Cada episódio precisa ser reconhecível como parte da MESMA série (elenco, paleta de cores, tema musical) mas contar uma história nova. Protagonista e coadjuvante estão sempre presentes; o resto do elenco de cada episódio (0 a 3 personagens) vem, na grande maioria das vezes (o caminho padrão), de um sorteio dentro do pacote de personagens da própria franquia — um convidado emprestado de outra franquia é a exceção, e só existe quando o usuário pede de forma explícita (ver Passo 2).

## Por que a bíblia de personagens importa

Modelos de geração de vídeo por IA não têm memória entre cenas nem entre episódios — cada prompt de cena precisa redescrever o personagem inteiro (cor, formato, roupa, textura) para manter consistência visual. É por isso que a primeira coisa que esta skill faz é fixar uma **bíblia de personagens** bem detalhada: ela é a fonte da verdade que você vai copiar, cena após cena, episódio após episódio, para o elenco nunca "mudar de cara" de um vídeo para o outro.

## Workflow

### Passo 1 — Verificar ou criar a bíblia de personagens

Procure por um arquivo `character-bible.md` no diretório de trabalho do usuário (ou pergunte onde ele guarda o projeto da série, se já existir um).

- **Se já existir**: leia e use os personagens fixos exatamente como estão descritos. Não improvise mudanças de aparência ou personalidade sem o usuário pedir.
- **Se não existir** (primeira execução da série): você vai criar o protagonista e o coadjuvante fixos agora, com a ajuda do usuário, em duas rodadas de perguntas com `ask_user_input_v0`.

  **Rodada A — contexto da série** (uma vez só, vale para todo o elenco):
  - Tipo de protagonista e coadjuvante (criança, animal antropomórfico, objeto animado, criatura fantástica etc.) e a dupla de personalidades (ex: curioso/cautelosa, atrapalhado/organizada — contraste gera comédia e conflito fácil)
  - Ambiente-base da série (floresta mágica, bairro colorido, fundo do mar, espaço sideral etc.)
  - Faixa etária alvo (isso muda ritmo, vocabulário e duração de plano — bebês/2-4 anos pedem cortes mais lentos e repetição; 5-7 anos aguentam mais reviravolta)

  **Rodada B — design visual, uma única chamada de `ask_user_input_v0` com 3 perguntas.** Esta série usa uma linguagem visual fixa de "boneco fofo" (o mesmo motivo por trás de Cocomelon, Word Party etc.: traços exagerados de bebê facilitam a leitura de expressão à distância e em telas pequenas). O banco completo de 10 traços físicos elegíveis está documentado em `references/character-bible-template.md`, organizado em 3 grupos (cabeça/feições, corpo/contorno, textura/movimento) — mas não pergunte sobre os 10. Com o tipo e a personalidade de cada personagem já definidos na Rodada A, **curadoria antes da pergunta**: escolha os 4 traços do banco que mais combinam com cada personagem (ex: um personagem "atrapalhado" combina com "movimento saltitante e elástico"; um "sábio e calmo" combina melhor com "corpo baixo e atarracado" do que com traços de movimento exagerado) e pergunte só sobre esses 4, deixando claro que o usuário pode pedir para ver o banco completo se quiser mais controle. Monte a chamada assim:

  - **Pergunta 1 — Traços físicos do protagonista** (`multi_select`, os 4 traços curados + explicando que dá pra pedir mais opções)
  - **Pergunta 2 — Traços físicos do coadjuvante** (`multi_select`, os 4 traços curados para esse personagem)
  - **Pergunta 3 — Paleta de cores** (`single_select`): em vez de perguntar a cor de cada personagem em separado e depois checar exclusividade, ofereça combinações já pareadas e válidas, ex: "Protagonista amarelo / Coadjuvante azul", "Protagonista verde / Coadjuvante rosa", "Protagonista vermelho / Coadjuvante amarelo", mais "Outra combinação (descrever)". Isso resolve a exclusividade de cor por construção, sem precisar de uma segunda chamada.

  Se o usuário pedir para ver o banco completo de traços (as 10 opções) em vez dos 4 curados, mostre-o e repita a pergunta com o banco inteiro.

  (Ao promover um convidado a recorrente mais tarde — um terceiro personagem fixo — a combinação pareada já não se aplica: pergunte a cor dele em `single_select` só entre as 3 cores da paleta que ainda não foram usadas pelo protagonista e pelo coadjuvante.)

  Depois de coletar essa única rodada, você preenche sozinho, com criatividade, o restante dos detalhes de uma bíblia de personagens completa seguindo `references/character-bible-template.md`: aparência física exaustiva (para reescrever em todo prompt de vídeo, incorporando os traços e a cor escolhidos), personalidade, tique de fala/catchphrase, e um leitmotif musical (motivo melódico ou instrumento que sempre acompanha o personagem). Mostre a bíblia ao usuário e ajuste conforme o feedback antes de seguir. Salve o arquivo final como `character-bible.md` no projeto.

  **Rodada C — pacote de personagens facultativos (recomendado, mas opcional agora).** Pergunte se o usuário quer já criar o pacote de personagens facultativos da franquia — o grupo do qual `scripts/sortear_elenco.py` vai sortear 0 a 3 por episódio (ver Passo 2). Fazer isso em lote agora evita repetir o processo de criação a cada episódio, que é exatamente o problema que este passo resolve. Se o usuário topar, pergunte quantos personagens ele quer no pacote inicial (sugira 5 a 8 — poucos o suficiente para não virar um interview longo, muitos o suficiente para o sorteio não repetir sempre os mesmos 2 ou 3) e repita, para cada um, o mesmo processo curado da Rodada B (traços + cor — mas aqui a cor **não precisa ser exclusiva** entre eles, só entre protagonista/coadjuvante). Preencha o restante sozinho e salve em `personagens-facultativos.md`, seguindo `references/personagens-facultativos-template.md`. Se o usuário preferir não criar o pacote agora, tudo bem — os episódios seguem só com protagonista e coadjuvante até o pacote existir (ver Passo 2).

### Passo 2 — Definir o elenco do episódio, depois a lição

A ordem importa aqui: **primeiro decide quem aparece, depois a lição/história se adapta a quem saiu.** É o inverso do que pareceria mais natural (lição → personagem que combina com ela), mas é o que torna o sorteio uma simplificação de verdade em vez de um enfeite — se você escolhe a lição antes e depois força o sorteio a "combinar", está recriando manualmente o trabalho que o sorteio deveria eliminar.

**Caminho padrão (a grande maioria dos episódios, ~80%)**: rode `python scripts/sortear_elenco.py personagens-facultativos.md` (usa o padrão de 0 a 3). Se o arquivo ainda não existir, o script avisa e o episódio segue só com protagonista e coadjuvante — normal se a Rodada C do Passo 1 ainda não foi feita. Pegue o resultado do sorteio (pode vir vazio — 0 personagens facultativos é um resultado válido, não um erro) e só então invente a lição e a história em torno de quem saiu.

**Caminho de exceção (raro, só por pedido explícito do usuário)**: convidado emprestado de outra franquia — um crossover. Isso **nunca** é sorteado nem decidido por você; só acontece se o usuário pedir nominalmente ("quero um episódio com o Fulano da série X"). Nesse caso: rode `python scripts/banco_convidados.py checar banco-convidados.md "Nome"` — se o nome já tiver aparecido antes, o script mostra a ficha existente e você decide com o usuário se é o mesmo personagem voltando (reaproveite a descrição) ou se precisa de outro nome. Descreva o convidado com o mesmo nível de detalhe visual da bíblia (incluindo `altura_relativa` em relação ao protagonista). Se o usuário também quiser personagens facultativos sorteados no mesmo episódio, rode o sorteio com `--max` reduzido (ex: `--max 2` se o convidado crossover já ocupa uma vaga) para não estourar o limite total de 5 — `scripts/validar_roteiro.py` avisa se isso acontecer mesmo assim.

Depois de decidido o elenco (por sorteio, por pedido explícito de crossover, ou pela combinação dos dois), defina:
- Tema/lição do episódio (uma lição simples e concreta — dividir, esperar a vez, tentar de novo, cuidar de um bichinho — nunca abstrata), pensada para caber na dinâmica de quem está no elenco deste episódio
- Duração alvo dentro da janela de 3 a 4 minutos (use 3:30 como padrão se o usuário não especificar)

### Passo 3 — Estruturar o arco narrativo

Um vídeo de 3-4 minutos para essa faixa etária não aguenta uma trama complexa. Use sempre este arco de 6 batidas, adaptando os nomes das cenas ao tema do episódio:

1. **Abertura/tema de assinatura** (~15-20s) — vinheta cantada com o tema da série, apresenta local e elenco fixo
2. **Estabelecimento** (~25-35s) — protagonista e coadjuvante no dia a dia, os demais personagens do episódio (sorteados ou o convidado, se houver) surgem, o problema/desejo aparece
3. **Primeira tentativa** (~30-40s) — o elenco tenta resolver e falha ou aprende algo, com humor físico
4. **Momento sensorial/musical central** (~40-60s) — a canção-chave do episódio (não a de abertura), ligada à lição, com repetição de refrão e um gesto/dança que a criança pode imitar
5. **Resolução** (~30-40s) — o problema se resolve por causa da lição, celebração em grupo
6. **Encerramento/callback** (~15-20s) — despedida ritual da série (mesma toda vez, como a abertura) e reforço verbal curto da lição

Ajuste os tempos proporcionalmente à duração alvo escolhida no Passo 2.

### Passo 4 — Escrever cena a cena

Para cada cena dentro das 6 batidas, escreva, seguindo `references/roteiro-template.md`:
- **Timecode estimado** (início-fim)
- **Background** — descrição completa do ambiente 3D (não só "floresta": luz, hora do dia, elementos de fundo que se movem, textura predominante)
- **Ação** — o que os personagens fazem, em linguagem de direção de cena
- **Diálogo** — falas curtas, vocabulário simples, uma fala por vez, frases de no máximo ~10-12 palavras (personagens infantis não fazem monólogos)
- **Estímulo sensorial** — pelo menos um elemento explícito de cor, um de textura/movimento e um de som por cena (ver `references/elementos-sensoriais-e-musica.md` para o banco de ideias e por que cada categoria importa nessa faixa etária)
- **Música/SFX** — o que toca nesse momento: só trilha ambiente, um SFX pontual (splash, boing, sino), ou um trecho cantado

### Passo 5 — Compor a música contagiante

Toda série precisa de (a) um tema de abertura, (b) um tema de encerramento e (c) pelo menos uma canção-chave por episódio (a da batida 4). Escreva a letra de cada uma: curta, com refrão repetido pelo menos duas vezes, rima simples (AABB ou ABAB), e uma instrução de estilo/andamento (ex: "reggae infantil, ~100 BPM, com xilofone e ukulele").

Se a skill `skill-cantiga` (ou equivalente de geração de música) estiver disponível na sessão, ofereça ao usuário usá-la para produzir o áudio completo (letra + melodia + faixa cantada) dessas músicas a partir da letra que você escreveu aqui — não tente sintetizar áudio sozinho.

### Passo 6 — Gerar os prompts de vídeo 3D por cena

Este é o entregável que vai direto para a ferramenta de geração de vídeo. Siga `references/prompts-video-3d-guia.md`, que explica a estrutura de prompt recomendada (estilo/render, personagem completo, ação, câmera, luz, trilha) e por que cada prompt de cena precisa ser autocontido.

Para o bloco de personagem, **rode o script uma única vez por episódio**, não cena a cena: o bloco de cada personagem não muda dentro do mesmo episódio, então recomputar é trabalho redundante. Rode `scripts/render_bloco_personagem.py character-bible.md` passando de uma vez todos os nomes que aparecem em algum prompt do episódio — elenco fixo, personagens facultativos sorteados e o convidado (se houver), juntos (requer `pip install jinja2 pyyaml --break-system-packages` se ainda não estiverem instalados):

```bash
python scripts/render_bloco_personagem.py character-bible.md "Fon" "Tarta" "Piu"
```

A saída traz uma linha por personagem, nesta ordem. Guarde essas linhas e cole, em cada prompt de cena, só as dos personagens que aparecem *naquela* cena (nem todo personagem aparece em toda cena) — sem editar o texto e sem rodar o script de novo. Gere um prompt por cena, numerado e alinhado ao timecode do Passo 4.

### Passo 7 — Entregar

Monte o documento final do episódio com, nesta ordem: título, ficha do episódio (elenco, convidado, lição, duração alvo), letra das músicas, roteiro cena a cena completo, e por último o bloco de prompts de vídeo 3D prontos para copiar. Pergunte se o usuário quer isso como arquivo `.md` (rápido) ou `.docx` formatado (use a skill `docx` nesse caso).

Depois de entregar, **só se o episódio usou um convidado crossover** (caminho de exceção do Passo 2) **e** ele era novo (não existia antes no banco), registre-o com `python scripts/banco_convidados.py registrar banco-convidados.md --episodio N --titulo "..." --nome "..." --licao "..." --descricao "..."`. Se o usuário pedir para torná-lo permanente na franquia, ele entra em `personagens-facultativos.md` (não em `character-bible.md`) — adicione o bloco lá, no mesmo formato dos demais facultativos, para passar a fazer parte do sorteio a partir do próximo episódio. Personagens facultativos sorteados no caminho padrão não precisam de registro nenhum — já vivem em `personagens-facultativos.md` desde a Rodada C do Passo 1.

## Consistência entre episódios

Ao escrever um novo episódio de uma série que já tem `character-bible.md`, releia o arquivo inteiro (e `personagens-facultativos.md`, se existir) antes de escrever qualquer prompt de vídeo — é fácil "derivar" a aparência de um personagem ao longo de várias sessões se você confiar na memória em vez de reler a fonte da verdade.

Três arquivos, três papéis que não se misturam:
- `character-bible.md` — só protagonista e coadjuvante, sempre os dois, nunca sorteados.
- `personagens-facultativos.md` — pacote da própria franquia, criado em lote (Rodada C do Passo 1), sorteado 0 a 3 por episódio (`scripts/sortear_elenco.py`). Caminho padrão, ~80% dos episódios.
- `banco-convidados.md` — crossover de outra franquia, nunca sorteado, só por pedido explícito do usuário. Caminho de exceção. Registra quem já apareceu, com que aparência, em qual episódio, para você nunca reaproveitar um nome sem querer.

## Verificação objetiva (evals)

Depois de gerar um roteiro, rode `scripts/validar_roteiro.py <arquivo.md>` para checar automaticamente: duração estimada dentro da janela de 3-4min, presença de todas as seções obrigatórias, pelo menos um elemento sensorial de cada categoria por cena, um prompt de vídeo por cena de roteiro, que todo bloco de personagem usado nos prompts bate exatamente com o que `scripts/render_bloco_personagem.py` geraria a partir da bíblia (pega drift de descrição visual entre cenas), que nenhuma cor-assinatura se repete entre protagonista e coadjuvante, e que o número de personagens ativos no episódio está entre 2 e 5. Mostre o resultado ao usuário e corrija o que falhar antes de entregar.
