#!/usr/bin/env python3
"""
Validador objetivo de roteiros gerados pela skill-video-infantil-3d.

Checa, sem depender de julgamento subjetivo:
  1. Presença das seções obrigatórias do documento
  2. Duração total estimada dentro da janela de 3:00-4:00
  3. Cada cena tem os 3 elementos sensoriais obrigatórios (cor / textura-movimento / som)
  4. Existe pelo menos um prompt de vídeo 3D por cena de roteiro
  5. Todo bloco de personagem usado nos prompts bate com o gerado por
     render_bloco_personagem.py a partir da bíblia — e do banco-convidados.md,
     se existir na mesma pasta, cobrindo também o convidado do episódio
     (detecta drift visual)
  6. Nenhuma cor_assinatura repetida entre personagens do elenco fixo
  7. Número de personagens ativos no episódio (elenco fixo + facultativos
     sorteados + convidado explícito, se houver) dentro do intervalo 2-5

Uso:
    python validar_roteiro.py <caminho_do_roteiro.md> [caminho_da_character-bible.md]

Se a bíblia não for passada, o script procura por 'character-bible.md' na
mesma pasta do roteiro. Se não encontrar, a checagem 5 é pulada com aviso
(não conta como falha).

Exit codes:
    0 -> tudo passou
    1 -> falha de validação (ver relatório impresso)
    2 -> erro de uso / arquivo não encontrado
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
try:
    from render_bloco_personagem import load_personagens, load_personagens_bible_only, render as render_personagem_block
    JINJA_AVAILABLE = True
except ImportError:
    JINJA_AVAILABLE = False

MAX_ELENCO = 5
MIN_ELENCO = 2

REQUIRED_SECTIONS = [
    "## Ficha do episódio",
    "## Músicas do episódio",
    "## Roteiro cena a cena",
]

SCENE_HEADER_RE = re.compile(r"^###\s*Cena\s*\d+.*?\(([^)]*)\)\s*$", re.MULTILINE)
TIMECODE_RE = re.compile(r"(\d{1,2}):(\d{2})")
SENSORY_LINE_RE = re.compile(r"\*\*Estímulo sensorial:\*\*(.*)", re.IGNORECASE)
VIDEO_PROMPT_HEADER_RE = re.compile(r"^###?\s*(Prompt|Cena)\b", re.MULTILINE)


def to_seconds(mm: str, ss: str) -> int:
    return int(mm) * 60 + int(ss)


def check_sections(text: str, report: list) -> bool:
    ok = True
    for section in REQUIRED_SECTIONS:
        if section not in text:
            report.append(f"[FALHA] Seção obrigatória ausente: '{section}'")
            ok = False
    if ok:
        report.append("[OK] Todas as seções obrigatórias presentes")
    return ok


def check_duration(text: str, report: list) -> bool:
    matches = SCENE_HEADER_RE.findall(text)
    if not matches:
        report.append("[FALHA] Nenhum timecode de cena encontrado (formato esperado: '### Cena N — nome (mm:ss–mm:ss)')")
        return False

    last_end = 0
    for block in matches:
        times = TIMECODE_RE.findall(block)
        if not times:
            continue
        mm, ss = times[-1]
        end = to_seconds(mm, ss)
        last_end = max(last_end, end)

    if last_end == 0:
        report.append("[FALHA] Não foi possível calcular a duração total a partir dos timecodes")
        return False

    minutes = last_end / 60
    if 3.0 <= minutes <= 4.0:
        report.append(f"[OK] Duração total estimada: {last_end // 60}:{last_end % 60:02d} (dentro de 3:00-4:00)")
        return True
    else:
        report.append(f"[FALHA] Duração total estimada: {last_end // 60}:{last_end % 60:02d} (fora da janela 3:00-4:00)")
        return False


def check_sensory_elements(text: str, report: list) -> bool:
    scenes = re.split(r"^###\s*Cena\s*\d+", text, flags=re.MULTILINE)[1:]
    if not scenes:
        report.append("[FALHA] Nenhuma cena encontrada para checar elementos sensoriais")
        return False

    ok = True
    for i, scene in enumerate(scenes, start=1):
        m = SENSORY_LINE_RE.search(scene)
        if not m:
            report.append(f"[FALHA] Cena {i}: linha 'Estímulo sensorial' ausente")
            ok = False
            continue
        line = m.group(1).lower()
        has_color = "cor" in line
        has_texture = "textura" in line or "movimento" in line
        has_sound = "som" in line
        if not (has_color and has_texture and has_sound):
            faltando = [n for n, present in [("cor", has_color), ("textura/movimento", has_texture), ("som", has_sound)] if not present]
            report.append(f"[FALHA] Cena {i}: faltando elemento sensorial: {', '.join(faltando)}")
            ok = False

    if ok:
        report.append(f"[OK] Todas as {len(scenes)} cenas têm os 3 elementos sensoriais (cor, textura/movimento, som)")
    return ok


def check_video_prompts(text: str, report: list) -> bool:
    scene_count = len(re.findall(r"^###\s*Cena\s*\d+", text, flags=re.MULTILINE))
    if "prompt" not in text.lower():
        report.append("[FALHA] Nenhum bloco de prompts de vídeo 3D encontrado no documento")
        return False

    # Conta cabeçalhos de prompt de vídeo, ex: "### Prompt — Cena 1 (0:00–0:20)"
    prompt_blocks = len(re.findall(r"(?im)^###\s*prompt\b", text))
    if prompt_blocks == 0:
        # fallback: conta blockquotes como proxy de prompts prontos
        prompt_blocks = len(re.findall(r"^>", text, flags=re.MULTILINE))

    if prompt_blocks >= scene_count and scene_count > 0:
        report.append(f"[OK] Encontrados pelo menos {prompt_blocks} blocos de prompt para {scene_count} cenas")
        return True
    else:
        report.append(f"[FALHA] Encontrados {prompt_blocks} blocos de prompt para {scene_count} cenas (esperado >= {scene_count})")
        return False


def check_character_consistency(text: str, bible_path: Path, report: list) -> bool:
    if not JINJA_AVAILABLE:
        report.append("[AVISO] jinja2/pyyaml não instalados — checagem de consistência de personagem pulada (pip install jinja2 pyyaml --break-system-packages)")
        return True

    if bible_path is None or not bible_path.exists():
        report.append("[AVISO] character-bible.md não encontrada ao lado do roteiro — checagem de consistência de personagem pulada")
        return True

    personagens = load_personagens(bible_path)
    if not personagens:
        report.append("[AVISO] Nenhum bloco ```yaml personagem``` na bíblia — checagem de consistência de personagem pulada")
        return True

    prompts_match = re.search(r"## Prompts de Vídeo 3D(.*)", text, re.DOTALL)
    if not prompts_match:
        report.append("[FALHA] Seção 'Prompts de Vídeo 3D' não encontrada para checar consistência de personagem")
        return False
    prompts_section = prompts_match.group(1)

    prompt_blocks = re.split(r"^###\s*Prompt", prompts_section, flags=re.MULTILINE)[1:]
    ok = True
    for i, block in enumerate(prompt_blocks, start=1):
        for nome, dados in personagens.items():
            if nome not in block:
                continue
            esperado = render_personagem_block([dados], Path(__file__).resolve().parent.parent / "references").strip().rstrip(".")
            if esperado not in block.replace("\n", " "):
                ok = False
                report.append(f"[FALHA] Prompt {i}: bloco de '{nome}' não bate com o gerado por render_bloco_personagem.py (possível drift)")

    if ok:
        report.append("[OK] Todos os blocos de personagem nos prompts batem com a bíblia (sem drift detectado)")
    return ok


def check_color_exclusivity(bible_path: Path, report: list) -> bool:
    if not JINJA_AVAILABLE:
        report.append("[AVISO] jinja2/pyyaml não instalados — checagem de exclusividade de cor pulada")
        return True

    if bible_path is None or not bible_path.exists():
        report.append("[AVISO] character-bible.md não encontrada — checagem de exclusividade de cor pulada")
        return True

    personagens = load_personagens_bible_only(bible_path)
    cores = {}
    ok = True
    for nome, dados in personagens.items():
        cor = dados.get("cor_assinatura")
        if not cor:
            continue
        if cor in cores:
            ok = False
            report.append(f"[FALHA] Cor '{cor}' repetida entre '{cores[cor]}' e '{nome}' — cor-assinatura deve ser exclusiva no elenco fixo")
        else:
            cores[cor] = nome

    if ok:
        if cores:
            report.append(f"[OK] Nenhuma cor-assinatura repetida entre os {len(cores)} personagens do elenco fixo")
        else:
            report.append("[AVISO] Nenhum personagem da bíblia tem cor_assinatura preenchida — checagem de exclusividade pulada")
    return ok


def check_cast_size(text: str, bible_path: Path, report: list) -> bool:
    if not JINJA_AVAILABLE:
        report.append("[AVISO] jinja2/pyyaml não instalados — checagem de limite de elenco pulada")
        return True

    if bible_path is None or not bible_path.exists():
        report.append("[AVISO] character-bible.md não encontrada — checagem de limite de elenco pulada")
        return True

    personagens = load_personagens(bible_path)
    prompts_match = re.search(r"## Prompts de Vídeo 3D(.*)", text, re.DOTALL)
    corpo = prompts_match.group(1) if prompts_match else text

    presentes = {nome for nome in personagens if nome in corpo}
    if not presentes:
        report.append("[AVISO] Nenhum personagem conhecido encontrado nos prompts — checagem de limite de elenco pulada")
        return True

    n = len(presentes)
    if n > MAX_ELENCO:
        report.append(f"[FALHA] {n} personagens ativos no episódio ({', '.join(sorted(presentes))}) — acima do limite máximo de {MAX_ELENCO}")
        return False
    if n < MIN_ELENCO:
        report.append(f"[AVISO] Só {n} personagem(ns) conhecido(s) encontrado(s) nos prompts ({', '.join(sorted(presentes))}) — normalmente protagonista e coadjuvante deveriam aparecer sempre; confira se não é um falso negativo da checagem")
        return True

    report.append(f"[OK] {n} personagens ativos no episódio ({', '.join(sorted(presentes))}) — dentro do intervalo esperado (2 fixos + 0 a 3 facultativos/convidado)")
    return True


def main():
    if len(sys.argv) not in (2, 3):
        print("Uso: python validar_roteiro.py <caminho_do_roteiro.md> [caminho_da_character-bible.md]")
        sys.exit(2)

    path = Path(sys.argv[1])
    if not path.exists():
        print(f"Arquivo não encontrado: {path}")
        sys.exit(2)

    if len(sys.argv) == 3:
        bible_path = Path(sys.argv[2])
    else:
        bible_path = path.parent / "character-bible.md"

    text = path.read_text(encoding="utf-8")
    report: list = []

    results = [
        check_sections(text, report),
        check_duration(text, report),
        check_sensory_elements(text, report),
        check_video_prompts(text, report),
        check_character_consistency(text, bible_path, report),
        check_color_exclusivity(bible_path, report),
        check_cast_size(text, bible_path, report),
    ]

    print("\n".join(report))
    print()
    if all(results):
        print("RESULTADO: PASSOU em todas as checagens.")
        sys.exit(0)
    else:
        print("RESULTADO: FALHOU em ao menos uma checagem — ver acima.")
        sys.exit(1)


if __name__ == "__main__":
    main()
