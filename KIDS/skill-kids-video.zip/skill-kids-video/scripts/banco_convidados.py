#!/usr/bin/env python3
"""
Gerencia o banco de convidados (banco-convidados.md) de uma série:
checa se um nome de convidado já foi usado antes, e registra um
convidado novo (linha no índice + bloco YAML de descrição visual)
depois que um episódio é entregue.

Uso:
    python banco_convidados.py checar <banco-convidados.md> "<Nome>"
    python banco_convidados.py registrar <banco-convidados.md> \\
        --episodio 2 --titulo "Título do Episódio" --nome "Nome" \\
        --licao "lição do episódio" --descricao "descrição visual completa" \\
        [--tipo "tipo do personagem"] [--estagio-vida filhote|jovem|adulto] \\
        [--altura-relativa 0.8] [--tique-de-fala "..."] [--movimento "..."] \\
        [--recorrente]

Exit codes (comando 'checar'):
    0 -> nome novo, pode criar o convidado livremente
    1 -> nome já existe no banco (imprime a ficha existente para reuso/decisão)
    2 -> erro de uso / arquivo não encontrado

Exit codes (comando 'registrar'):
    0 -> registrado com sucesso
    1 -> nome já existe no banco (use 'checar' antes de registrar para evitar duplicata)
    2 -> erro de uso / argumento faltando
"""
import argparse
import re
import sys
from pathlib import Path

YAML_BLOCK_RE = re.compile(r"```yaml\s+personagem\s*\n(.*?)```", re.DOTALL)
NOME_RE = re.compile(r'nome:\s*"([^"]+)"')
INDEX_TABLE_HEADER = "| Episódio | Título | Convidado | Lição | Recorrente? |"
INDEX_TABLE_SEP = "|---|---|---|---|---|"


def find_existing_names(text: str) -> dict:
    names = {}
    for match in YAML_BLOCK_RE.finditer(text):
        nome_match = NOME_RE.search(match.group(1))
        if nome_match:
            names[nome_match.group(1)] = match.group(0)
    return names


def cmd_checar(args):
    path = Path(args.banco)
    if not path.exists():
        print(f"Banco de convidados ainda não existe em {path} — todo nome é novo.")
        sys.exit(0)

    text = path.read_text(encoding="utf-8")
    existentes = find_existing_names(text)

    if args.nome in existentes:
        print(f"'{args.nome}' já existe no banco de convidados. Ficha atual:\n")
        print(existentes[args.nome])
        print("\nDecida com o usuário: é o mesmo convidado voltando (reaproveite esta "
              "descrição via render_bloco_personagem.py) ou um novo convidado que precisa de outro nome?")
        sys.exit(1)
    else:
        print(f"'{args.nome}' ainda não foi usado nesta série. Pode criar normalmente.")
        sys.exit(0)


def cmd_registrar(args):
    path = Path(args.banco)

    if path.exists():
        text = path.read_text(encoding="utf-8")
        if args.nome in find_existing_names(text):
            print(f"'{args.nome}' já está registrado no banco — rode 'checar' antes de registrar para não duplicar.")
            sys.exit(1)
    else:
        text = (
            "# Banco de Convidados\n\n"
            "## Índice de episódios\n\n"
            f"{INDEX_TABLE_HEADER}\n{INDEX_TABLE_SEP}\n\n"
            "## Fichas dos convidados\n\n"
        )

    recorrente = "Sim" if args.recorrente else "Não"
    nova_linha = f"| {args.episodio} | {args.titulo} | {args.nome} | {args.licao} | {recorrente} |\n"

    if INDEX_TABLE_HEADER in text:
        # insere a nova linha logo após a última linha da tabela existente
        header_pos = text.index(INDEX_TABLE_HEADER)
        sep_end = text.index("\n", text.index(INDEX_TABLE_SEP, header_pos)) + 1
        # avança até o fim do bloco de linhas da tabela (linhas que começam com '|')
        pos = sep_end
        while pos < len(text) and text[pos:pos + 1] == "|":
            pos = text.index("\n", pos) + 1
        text = text[:pos] + nova_linha + text[pos:]
    else:
        text += f"{INDEX_TABLE_HEADER}\n{INDEX_TABLE_SEP}\n{nova_linha}"

    campos_opcionais = ""
    if args.tipo:
        campos_opcionais += f'tipo: "{args.tipo}"\n'
    if args.estagio_vida:
        campos_opcionais += f'estagio_vida: "{args.estagio_vida}"\n'
    if args.altura_relativa is not None:
        campos_opcionais += f"altura_relativa: {args.altura_relativa}\n"
    if args.tique_de_fala:
        campos_opcionais += f'tique_de_fala: "{args.tique_de_fala}"\n'
    if args.movimento:
        campos_opcionais += f'movimento_caracteristico: "{args.movimento}"\n'

    novo_bloco = (
        f"\n### {args.nome} (Episódio {args.episodio})\n\n"
        "```yaml personagem\n"
        f'nome: "{args.nome}"\n'
        f"{campos_opcionais}"
        f'descricao_visual_completa: "{args.descricao}"\n'
        "```\n"
    )
    text += novo_bloco

    path.write_text(text, encoding="utf-8")
    print(f"'{args.nome}' registrado no banco de convidados ({path}).")
    sys.exit(0)


def main():
    parser = argparse.ArgumentParser(description="Gerencia o banco de convidados da série.")
    sub = parser.add_subparsers(dest="comando", required=True)

    p_checar = sub.add_parser("checar")
    p_checar.add_argument("banco")
    p_checar.add_argument("nome")
    p_checar.set_defaults(func=cmd_checar)

    p_registrar = sub.add_parser("registrar")
    p_registrar.add_argument("banco")
    p_registrar.add_argument("--episodio", required=True)
    p_registrar.add_argument("--titulo", required=True)
    p_registrar.add_argument("--nome", required=True)
    p_registrar.add_argument("--licao", required=True)
    p_registrar.add_argument("--descricao", required=True)
    p_registrar.add_argument("--recorrente", action="store_true")
    p_registrar.add_argument("--tipo")
    p_registrar.add_argument("--estagio-vida", dest="estagio_vida")
    p_registrar.add_argument("--altura-relativa", dest="altura_relativa", type=float)
    p_registrar.add_argument("--tique-de-fala", dest="tique_de_fala")
    p_registrar.add_argument("--movimento")
    p_registrar.set_defaults(func=cmd_registrar)

    if len(sys.argv) < 2:
        parser.print_usage()
        sys.exit(2)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
