#!/usr/bin/env python3
"""
Sorteia entre --min e --max personagens facultativos (padrão: 0 a 3) do
pacote da franquia (personagens-facultativos.md) para compor um episódio,
junto com o elenco fixo (protagonista + coadjuvante, sempre presentes,
não fazem parte deste sorteio).

Este script é só para o pacote da própria franquia. Convidados emprestados
de outra franquia (banco-convidados.md) NUNCA são sorteados — só entram
por pedido explícito do usuário, fora deste fluxo.

Uso:
    python sortear_elenco.py <personagens-facultativos.md> [--min 0] [--max 3] [--seed N]

Exit codes:
    0 -> sorteio realizado com sucesso (inclusive quando o resultado é 0 personagens — é um resultado válido, não um erro)
    2 -> erro de uso / arquivo não encontrado / dependência ausente
"""
import argparse
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
try:
    from render_bloco_personagem import load_personagens_bible_only
except ImportError as e:
    print(f"Dependência ausente ({e}). Instale com: pip install jinja2 pyyaml --break-system-packages")
    sys.exit(2)


def main():
    parser = argparse.ArgumentParser(description="Sorteia personagens facultativos da franquia para um episódio.")
    parser.add_argument("pacote", help="Caminho para personagens-facultativos.md")
    parser.add_argument("--min", type=int, default=0, help="Mínimo de personagens sorteados (padrão: 0)")
    parser.add_argument("--max", type=int, default=3, help="Máximo de personagens sorteados (padrão: 3)")
    parser.add_argument("--seed", type=int, default=None, help="Semente para sorteio reproduzível (opcional, útil em testes)")
    args = parser.parse_args()

    pacote_path = Path(args.pacote)
    if not pacote_path.exists():
        print(f"Pacote não encontrado: {pacote_path}. Este episódio segue só com o elenco fixo "
              f"(protagonista + coadjuvante) — ou crie o pacote primeiro (ver references/personagens-facultativos-template.md).")
        sys.exit(2)

    if args.min < 0 or args.max < args.min:
        print("--min deve ser >= 0 e --max deve ser >= --min.")
        sys.exit(2)

    personagens = load_personagens_bible_only(pacote_path)
    if not personagens:
        print(f"Nenhum bloco ```yaml personagem``` encontrado em {pacote_path}. "
              f"O pacote existe mas está vazio — crie pelo menos um personagem facultativo antes de sortear.")
        sys.exit(2)

    if args.seed is not None:
        random.seed(args.seed)

    limite_superior = min(args.max, len(personagens))
    if limite_superior < args.min:
        print(f"O pacote só tem {len(personagens)} personagem(ns), menos que o mínimo pedido ({args.min}).")
        sys.exit(2)

    n = random.randint(args.min, limite_superior)
    sorteados = random.sample(list(personagens.keys()), n)

    if n == 0:
        print("Sorteio: 0 personagens facultativos neste episódio — só protagonista e coadjuvante.")
    else:
        print(f"Sorteio: {n} personagem(ns) facultativo(s) para este episódio: {', '.join(sorteados)}")
        print("Combine com o elenco fixo (protagonista + coadjuvante) e adapte a lição/história a quem saiu.")

    sys.exit(0)


if __name__ == "__main__":
    main()
