#!/usr/bin/env python3
"""
Renderiza, via Jinja2, o bloco de descrição visual de um ou mais personagens
a partir da bíblia de personagens — para colar sem alterações dentro de um
prompt de vídeo 3D. Existe para eliminar o "drift" de aparência que acontece
quando o bloco é reescrito de memória a cada cena/episódio.

A bíblia de personagens (character-bible.md) guarda, para cada personagem,
um bloco de dados estruturado em YAML (dentro de um code fence ```yaml
personagem ... ```) ao lado da prosa legível por humanos. Este script lê
esses blocos — e também os do banco-convidados.md, se existir na mesma
pasta, para que o convidado do episódio também possa ser renderizado —
filtra pelos nomes pedidos, e renderiza references/personagem_prompt.j2.

Uso:
    python render_bloco_personagem.py <character-bible.md> <Nome1> [Nome2 ...]

Exit codes:
    0 -> renderizado e impresso com sucesso
    1 -> algum nome pedido não foi encontrado na bíblia
    2 -> erro de uso / arquivo não encontrado / dependência ausente
"""
import re
import sys
from pathlib import Path

try:
    import yaml
    from jinja2 import Environment, FileSystemLoader
except ImportError as e:
    print(f"Dependência ausente ({e}). Instale com: pip install jinja2 pyyaml --break-system-packages")
    sys.exit(2)

YAML_BLOCK_RE = re.compile(r"```yaml\s+personagem\s*\n(.*?)```", re.DOTALL)


def _extract_personagens(text: str) -> dict:
    personagens = {}
    for match in YAML_BLOCK_RE.finditer(text):
        data = yaml.safe_load(match.group(1))
        if not data or "nome" not in data:
            continue
        personagens[data["nome"]] = data
    return personagens


def load_personagens_bible_only(bible_path: Path) -> dict:
    """Carrega só os personagens de UM arquivo (sem mesclar outros) — usado por
    checagens que valem apenas para um conjunto específico, como a exclusividade
    de cor no elenco fixo, e reaproveitado por sortear_elenco.py para ler
    personagens-facultativos.md."""
    return _extract_personagens(bible_path.read_text(encoding="utf-8"))


# Alias semântico: a função acima não é exclusiva de "bíblia", serve para
# qualquer arquivo com blocos ```yaml personagem```.
load_personagens_from_file = load_personagens_bible_only


def load_personagens(bible_path: Path) -> dict:
    """Carrega os personagens da bíblia (elenco fixo) e mescla, se existirem
    na mesma pasta: personagens-facultativos.md (pacote da franquia, sorteável)
    e banco-convidados.md (crossover de outra franquia, só por pedido explícito).
    Em caso de nome repetido, a prioridade é: bíblia > facultativos > convidados."""
    personagens = _extract_personagens(bible_path.read_text(encoding="utf-8"))

    for nome_arquivo in ("personagens-facultativos.md", "banco-convidados.md"):
        irmao_path = bible_path.parent / nome_arquivo
        if irmao_path.exists() and irmao_path != bible_path:
            extras = _extract_personagens(irmao_path.read_text(encoding="utf-8"))
            for nome, dados in extras.items():
                personagens.setdefault(nome, dados)

    return personagens


def compute_scale_sentences(personagens_data: list) -> list:
    """A partir do campo altura_relativa (sempre relativo ao protagonista = 1.0),
    gera frases de ancoragem de proporção entre pares de personagens presentes
    na mesma chamada — para o modelo de vídeo não desenhar a mesma dupla em
    tamanhos diferentes de prompt para prompt."""
    com_altura = [p for p in personagens_data if p.get("altura_relativa") is not None]
    if len(com_altura) < 2:
        return []

    frases = []
    for i in range(len(com_altura)):
        for j in range(i + 1, len(com_altura)):
            a, b = com_altura[i], com_altura[j]
            ha, hb = float(a["altura_relativa"]), float(b["altura_relativa"])
            if hb == 0:
                continue
            razao = ha / hb
            razao_str = f"{razao:.2f}".replace(".", ",")
            if razao >= 1.1:
                frases.append(f"{a['nome']} é cerca de {razao_str}x mais alto que {b['nome']}")
            elif razao <= 0.9:
                razao_inv_str = f"{(1 / razao):.2f}".replace(".", ",")
                frases.append(f"{b['nome']} é cerca de {razao_inv_str}x mais alto que {a['nome']}")
            else:
                frases.append(f"{a['nome']} e {b['nome']} têm aproximadamente a mesma altura")
    return frases


def render(personagens_data: list, template_dir: Path) -> str:
    env = Environment(loader=FileSystemLoader(str(template_dir)), trim_blocks=True, lstrip_blocks=True)
    template = env.get_template("personagem_prompt.j2")
    return template.render(personagens=personagens_data, frases_escala=compute_scale_sentences(personagens_data))


def main():
    if len(sys.argv) < 3:
        print("Uso: python render_bloco_personagem.py <character-bible.md> <Nome1> [Nome2 ...]")
        sys.exit(2)

    bible_path = Path(sys.argv[1])
    if not bible_path.exists():
        print(f"Arquivo não encontrado: {bible_path}")
        sys.exit(2)

    nomes_pedidos = sys.argv[2:]
    personagens = load_personagens(bible_path)

    if not personagens:
        print(f"Nenhum bloco ```yaml personagem``` encontrado em {bible_path}. "
              f"Adicione um bloco estruturado por personagem (ver references/character-bible-template.md).")
        sys.exit(2)

    faltando = [n for n in nomes_pedidos if n not in personagens]
    if faltando:
        print(f"Personagem(ns) não encontrado(s) na bíblia: {', '.join(faltando)}. "
              f"Disponíveis: {', '.join(personagens.keys())}")
        sys.exit(1)

    dados = [personagens[n] for n in nomes_pedidos]
    template_dir = Path(__file__).resolve().parent.parent / "references"
    output = render(dados, template_dir)
    print(output.strip())
    sys.exit(0)


if __name__ == "__main__":
    main()
